﻿namespace SHOPCONTROL
{
    partial class Bienvenidos
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Bienvenidos));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripDropDownButton5 = new System.Windows.Forms.ToolStripDropDownButton();
            this.empresaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.estadosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.municipiosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vendedoresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.formaDePagoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.catalogoDeServiciosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.catalogoDeDoctoresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bancosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripDropDownButton1 = new System.Windows.Forms.ToolStripDropDownButton();
            this.nuevoContratoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.operacionesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.importarAdministrarProductosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.importarExportarPreciosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.notasDeRemisionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reciboToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pagosDePedidosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.carteraDePagosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.registroDePagoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accesoAUsuariosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reimpresionDeFacturaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.registroDeGastosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripDropDownButton6 = new System.Windows.Forms.ToolStripDropDownButton();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.notasDeEvoluciónToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.historiaClinicaOftamologiaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ginecologiaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.estudioColposcopicoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.controlPrenatalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.registroDeCitasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripDropDownButton2 = new System.Windows.Forms.ToolStripDropDownButton();
            this.reporteDeFacturaciónToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reporteDeRecibosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripDropDownButton4 = new System.Windows.Forms.ToolStripDropDownButton();
            this.cosecutivosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.configuraciónToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.configurarFacturacionElectronicaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.configurarCorreoElectronicoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.importaciónDeProductosserviciosExcelToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.baseDeDatosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.comprobaciónDeTablasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.verificarValoresDeFabricaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.respaldoDeBaseBillLineToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripDropDownButton3 = new System.Windows.Forms.ToolStripDropDownButton();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.label2 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.linkLabel3 = new System.Windows.Forms.LinkLabel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.linkLabel4 = new System.Windows.Forms.LinkLabel();
            this.linkLabel5 = new System.Windows.Forms.LinkLabel();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.toolStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.Color.White;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripDropDownButton5,
            this.toolStripSeparator3,
            this.toolStripDropDownButton1,
            this.toolStripSeparator2,
            this.toolStripDropDownButton6,
            this.toolStripDropDownButton2,
            this.toolStripSeparator4,
            this.toolStripDropDownButton4,
            this.toolStripSeparator1,
            this.toolStripDropDownButton3,
            this.toolStripButton2});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1008, 39);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripDropDownButton5
            // 
            this.toolStripDropDownButton5.BackColor = System.Drawing.Color.White;
            this.toolStripDropDownButton5.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.empresaToolStripMenuItem,
            this.estadosToolStripMenuItem,
            this.municipiosToolStripMenuItem,
            this.vendedoresToolStripMenuItem,
            this.formaDePagoToolStripMenuItem,
            this.catalogoDeServiciosToolStripMenuItem,
            this.catalogoDeDoctoresToolStripMenuItem,
            this.bancosToolStripMenuItem});
            this.toolStripDropDownButton5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton5.Image")));
            this.toolStripDropDownButton5.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripDropDownButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton5.Name = "toolStripDropDownButton5";
            this.toolStripDropDownButton5.Size = new System.Drawing.Size(105, 36);
            this.toolStripDropDownButton5.Text = "Catalogos";
            // 
            // empresaToolStripMenuItem
            // 
            this.empresaToolStripMenuItem.Name = "empresaToolStripMenuItem";
            this.empresaToolStripMenuItem.Size = new System.Drawing.Size(272, 22);
            this.empresaToolStripMenuItem.Text = "Información de empresa o institución";
            this.empresaToolStripMenuItem.Click += new System.EventHandler(this.empresaToolStripMenuItem_Click);
            // 
            // estadosToolStripMenuItem
            // 
            this.estadosToolStripMenuItem.Name = "estadosToolStripMenuItem";
            this.estadosToolStripMenuItem.Size = new System.Drawing.Size(272, 22);
            this.estadosToolStripMenuItem.Text = "Directorio de Proveedores";
            this.estadosToolStripMenuItem.Click += new System.EventHandler(this.estadosToolStripMenuItem_Click);
            // 
            // municipiosToolStripMenuItem
            // 
            this.municipiosToolStripMenuItem.Name = "municipiosToolStripMenuItem";
            this.municipiosToolStripMenuItem.Size = new System.Drawing.Size(272, 22);
            this.municipiosToolStripMenuItem.Text = "Directorio de Pacientes para Facturar";
            this.municipiosToolStripMenuItem.Click += new System.EventHandler(this.municipiosToolStripMenuItem_Click);
            // 
            // vendedoresToolStripMenuItem
            // 
            this.vendedoresToolStripMenuItem.Name = "vendedoresToolStripMenuItem";
            this.vendedoresToolStripMenuItem.Size = new System.Drawing.Size(272, 22);
            this.vendedoresToolStripMenuItem.Text = "Directorio de Vendedores";
            this.vendedoresToolStripMenuItem.Click += new System.EventHandler(this.vendedoresToolStripMenuItem_Click);
            // 
            // formaDePagoToolStripMenuItem
            // 
            this.formaDePagoToolStripMenuItem.Name = "formaDePagoToolStripMenuItem";
            this.formaDePagoToolStripMenuItem.Size = new System.Drawing.Size(272, 22);
            this.formaDePagoToolStripMenuItem.Text = "Forma de Pago";
            this.formaDePagoToolStripMenuItem.Click += new System.EventHandler(this.formaDePagoToolStripMenuItem_Click);
            // 
            // catalogoDeServiciosToolStripMenuItem
            // 
            this.catalogoDeServiciosToolStripMenuItem.Name = "catalogoDeServiciosToolStripMenuItem";
            this.catalogoDeServiciosToolStripMenuItem.Size = new System.Drawing.Size(272, 22);
            this.catalogoDeServiciosToolStripMenuItem.Text = "Catalogo de Servicios";
            this.catalogoDeServiciosToolStripMenuItem.Click += new System.EventHandler(this.catalogoDeServiciosToolStripMenuItem_Click);
            // 
            // catalogoDeDoctoresToolStripMenuItem
            // 
            this.catalogoDeDoctoresToolStripMenuItem.Name = "catalogoDeDoctoresToolStripMenuItem";
            this.catalogoDeDoctoresToolStripMenuItem.Size = new System.Drawing.Size(272, 22);
            this.catalogoDeDoctoresToolStripMenuItem.Text = "Catalogo de Doctores";
            this.catalogoDeDoctoresToolStripMenuItem.Click += new System.EventHandler(this.catalogoDeDoctoresToolStripMenuItem_Click);
            // 
            // bancosToolStripMenuItem
            // 
            this.bancosToolStripMenuItem.Name = "bancosToolStripMenuItem";
            this.bancosToolStripMenuItem.Size = new System.Drawing.Size(272, 22);
            this.bancosToolStripMenuItem.Text = "Bancos";
            this.bancosToolStripMenuItem.Click += new System.EventHandler(this.bancosToolStripMenuItem_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 39);
            // 
            // toolStripDropDownButton1
            // 
            this.toolStripDropDownButton1.BackColor = System.Drawing.Color.White;
            this.toolStripDropDownButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nuevoContratoToolStripMenuItem,
            this.operacionesToolStripMenuItem,
            this.notasDeRemisionToolStripMenuItem,
            this.reciboToolStripMenuItem,
            this.pagosDePedidosToolStripMenuItem,
            this.carteraDePagosToolStripMenuItem,
            this.accesoAUsuariosToolStripMenuItem,
            this.reimpresionDeFacturaToolStripMenuItem,
            this.registroDeGastosToolStripMenuItem});
            this.toolStripDropDownButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton1.Image")));
            this.toolStripDropDownButton1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton1.Name = "toolStripDropDownButton1";
            this.toolStripDropDownButton1.Size = new System.Drawing.Size(114, 36);
            this.toolStripDropDownButton1.Text = "Administrar";
            // 
            // nuevoContratoToolStripMenuItem
            // 
            this.nuevoContratoToolStripMenuItem.Name = "nuevoContratoToolStripMenuItem";
            this.nuevoContratoToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.nuevoContratoToolStripMenuItem.Text = "Nuevo Producto";
            this.nuevoContratoToolStripMenuItem.Click += new System.EventHandler(this.nuevoContratoToolStripMenuItem_Click);
            // 
            // operacionesToolStripMenuItem
            // 
            this.operacionesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.importarAdministrarProductosToolStripMenuItem,
            this.importarExportarPreciosToolStripMenuItem});
            this.operacionesToolStripMenuItem.Name = "operacionesToolStripMenuItem";
            this.operacionesToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.operacionesToolStripMenuItem.Text = "Tareas en Productos";
            // 
            // importarAdministrarProductosToolStripMenuItem
            // 
            this.importarAdministrarProductosToolStripMenuItem.Name = "importarAdministrarProductosToolStripMenuItem";
            this.importarAdministrarProductosToolStripMenuItem.Size = new System.Drawing.Size(222, 22);
            this.importarAdministrarProductosToolStripMenuItem.Text = "Importar/Exportar Existencia";
            this.importarAdministrarProductosToolStripMenuItem.Click += new System.EventHandler(this.importarAdministrarProductosToolStripMenuItem_Click);
            // 
            // importarExportarPreciosToolStripMenuItem
            // 
            this.importarExportarPreciosToolStripMenuItem.Name = "importarExportarPreciosToolStripMenuItem";
            this.importarExportarPreciosToolStripMenuItem.Size = new System.Drawing.Size(222, 22);
            this.importarExportarPreciosToolStripMenuItem.Text = "Importar/Exportar Precios";
            this.importarExportarPreciosToolStripMenuItem.Click += new System.EventHandler(this.importarExportarPreciosToolStripMenuItem_Click);
            // 
            // notasDeRemisionToolStripMenuItem
            // 
            this.notasDeRemisionToolStripMenuItem.Name = "notasDeRemisionToolStripMenuItem";
            this.notasDeRemisionToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.notasDeRemisionToolStripMenuItem.Text = "Facturación Electronica";
            this.notasDeRemisionToolStripMenuItem.Click += new System.EventHandler(this.notasDeRemisionToolStripMenuItem_Click);
            // 
            // reciboToolStripMenuItem
            // 
            this.reciboToolStripMenuItem.Name = "reciboToolStripMenuItem";
            this.reciboToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.reciboToolStripMenuItem.Text = "Nuevo Recibo";
            this.reciboToolStripMenuItem.Click += new System.EventHandler(this.reciboToolStripMenuItem_Click);
            // 
            // pagosDePedidosToolStripMenuItem
            // 
            this.pagosDePedidosToolStripMenuItem.Name = "pagosDePedidosToolStripMenuItem";
            this.pagosDePedidosToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.pagosDePedidosToolStripMenuItem.Text = "Registro de Pagos";
            this.pagosDePedidosToolStripMenuItem.Click += new System.EventHandler(this.pagosDePedidosToolStripMenuItem_Click);
            // 
            // carteraDePagosToolStripMenuItem
            // 
            this.carteraDePagosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.registroDePagoToolStripMenuItem});
            this.carteraDePagosToolStripMenuItem.Name = "carteraDePagosToolStripMenuItem";
            this.carteraDePagosToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.carteraDePagosToolStripMenuItem.Text = "Cuentas por Cobrar";
            this.carteraDePagosToolStripMenuItem.Visible = false;
            this.carteraDePagosToolStripMenuItem.Click += new System.EventHandler(this.carteraDePagosToolStripMenuItem_Click);
            // 
            // registroDePagoToolStripMenuItem
            // 
            this.registroDePagoToolStripMenuItem.Name = "registroDePagoToolStripMenuItem";
            this.registroDePagoToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.registroDePagoToolStripMenuItem.Text = "Registro de pago";
            this.registroDePagoToolStripMenuItem.Click += new System.EventHandler(this.registroDePagoToolStripMenuItem_Click);
            // 
            // accesoAUsuariosToolStripMenuItem
            // 
            this.accesoAUsuariosToolStripMenuItem.Name = "accesoAUsuariosToolStripMenuItem";
            this.accesoAUsuariosToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.accesoAUsuariosToolStripMenuItem.Text = "Acceso a Usuarios";
            this.accesoAUsuariosToolStripMenuItem.Click += new System.EventHandler(this.accesoAUsuariosToolStripMenuItem_Click);
            // 
            // reimpresionDeFacturaToolStripMenuItem
            // 
            this.reimpresionDeFacturaToolStripMenuItem.Name = "reimpresionDeFacturaToolStripMenuItem";
            this.reimpresionDeFacturaToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.reimpresionDeFacturaToolStripMenuItem.Text = "Reimpresion de Factura";
            this.reimpresionDeFacturaToolStripMenuItem.Click += new System.EventHandler(this.reimpresionDeFacturaToolStripMenuItem_Click);
            // 
            // registroDeGastosToolStripMenuItem
            // 
            this.registroDeGastosToolStripMenuItem.Name = "registroDeGastosToolStripMenuItem";
            this.registroDeGastosToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.registroDeGastosToolStripMenuItem.Text = "Registro de Gastos ";
            this.registroDeGastosToolStripMenuItem.Click += new System.EventHandler(this.registroDeGastosToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 39);
            // 
            // toolStripDropDownButton6
            // 
            this.toolStripDropDownButton6.BackColor = System.Drawing.Color.White;
            this.toolStripDropDownButton6.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem2,
            this.notasDeEvoluciónToolStripMenuItem,
            this.toolStripMenuItem3,
            this.historiaClinicaOftamologiaToolStripMenuItem1,
            this.ginecologiaToolStripMenuItem,
            this.registroDeCitasToolStripMenuItem});
            this.toolStripDropDownButton6.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton6.Image")));
            this.toolStripDropDownButton6.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripDropDownButton6.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton6.Name = "toolStripDropDownButton6";
            this.toolStripDropDownButton6.Size = new System.Drawing.Size(142, 36);
            this.toolStripDropDownButton6.Text = "Atención Medica";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(224, 22);
            this.toolStripMenuItem2.Text = "Registro de Paciente";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // notasDeEvoluciónToolStripMenuItem
            // 
            this.notasDeEvoluciónToolStripMenuItem.Name = "notasDeEvoluciónToolStripMenuItem";
            this.notasDeEvoluciónToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.notasDeEvoluciónToolStripMenuItem.Text = "Atención de Pacientes";
            this.notasDeEvoluciónToolStripMenuItem.Click += new System.EventHandler(this.notasDeEvoluciónToolStripMenuItem_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(224, 22);
            this.toolStripMenuItem3.Text = "Historia Clinica Dental";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.toolStripMenuItem3_Click);
            // 
            // historiaClinicaOftamologiaToolStripMenuItem1
            // 
            this.historiaClinicaOftamologiaToolStripMenuItem1.Name = "historiaClinicaOftamologiaToolStripMenuItem1";
            this.historiaClinicaOftamologiaToolStripMenuItem1.Size = new System.Drawing.Size(224, 22);
            this.historiaClinicaOftamologiaToolStripMenuItem1.Text = "Historia Clinica Oftamologia";
            this.historiaClinicaOftamologiaToolStripMenuItem1.Click += new System.EventHandler(this.historiaClinicaOftamologiaToolStripMenuItem1_Click);
            // 
            // ginecologiaToolStripMenuItem
            // 
            this.ginecologiaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.estudioColposcopicoToolStripMenuItem,
            this.controlPrenatalToolStripMenuItem});
            this.ginecologiaToolStripMenuItem.Name = "ginecologiaToolStripMenuItem";
            this.ginecologiaToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.ginecologiaToolStripMenuItem.Text = "Ginecologia";
            // 
            // estudioColposcopicoToolStripMenuItem
            // 
            this.estudioColposcopicoToolStripMenuItem.Name = "estudioColposcopicoToolStripMenuItem";
            this.estudioColposcopicoToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
            this.estudioColposcopicoToolStripMenuItem.Text = "Estudio Colposcopico";
            this.estudioColposcopicoToolStripMenuItem.Click += new System.EventHandler(this.estudioColposcopicoToolStripMenuItem_Click_1);
            // 
            // controlPrenatalToolStripMenuItem
            // 
            this.controlPrenatalToolStripMenuItem.Name = "controlPrenatalToolStripMenuItem";
            this.controlPrenatalToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
            this.controlPrenatalToolStripMenuItem.Text = "Control Prenatal";
            this.controlPrenatalToolStripMenuItem.Click += new System.EventHandler(this.controlPrenatalToolStripMenuItem_Click_1);
            // 
            // registroDeCitasToolStripMenuItem
            // 
            this.registroDeCitasToolStripMenuItem.Name = "registroDeCitasToolStripMenuItem";
            this.registroDeCitasToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.registroDeCitasToolStripMenuItem.Text = "Registro de Citas";
            this.registroDeCitasToolStripMenuItem.Click += new System.EventHandler(this.registroDeCitasToolStripMenuItem_Click);
            // 
            // toolStripDropDownButton2
            // 
            this.toolStripDropDownButton2.BackColor = System.Drawing.Color.White;
            this.toolStripDropDownButton2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.reporteDeFacturaciónToolStripMenuItem,
            this.reporteDeRecibosToolStripMenuItem});
            this.toolStripDropDownButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton2.Image")));
            this.toolStripDropDownButton2.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripDropDownButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton2.Name = "toolStripDropDownButton2";
            this.toolStripDropDownButton2.Size = new System.Drawing.Size(98, 36);
            this.toolStripDropDownButton2.Text = "Reportes";
            this.toolStripDropDownButton2.Click += new System.EventHandler(this.toolStripDropDownButton2_Click);
            // 
            // reporteDeFacturaciónToolStripMenuItem
            // 
            this.reporteDeFacturaciónToolStripMenuItem.Name = "reporteDeFacturaciónToolStripMenuItem";
            this.reporteDeFacturaciónToolStripMenuItem.Size = new System.Drawing.Size(196, 22);
            this.reporteDeFacturaciónToolStripMenuItem.Text = "Reporte de Facturación";
            this.reporteDeFacturaciónToolStripMenuItem.Click += new System.EventHandler(this.reporteDeFacturaciónToolStripMenuItem_Click);
            // 
            // reporteDeRecibosToolStripMenuItem
            // 
            this.reporteDeRecibosToolStripMenuItem.Name = "reporteDeRecibosToolStripMenuItem";
            this.reporteDeRecibosToolStripMenuItem.Size = new System.Drawing.Size(196, 22);
            this.reporteDeRecibosToolStripMenuItem.Text = "Reporte de Recibos";
            this.reporteDeRecibosToolStripMenuItem.Click += new System.EventHandler(this.reporteDeRecibosToolStripMenuItem_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 39);
            // 
            // toolStripDropDownButton4
            // 
            this.toolStripDropDownButton4.BackColor = System.Drawing.Color.White;
            this.toolStripDropDownButton4.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cosecutivosToolStripMenuItem,
            this.configuraciónToolStripMenuItem,
            this.configurarFacturacionElectronicaToolStripMenuItem,
            this.configurarCorreoElectronicoToolStripMenuItem,
            this.importaciónDeProductosserviciosExcelToolStripMenuItem,
            this.baseDeDatosToolStripMenuItem});
            this.toolStripDropDownButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton4.Image")));
            this.toolStripDropDownButton4.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripDropDownButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton4.Name = "toolStripDropDownButton4";
            this.toolStripDropDownButton4.Size = new System.Drawing.Size(94, 36);
            this.toolStripDropDownButton4.Text = "Utilerias";
            // 
            // cosecutivosToolStripMenuItem
            // 
            this.cosecutivosToolStripMenuItem.Name = "cosecutivosToolStripMenuItem";
            this.cosecutivosToolStripMenuItem.Size = new System.Drawing.Size(297, 22);
            this.cosecutivosToolStripMenuItem.Text = "Cosecutivos ";
            this.cosecutivosToolStripMenuItem.Click += new System.EventHandler(this.cosecutivosToolStripMenuItem_Click);
            // 
            // configuraciónToolStripMenuItem
            // 
            this.configuraciónToolStripMenuItem.Name = "configuraciónToolStripMenuItem";
            this.configuraciónToolStripMenuItem.Size = new System.Drawing.Size(297, 22);
            this.configuraciónToolStripMenuItem.Text = "Configuración";
            this.configuraciónToolStripMenuItem.Click += new System.EventHandler(this.configuraciónToolStripMenuItem_Click);
            // 
            // configurarFacturacionElectronicaToolStripMenuItem
            // 
            this.configurarFacturacionElectronicaToolStripMenuItem.Name = "configurarFacturacionElectronicaToolStripMenuItem";
            this.configurarFacturacionElectronicaToolStripMenuItem.Size = new System.Drawing.Size(297, 22);
            this.configurarFacturacionElectronicaToolStripMenuItem.Text = "Configurar Facturacion Electronica";
            this.configurarFacturacionElectronicaToolStripMenuItem.Click += new System.EventHandler(this.configurarFacturacionElectronicaToolStripMenuItem_Click);
            // 
            // configurarCorreoElectronicoToolStripMenuItem
            // 
            this.configurarCorreoElectronicoToolStripMenuItem.Name = "configurarCorreoElectronicoToolStripMenuItem";
            this.configurarCorreoElectronicoToolStripMenuItem.Size = new System.Drawing.Size(297, 22);
            this.configurarCorreoElectronicoToolStripMenuItem.Text = "Configurar Correo Electronico";
            this.configurarCorreoElectronicoToolStripMenuItem.Click += new System.EventHandler(this.configurarCorreoElectronicoToolStripMenuItem_Click);
            // 
            // importaciónDeProductosserviciosExcelToolStripMenuItem
            // 
            this.importaciónDeProductosserviciosExcelToolStripMenuItem.Name = "importaciónDeProductosserviciosExcelToolStripMenuItem";
            this.importaciónDeProductosserviciosExcelToolStripMenuItem.Size = new System.Drawing.Size(297, 22);
            this.importaciónDeProductosserviciosExcelToolStripMenuItem.Text = "Importación de productos/servicios Excel..";
            this.importaciónDeProductosserviciosExcelToolStripMenuItem.Click += new System.EventHandler(this.importaciónDeProductosserviciosExcelToolStripMenuItem_Click);
            // 
            // baseDeDatosToolStripMenuItem
            // 
            this.baseDeDatosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.comprobaciónDeTablasToolStripMenuItem,
            this.verificarValoresDeFabricaToolStripMenuItem,
            this.respaldoDeBaseBillLineToolStripMenuItem});
            this.baseDeDatosToolStripMenuItem.Name = "baseDeDatosToolStripMenuItem";
            this.baseDeDatosToolStripMenuItem.Size = new System.Drawing.Size(297, 22);
            this.baseDeDatosToolStripMenuItem.Text = "Base de Datos";
            // 
            // comprobaciónDeTablasToolStripMenuItem
            // 
            this.comprobaciónDeTablasToolStripMenuItem.Name = "comprobaciónDeTablasToolStripMenuItem";
            this.comprobaciónDeTablasToolStripMenuItem.Size = new System.Drawing.Size(215, 22);
            this.comprobaciónDeTablasToolStripMenuItem.Text = "Comprobación de tablas";
            this.comprobaciónDeTablasToolStripMenuItem.Click += new System.EventHandler(this.comprobaciónDeTablasToolStripMenuItem_Click);
            // 
            // verificarValoresDeFabricaToolStripMenuItem
            // 
            this.verificarValoresDeFabricaToolStripMenuItem.Name = "verificarValoresDeFabricaToolStripMenuItem";
            this.verificarValoresDeFabricaToolStripMenuItem.Size = new System.Drawing.Size(215, 22);
            this.verificarValoresDeFabricaToolStripMenuItem.Text = "Verificar Valores de Fabrica";
            this.verificarValoresDeFabricaToolStripMenuItem.Click += new System.EventHandler(this.verificarValoresDeFabricaToolStripMenuItem_Click);
            // 
            // respaldoDeBaseBillLineToolStripMenuItem
            // 
            this.respaldoDeBaseBillLineToolStripMenuItem.Name = "respaldoDeBaseBillLineToolStripMenuItem";
            this.respaldoDeBaseBillLineToolStripMenuItem.Size = new System.Drawing.Size(215, 22);
            this.respaldoDeBaseBillLineToolStripMenuItem.Text = "Respaldo de Base Bill Line";
            this.respaldoDeBaseBillLineToolStripMenuItem.Click += new System.EventHandler(this.respaldoDeBaseBillLineToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 39);
            // 
            // toolStripDropDownButton3
            // 
            this.toolStripDropDownButton3.BackColor = System.Drawing.Color.White;
            this.toolStripDropDownButton3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1});
            this.toolStripDropDownButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton3.Image")));
            this.toolStripDropDownButton3.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripDropDownButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton3.Name = "toolStripDropDownButton3";
            this.toolStripDropDownButton3.Size = new System.Drawing.Size(86, 36);
            this.toolStripDropDownButton3.Text = "Ayuda";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(175, 22);
            this.toolStripMenuItem1.Text = "Manual del usuario";
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.BackColor = System.Drawing.Color.White;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(65, 36);
            this.toolStripButton2.Text = "Salir";
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 707);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1008, 22);
            this.statusStrip1.TabIndex = 2;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(118, 17);
            this.toolStripStatusLabel1.Text = "toolStripStatusLabel1";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(1, 54);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(288, 89);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.BackColor = System.Drawing.Color.Transparent;
            this.linkLabel1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel1.ForeColor = System.Drawing.Color.Black;
            this.linkLabel1.LinkColor = System.Drawing.Color.Black;
            this.linkLabel1.Location = new System.Drawing.Point(54, 335);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(71, 16);
            this.linkLabel1.TabIndex = 4;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "3.- Recibo";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // linkLabel2
            // 
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.BackColor = System.Drawing.Color.Transparent;
            this.linkLabel2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel2.ForeColor = System.Drawing.Color.White;
            this.linkLabel2.LinkColor = System.Drawing.Color.Black;
            this.linkLabel2.Location = new System.Drawing.Point(46, 393);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(173, 16);
            this.linkLabel2.TabIndex = 5;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "-Nuevo servicio / producto";
            this.linkLabel2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel2_LinkClicked);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(11)))), ((int)(((byte)(54)))));
            this.label2.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(765, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(16, 20);
            this.label2.TabIndex = 11;
            this.label2.Text = "0";
            this.label2.Visible = false;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 6000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Lime;
            this.label3.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(14, 72);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(18, 20);
            this.label3.TabIndex = 12;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(670, 314);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 13;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.White;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(736, 54);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(237, 126);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 14;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.DoubleClick += new System.EventHandler(this.pictureBox2_DoubleClick);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(29, 173);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 20);
            this.label4.TabIndex = 15;
            this.label4.Text = "BIENVENIDO";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(118, 173);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(18, 20);
            this.label5.TabIndex = 16;
            this.label5.Text = "...";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(12, 325);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(36, 37);
            this.pictureBox4.TabIndex = 18;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(12, 383);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(36, 37);
            this.pictureBox5.TabIndex = 19;
            this.pictureBox5.TabStop = false;
            // 
            // linkLabel3
            // 
            this.linkLabel3.AutoSize = true;
            this.linkLabel3.BackColor = System.Drawing.Color.Transparent;
            this.linkLabel3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel3.ForeColor = System.Drawing.Color.White;
            this.linkLabel3.LinkColor = System.Drawing.Color.Black;
            this.linkLabel3.Location = new System.Drawing.Point(49, 281);
            this.linkLabel3.Name = "linkLabel3";
            this.linkLabel3.Size = new System.Drawing.Size(128, 16);
            this.linkLabel3.TabIndex = 20;
            this.linkLabel3.TabStop = true;
            this.linkLabel3.Text = "2.- Registro de Cita";
            this.linkLabel3.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel3_LinkClicked_1);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(12, 271);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(36, 37);
            this.pictureBox3.TabIndex = 21;
            this.pictureBox3.TabStop = false;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(295, 72);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(435, 20);
            this.label1.TabIndex = 22;
            this.label1.Text = "...";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(295, 101);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(435, 20);
            this.label6.TabIndex = 23;
            this.label6.Text = "...";
            this.label6.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(12, 226);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(36, 37);
            this.pictureBox6.TabIndex = 25;
            this.pictureBox6.TabStop = false;
            // 
            // linkLabel4
            // 
            this.linkLabel4.AutoSize = true;
            this.linkLabel4.BackColor = System.Drawing.Color.Transparent;
            this.linkLabel4.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel4.ForeColor = System.Drawing.Color.Black;
            this.linkLabel4.LinkColor = System.Drawing.Color.Black;
            this.linkLabel4.Location = new System.Drawing.Point(47, 232);
            this.linkLabel4.Name = "linkLabel4";
            this.linkLabel4.Size = new System.Drawing.Size(139, 16);
            this.linkLabel4.TabIndex = 24;
            this.linkLabel4.TabStop = true;
            this.linkLabel4.Text = "1.- Registro Paciente";
            this.linkLabel4.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel4_LinkClicked);
            // 
            // linkLabel5
            // 
            this.linkLabel5.AutoSize = true;
            this.linkLabel5.BackColor = System.Drawing.Color.Transparent;
            this.linkLabel5.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel5.ForeColor = System.Drawing.Color.Black;
            this.linkLabel5.LinkColor = System.Drawing.Color.Black;
            this.linkLabel5.Location = new System.Drawing.Point(49, 451);
            this.linkLabel5.Name = "linkLabel5";
            this.linkLabel5.Size = new System.Drawing.Size(165, 16);
            this.linkLabel5.TabIndex = 26;
            this.linkLabel5.TabStop = true;
            this.linkLabel5.Text = "4.-Atencion de Pacientes";
            this.linkLabel5.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel5_LinkClicked);
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(12, 441);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(36, 37);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 27;
            this.pictureBox7.TabStop = false;
            // 
            // Bienvenidos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1008, 729);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.linkLabel5);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.linkLabel4);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.linkLabel3);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.linkLabel2);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.toolStrip1);
            this.ForeColor = System.Drawing.Color.Black;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Bienvenidos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bievenido SAIMED";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Activated += new System.EventHandler(this.Bienvenidos_Activated);
            this.Load += new System.EventHandler(this.Bienvenidos_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton5;
        private System.Windows.Forms.ToolStripMenuItem estadosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem municipiosToolStripMenuItem;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton1;
        private System.Windows.Forms.ToolStripMenuItem nuevoContratoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem notasDeRemisionToolStripMenuItem;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton2;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton4;
        private System.Windows.Forms.ToolStripMenuItem cosecutivosToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripMenuItem configuraciónToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem carteraDePagosToolStripMenuItem;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem registroDePagoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem empresaToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.LinkLabel linkLabel2;
        private System.Windows.Forms.ToolStripMenuItem reporteDeFacturaciónToolStripMenuItem;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ToolStripMenuItem bancosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vendedoresToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pagosDePedidosToolStripMenuItem;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.ToolStripMenuItem configurarFacturacionElectronicaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reciboToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem importaciónDeProductosserviciosExcelToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem baseDeDatosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem comprobaciónDeTablasToolStripMenuItem;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ToolStripMenuItem verificarValoresDeFabricaToolStripMenuItem;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem formaDePagoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem respaldoDeBaseBillLineToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accesoAUsuariosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reimpresionDeFacturaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reporteDeRecibosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem operacionesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem importarAdministrarProductosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem importarExportarPreciosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem registroDeGastosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem configurarCorreoElectronicoToolStripMenuItem;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton6;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem historiaClinicaOftamologiaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem registroDeCitasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem catalogoDeServiciosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem catalogoDeDoctoresToolStripMenuItem;
        private System.Windows.Forms.LinkLabel linkLabel3;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.ToolStripMenuItem notasDeEvoluciónToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.LinkLabel linkLabel4;
        private System.Windows.Forms.ToolStripMenuItem ginecologiaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem estudioColposcopicoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem controlPrenatalToolStripMenuItem;
        private System.Windows.Forms.LinkLabel linkLabel5;
        private System.Windows.Forms.PictureBox pictureBox7;
    }
}

