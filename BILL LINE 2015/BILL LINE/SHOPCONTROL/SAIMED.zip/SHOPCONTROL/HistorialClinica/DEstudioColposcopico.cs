﻿namespace SHOPCONTROL.HistorialClinica
{
    
    
    public partial class DEstudioColposcopico {
    }
}
namespace SHOPCONTROL.HistorialClinica {
    
    
    public partial class DEstudioColposcopico {
    }
}
