﻿namespace SHOPCONTROL.HistorialClinica
{
    
    
    public partial class DataSetOftalmologia {
    }
}
namespace SHOPCONTROL.HistorialClinica {
    
    
    public partial class DataSetOftalmologia {
    }
}
