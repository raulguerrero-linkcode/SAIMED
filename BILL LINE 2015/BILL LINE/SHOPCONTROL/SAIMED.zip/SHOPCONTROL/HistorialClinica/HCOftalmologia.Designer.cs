﻿namespace SHOPCONTROL.HistorialClinica
{
    partial class HCOftalmologia
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HCOftalmologia));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.comboBox9 = new System.Windows.Forms.ComboBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dateTimePicker4 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker3 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker6 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker5 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label141 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.textBox69 = new System.Windows.Forms.TextBox();
            this.label92 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.textBox52 = new System.Windows.Forms.TextBox();
            this.textBox58 = new System.Windows.Forms.TextBox();
            this.textBox56 = new System.Windows.Forms.TextBox();
            this.textBox65 = new System.Windows.Forms.TextBox();
            this.textBox48 = new System.Windows.Forms.TextBox();
            this.textBox50 = new System.Windows.Forms.TextBox();
            this.textBox68 = new System.Windows.Forms.TextBox();
            this.textBox61 = new System.Windows.Forms.TextBox();
            this.textBox60 = new System.Windows.Forms.TextBox();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.textBox51 = new System.Windows.Forms.TextBox();
            this.textBox47 = new System.Windows.Forms.TextBox();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.textBox49 = new System.Windows.Forms.TextBox();
            this.textBox57 = new System.Windows.Forms.TextBox();
            this.textBox55 = new System.Windows.Forms.TextBox();
            this.textBox64 = new System.Windows.Forms.TextBox();
            this.textBox63 = new System.Windows.Forms.TextBox();
            this.textBox62 = new System.Windows.Forms.TextBox();
            this.textBox59 = new System.Windows.Forms.TextBox();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.label79 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.label97 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.label138 = new System.Windows.Forms.Label();
            this.label137 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.pbpp2 = new System.Windows.Forms.PictureBox();
            this.pbbiomicro2 = new System.Windows.Forms.PictureBox();
            this.pbpp1 = new System.Windows.Forms.PictureBox();
            this.pbbiomicro1 = new System.Windows.Forms.PictureBox();
            this.label99 = new System.Windows.Forms.Label();
            this.label98 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.textBox78 = new System.Windows.Forms.TextBox();
            this.textBox77 = new System.Windows.Forms.TextBox();
            this.textBox75 = new System.Windows.Forms.TextBox();
            this.textBox74 = new System.Windows.Forms.TextBox();
            this.textBox73 = new System.Windows.Forms.TextBox();
            this.textBox72 = new System.Windows.Forms.TextBox();
            this.textBox71 = new System.Windows.Forms.TextBox();
            this.textBox76 = new System.Windows.Forms.TextBox();
            this.textBox70 = new System.Windows.Forms.TextBox();
            this.angulo2 = new System.Windows.Forms.PictureBox();
            this.pbcristalinooi = new System.Windows.Forms.PictureBox();
            this.angulo1 = new System.Windows.Forms.PictureBox();
            this.pbcristalinood = new System.Windows.Forms.PictureBox();
            this.label103 = new System.Windows.Forms.Label();
            this.label102 = new System.Windows.Forms.Label();
            this.label113 = new System.Windows.Forms.Label();
            this.label112 = new System.Windows.Forms.Label();
            this.label108 = new System.Windows.Forms.Label();
            this.label107 = new System.Windows.Forms.Label();
            this.label106 = new System.Windows.Forms.Label();
            this.label109 = new System.Windows.Forms.Label();
            this.label105 = new System.Windows.Forms.Label();
            this.label111 = new System.Windows.Forms.Label();
            this.label101 = new System.Windows.Forms.Label();
            this.label110 = new System.Windows.Forms.Label();
            this.label114 = new System.Windows.Forms.Label();
            this.label104 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.comboBox8 = new System.Windows.Forms.ComboBox();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.comboBox7 = new System.Windows.Forms.ComboBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.textBox88 = new System.Windows.Forms.TextBox();
            this.textBox87 = new System.Windows.Forms.TextBox();
            this.textBox94 = new System.Windows.Forms.TextBox();
            this.textBox86 = new System.Windows.Forms.TextBox();
            this.textBox93 = new System.Windows.Forms.TextBox();
            this.textBox91 = new System.Windows.Forms.TextBox();
            this.textBox89 = new System.Windows.Forms.TextBox();
            this.textBox90 = new System.Windows.Forms.TextBox();
            this.textBox85 = new System.Windows.Forms.TextBox();
            this.label127 = new System.Windows.Forms.Label();
            this.label125 = new System.Windows.Forms.Label();
            this.label121 = new System.Windows.Forms.Label();
            this.textBox92 = new System.Windows.Forms.TextBox();
            this.label124 = new System.Windows.Forms.Label();
            this.label120 = new System.Windows.Forms.Label();
            this.label132 = new System.Windows.Forms.Label();
            this.label116 = new System.Windows.Forms.Label();
            this.label129 = new System.Windows.Forms.Label();
            this.label126 = new System.Windows.Forms.Label();
            this.label128 = new System.Windows.Forms.Label();
            this.label123 = new System.Windows.Forms.Label();
            this.label119 = new System.Windows.Forms.Label();
            this.label131 = new System.Windows.Forms.Label();
            this.label117 = new System.Windows.Forms.Label();
            this.label130 = new System.Windows.Forms.Label();
            this.label140 = new System.Windows.Forms.Label();
            this.label139 = new System.Windows.Forms.Label();
            this.label118 = new System.Windows.Forms.Label();
            this.label133 = new System.Windows.Forms.Label();
            this.label122 = new System.Windows.Forms.Label();
            this.label115 = new System.Windows.Forms.Label();
            this.retina2 = new System.Windows.Forms.PictureBox();
            this.retina1 = new System.Windows.Forms.PictureBox();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.textBox97 = new System.Windows.Forms.TextBox();
            this.textBox96 = new System.Windows.Forms.TextBox();
            this.textBox95 = new System.Windows.Forms.TextBox();
            this.label136 = new System.Windows.Forms.Label();
            this.label135 = new System.Windows.Forms.Label();
            this.label134 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbNuevo = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lbEditar = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbpp2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbbiomicro2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbpp1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbbiomicro1)).BeginInit();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.angulo2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbcristalinooi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.angulo1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbcristalinood)).BeginInit();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.retina2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.retina1)).BeginInit();
            this.tabPage7.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Controls.Add(this.tabPage7);
            this.tabControl1.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(1, 132);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(995, 642);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.comboBox9);
            this.tabPage1.Controls.Add(this.textBox8);
            this.tabPage1.Controls.Add(this.textBox9);
            this.tabPage1.Controls.Add(this.textBox10);
            this.tabPage1.Controls.Add(this.textBox11);
            this.tabPage1.Controls.Add(this.label27);
            this.tabPage1.Controls.Add(this.label28);
            this.tabPage1.Controls.Add(this.label29);
            this.tabPage1.Controls.Add(this.label30);
            this.tabPage1.Controls.Add(this.textBox7);
            this.tabPage1.Controls.Add(this.textBox6);
            this.tabPage1.Controls.Add(this.textBox5);
            this.tabPage1.Controls.Add(this.textBox4);
            this.tabPage1.Controls.Add(this.textBox3);
            this.tabPage1.Controls.Add(this.textBox2);
            this.tabPage1.Controls.Add(this.label22);
            this.tabPage1.Controls.Add(this.label21);
            this.tabPage1.Controls.Add(this.label26);
            this.tabPage1.Controls.Add(this.label25);
            this.tabPage1.Controls.Add(this.label24);
            this.tabPage1.Controls.Add(this.label23);
            this.tabPage1.Controls.Add(this.label20);
            this.tabPage1.Controls.Add(this.label19);
            this.tabPage1.Controls.Add(this.label18);
            this.tabPage1.Controls.Add(this.label17);
            this.tabPage1.Location = new System.Drawing.Point(4, 23);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(987, 615);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Página 1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // comboBox9
            // 
            this.comboBox9.FormattingEnabled = true;
            this.comboBox9.Items.AddRange(new object[] {
            "PACIENTE",
            "FAMILIAR",
            "OTRO"});
            this.comboBox9.Location = new System.Drawing.Point(126, 18);
            this.comboBox9.Name = "comboBox9";
            this.comboBox9.Size = new System.Drawing.Size(128, 22);
            this.comboBox9.TabIndex = 0;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(341, 358);
            this.textBox8.Multiline = true;
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(332, 41);
            this.textBox8.TabIndex = 10;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(374, 308);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(298, 22);
            this.textBox9.TabIndex = 9;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(374, 280);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(298, 22);
            this.textBox10.TabIndex = 8;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(374, 252);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(298, 22);
            this.textBox11.TabIndex = 7;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(337, 341);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(51, 14);
            this.label27.TabIndex = 4;
            this.label27.Text = "OTROS:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(336, 316);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(26, 14);
            this.label28.TabIndex = 5;
            this.label28.Text = "CA:";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(336, 288);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(34, 14);
            this.label29.TabIndex = 6;
            this.label29.Text = "HAS:";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(336, 260);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(32, 14);
            this.label30.TabIndex = 7;
            this.label30.Text = "D.M.";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(11, 358);
            this.textBox7.Multiline = true;
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(307, 41);
            this.textBox7.TabIndex = 6;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(44, 308);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(273, 22);
            this.textBox6.TabIndex = 5;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(44, 280);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(273, 22);
            this.textBox5.TabIndex = 4;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(44, 252);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(273, 22);
            this.textBox4.TabIndex = 3;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(13, 138);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(659, 51);
            this.textBox3.TabIndex = 2;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(13, 67);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(659, 51);
            this.textBox2.TabIndex = 1;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(336, 227);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(86, 14);
            this.label22.TabIndex = 0;
            this.label22.Text = "Oftalmológicos";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(6, 227);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(63, 14);
            this.label21.TabIndex = 0;
            this.label21.Text = "Sistémicos";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(7, 341);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(51, 14);
            this.label26.TabIndex = 0;
            this.label26.Text = "OTROS:";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(6, 316);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(26, 14);
            this.label25.TabIndex = 0;
            this.label25.Text = "CA:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(6, 288);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(34, 14);
            this.label24.TabIndex = 0;
            this.label24.Text = "HAS:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(6, 260);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(32, 14);
            this.label23.TabIndex = 0;
            this.label23.Text = "D.M.";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(6, 201);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(141, 14);
            this.label20.TabIndex = 0;
            this.label20.Text = "HEREDO FAMILIARES:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(10, 121);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(156, 14);
            this.label19.TabIndex = 0;
            this.label19.Text = "PADECIMIENTO ACTUAL:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(6, 49);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(148, 14);
            this.label18.TabIndex = 0;
            this.label18.Text = "MOTIVO DE CONSULTA:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(6, 26);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(114, 14);
            this.label17.TabIndex = 11;
            this.label17.Text = "INTERROGATORIO:";
            // 
            // tabPage2
            // 
            this.tabPage2.AutoScroll = true;
            this.tabPage2.Controls.Add(this.dateTimePicker4);
            this.tabPage2.Controls.Add(this.dateTimePicker3);
            this.tabPage2.Controls.Add(this.dateTimePicker6);
            this.tabPage2.Controls.Add(this.dateTimePicker5);
            this.tabPage2.Controls.Add(this.dateTimePicker2);
            this.tabPage2.Controls.Add(this.textBox14);
            this.tabPage2.Controls.Add(this.textBox13);
            this.tabPage2.Controls.Add(this.textBox20);
            this.tabPage2.Controls.Add(this.textBox35);
            this.tabPage2.Controls.Add(this.textBox34);
            this.tabPage2.Controls.Add(this.textBox33);
            this.tabPage2.Controls.Add(this.textBox32);
            this.tabPage2.Controls.Add(this.textBox31);
            this.tabPage2.Controls.Add(this.textBox30);
            this.tabPage2.Controls.Add(this.textBox19);
            this.tabPage2.Controls.Add(this.textBox18);
            this.tabPage2.Controls.Add(this.textBox17);
            this.tabPage2.Controls.Add(this.textBox16);
            this.tabPage2.Controls.Add(this.textBox26);
            this.tabPage2.Controls.Add(this.textBox25);
            this.tabPage2.Controls.Add(this.textBox27);
            this.tabPage2.Controls.Add(this.textBox29);
            this.tabPage2.Controls.Add(this.textBox28);
            this.tabPage2.Controls.Add(this.textBox40);
            this.tabPage2.Controls.Add(this.textBox42);
            this.tabPage2.Controls.Add(this.textBox41);
            this.tabPage2.Controls.Add(this.textBox39);
            this.tabPage2.Controls.Add(this.textBox38);
            this.tabPage2.Controls.Add(this.textBox37);
            this.tabPage2.Controls.Add(this.textBox36);
            this.tabPage2.Controls.Add(this.textBox24);
            this.tabPage2.Controls.Add(this.textBox23);
            this.tabPage2.Controls.Add(this.textBox15);
            this.tabPage2.Controls.Add(this.textBox22);
            this.tabPage2.Controls.Add(this.textBox21);
            this.tabPage2.Controls.Add(this.textBox12);
            this.tabPage2.Controls.Add(this.label36);
            this.tabPage2.Controls.Add(this.label44);
            this.tabPage2.Controls.Add(this.label35);
            this.tabPage2.Controls.Add(this.label58);
            this.tabPage2.Controls.Add(this.label57);
            this.tabPage2.Controls.Add(this.label56);
            this.tabPage2.Controls.Add(this.label55);
            this.tabPage2.Controls.Add(this.label54);
            this.tabPage2.Controls.Add(this.label53);
            this.tabPage2.Controls.Add(this.label42);
            this.tabPage2.Controls.Add(this.label41);
            this.tabPage2.Controls.Add(this.label40);
            this.tabPage2.Controls.Add(this.label39);
            this.tabPage2.Controls.Add(this.label38);
            this.tabPage2.Controls.Add(this.label52);
            this.tabPage2.Controls.Add(this.label141);
            this.tabPage2.Controls.Add(this.label51);
            this.tabPage2.Controls.Add(this.label50);
            this.tabPage2.Controls.Add(this.label49);
            this.tabPage2.Controls.Add(this.label48);
            this.tabPage2.Controls.Add(this.label47);
            this.tabPage2.Controls.Add(this.label46);
            this.tabPage2.Controls.Add(this.label45);
            this.tabPage2.Controls.Add(this.label37);
            this.tabPage2.Controls.Add(this.label43);
            this.tabPage2.Controls.Add(this.label34);
            this.tabPage2.Controls.Add(this.label33);
            this.tabPage2.Controls.Add(this.label64);
            this.tabPage2.Controls.Add(this.label61);
            this.tabPage2.Controls.Add(this.label62);
            this.tabPage2.Controls.Add(this.label65);
            this.tabPage2.Controls.Add(this.label63);
            this.tabPage2.Controls.Add(this.label60);
            this.tabPage2.Controls.Add(this.label59);
            this.tabPage2.Controls.Add(this.label31);
            this.tabPage2.Controls.Add(this.label32);
            this.tabPage2.Location = new System.Drawing.Point(4, 23);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(987, 615);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Página 2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // dateTimePicker4
            // 
            this.dateTimePicker4.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker4.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker4.Location = new System.Drawing.Point(734, 400);
            this.dateTimePicker4.Name = "dateTimePicker4";
            this.dateTimePicker4.Size = new System.Drawing.Size(107, 22);
            this.dateTimePicker4.TabIndex = 29;
            // 
            // dateTimePicker3
            // 
            this.dateTimePicker3.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker3.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker3.Location = new System.Drawing.Point(734, 372);
            this.dateTimePicker3.Name = "dateTimePicker3";
            this.dateTimePicker3.Size = new System.Drawing.Size(107, 22);
            this.dateTimePicker3.TabIndex = 27;
            // 
            // dateTimePicker6
            // 
            this.dateTimePicker6.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker6.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker6.Location = new System.Drawing.Point(423, 589);
            this.dateTimePicker6.Name = "dateTimePicker6";
            this.dateTimePicker6.Size = new System.Drawing.Size(107, 22);
            this.dateTimePicker6.TabIndex = 34;
            // 
            // dateTimePicker5
            // 
            this.dateTimePicker5.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker5.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker5.Location = new System.Drawing.Point(423, 560);
            this.dateTimePicker5.Name = "dateTimePicker5";
            this.dateTimePicker5.Size = new System.Drawing.Size(107, 22);
            this.dateTimePicker5.TabIndex = 32;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker2.Location = new System.Drawing.Point(734, 344);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(107, 22);
            this.dateTimePicker2.TabIndex = 25;
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(411, 53);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(119, 22);
            this.textBox14.TabIndex = 2;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(253, 53);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(119, 22);
            this.textBox13.TabIndex = 1;
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(10, 252);
            this.textBox20.Multiline = true;
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(520, 50);
            this.textBox20.TabIndex = 8;
            // 
            // textBox35
            // 
            this.textBox35.Location = new System.Drawing.Point(105, 484);
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(425, 22);
            this.textBox35.TabIndex = 23;
            // 
            // textBox34
            // 
            this.textBox34.Location = new System.Drawing.Point(105, 456);
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(425, 22);
            this.textBox34.TabIndex = 22;
            // 
            // textBox33
            // 
            this.textBox33.Location = new System.Drawing.Point(105, 428);
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(425, 22);
            this.textBox33.TabIndex = 21;
            // 
            // textBox32
            // 
            this.textBox32.Location = new System.Drawing.Point(105, 400);
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(425, 22);
            this.textBox32.TabIndex = 20;
            // 
            // textBox31
            // 
            this.textBox31.Location = new System.Drawing.Point(105, 372);
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(425, 22);
            this.textBox31.TabIndex = 19;
            // 
            // textBox30
            // 
            this.textBox30.Location = new System.Drawing.Point(105, 344);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(425, 22);
            this.textBox30.TabIndex = 18;
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(102, 198);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(428, 22);
            this.textBox19.TabIndex = 7;
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(87, 169);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(443, 22);
            this.textBox18.TabIndex = 6;
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(140, 139);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(390, 22);
            this.textBox17.TabIndex = 5;
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(78, 111);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(452, 22);
            this.textBox16.TabIndex = 4;
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(642, 111);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(199, 22);
            this.textBox26.TabIndex = 12;
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(656, 140);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(185, 22);
            this.textBox25.TabIndex = 13;
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(579, 198);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(262, 22);
            this.textBox27.TabIndex = 15;
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(604, 256);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(237, 22);
            this.textBox29.TabIndex = 17;
            // 
            // textBox28
            // 
            this.textBox28.Location = new System.Drawing.Point(639, 227);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(202, 22);
            this.textBox28.TabIndex = 16;
            // 
            // textBox40
            // 
            this.textBox40.Location = new System.Drawing.Point(550, 560);
            this.textBox40.Multiline = true;
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(291, 49);
            this.textBox40.TabIndex = 35;
            // 
            // textBox42
            // 
            this.textBox42.Location = new System.Drawing.Point(550, 456);
            this.textBox42.Multiline = true;
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(291, 50);
            this.textBox42.TabIndex = 30;
            // 
            // textBox41
            // 
            this.textBox41.Location = new System.Drawing.Point(550, 400);
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(178, 22);
            this.textBox41.TabIndex = 28;
            // 
            // textBox39
            // 
            this.textBox39.Location = new System.Drawing.Point(550, 372);
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(178, 22);
            this.textBox39.TabIndex = 26;
            // 
            // textBox38
            // 
            this.textBox38.Location = new System.Drawing.Point(10, 587);
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(407, 22);
            this.textBox38.TabIndex = 33;
            // 
            // textBox37
            // 
            this.textBox37.Location = new System.Drawing.Point(10, 560);
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(407, 22);
            this.textBox37.TabIndex = 31;
            // 
            // textBox36
            // 
            this.textBox36.Location = new System.Drawing.Point(550, 344);
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(178, 22);
            this.textBox36.TabIndex = 24;
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(674, 169);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(167, 22);
            this.textBox24.TabIndex = 14;
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(618, 82);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(223, 22);
            this.textBox23.TabIndex = 11;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(78, 82);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(452, 22);
            this.textBox15.TabIndex = 3;
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(758, 53);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(83, 22);
            this.textBox22.TabIndex = 10;
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(586, 53);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(83, 22);
            this.textBox21.TabIndex = 9;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(45, 53);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(119, 22);
            this.textBox12.TabIndex = 0;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(378, 61);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(27, 14);
            this.label36.TabIndex = 3;
            this.label36.Text = "UG:";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(675, 61);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(77, 14);
            this.label44.TabIndex = 3;
            this.label44.Text = "EVOLUCION:";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(170, 61);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(77, 14);
            this.label35.TabIndex = 3;
            this.label35.Text = "EVOLUCION:";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label58.Location = new System.Drawing.Point(10, 521);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(51, 14);
            this.label58.TabIndex = 3;
            this.label58.Text = "LASER:";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label57.Location = new System.Drawing.Point(10, 464);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(51, 14);
            this.label57.TabIndex = 3;
            this.label57.Text = "TRUMA:";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.Location = new System.Drawing.Point(10, 436);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(84, 14);
            this.label56.TabIndex = 3;
            this.label56.Text = "ESTRABISMO:";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.Location = new System.Drawing.Point(10, 408);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(89, 14);
            this.label55.TabIndex = 3;
            this.label55.Text = "RETINOPATIA:";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.Location = new System.Drawing.Point(10, 380);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(74, 14);
            this.label54.TabIndex = 3;
            this.label54.Text = "GLAUCOMA:";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.Location = new System.Drawing.Point(10, 352);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(73, 14);
            this.label53.TabIndex = 3;
            this.label53.Text = "CATARATA:";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(7, 235);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(175, 14);
            this.label42.TabIndex = 3;
            this.label42.Text = "MEDICAMENTOS SISTEMICOS:";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(7, 206);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(89, 14);
            this.label41.TabIndex = 3;
            this.label41.Text = "QUIRURGICOS:";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(7, 177);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(74, 14);
            this.label40.TabIndex = 3;
            this.label40.Text = "ALERGICOS:";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(7, 148);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(127, 14);
            this.label39.TabIndex = 3;
            this.label39.Text = "TRANSFUNCIONALES:";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(7, 119);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(55, 14);
            this.label38.TabIndex = 3;
            this.label38.Text = "CANCER:";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(547, 288);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(64, 14);
            this.label52.TabIndex = 3;
            this.label52.Text = "CIRUGIAS:";
            // 
            // label141
            // 
            this.label141.AutoSize = true;
            this.label141.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label141.Location = new System.Drawing.Point(10, 492);
            this.label141.Name = "label141";
            this.label141.Size = new System.Drawing.Size(51, 14);
            this.label141.TabIndex = 3;
            this.label141.Text = "OTROS:";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(547, 264);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(51, 14);
            this.label51.TabIndex = 3;
            this.label51.Text = "OTROS:";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(547, 235);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(86, 14);
            this.label50.TabIndex = 3;
            this.label50.Text = "INFECCIOSOS:";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(547, 206);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(26, 14);
            this.label49.TabIndex = 3;
            this.label49.Text = "AR:";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(547, 177);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(121, 14);
            this.label48.TabIndex = 3;
            this.label48.Text = "ENF. NEUROLOGICA:";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(547, 148);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(106, 14);
            this.label47.TabIndex = 3;
            this.label47.Text = "ENF. ENDOCRINA:";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(547, 119);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(89, 14);
            this.label46.TabIndex = 3;
            this.label46.Text = "CARDIOPATIA:";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(547, 90);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(65, 14);
            this.label45.TabIndex = 3;
            this.label45.Text = "CONTROL:";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(7, 90);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(65, 14);
            this.label37.TabIndex = 3;
            this.label37.Text = "CONTROL:";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(547, 61);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(34, 14);
            this.label43.TabIndex = 3;
            this.label43.Text = "HAS:";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(7, 61);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(32, 14);
            this.label34.TabIndex = 3;
            this.label34.Text = "D.M.";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(7, 12);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(187, 14);
            this.label33.TabIndex = 3;
            this.label33.Text = "ANTECEDENTES PERSONALES:";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label64.Location = new System.Drawing.Point(462, 533);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(39, 14);
            this.label64.TabIndex = 1;
            this.label64.Text = "Fecha";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label61.Location = new System.Drawing.Point(755, 317);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(39, 14);
            this.label61.TabIndex = 1;
            this.label61.Text = "Fecha";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label62.Location = new System.Drawing.Point(547, 436);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(164, 14);
            this.label62.TabIndex = 1;
            this.label62.Text = "Ultimo examen oftalmológico";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label65.Location = new System.Drawing.Point(601, 533);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(166, 14);
            this.label65.TabIndex = 1;
            this.label65.Text = "Medicamentos oftalmologicos";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label63.Location = new System.Drawing.Point(157, 533);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(90, 14);
            this.label63.TabIndex = 1;
            this.label63.Text = "Procedimientos";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label60.Location = new System.Drawing.Point(547, 317);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(90, 14);
            this.label60.TabIndex = 1;
            this.label60.Text = "Procedimientos";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label59.Location = new System.Drawing.Point(409, 317);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(121, 14);
            this.label59.TabIndex = 1;
            this.label59.Text = "Tiempo de Evolución";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(10, 317);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(111, 14);
            this.label31.TabIndex = 1;
            this.label31.Text = "Oftalmológicos: ojo";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(7, 36);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(63, 14);
            this.label32.TabIndex = 2;
            this.label32.Text = "Sistémicos";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.textBox69);
            this.tabPage3.Controls.Add(this.label92);
            this.tabPage3.Controls.Add(this.comboBox2);
            this.tabPage3.Controls.Add(this.comboBox1);
            this.tabPage3.Controls.Add(this.textBox52);
            this.tabPage3.Controls.Add(this.textBox58);
            this.tabPage3.Controls.Add(this.textBox56);
            this.tabPage3.Controls.Add(this.textBox65);
            this.tabPage3.Controls.Add(this.textBox48);
            this.tabPage3.Controls.Add(this.textBox50);
            this.tabPage3.Controls.Add(this.textBox68);
            this.tabPage3.Controls.Add(this.textBox61);
            this.tabPage3.Controls.Add(this.textBox60);
            this.tabPage3.Controls.Add(this.textBox44);
            this.tabPage3.Controls.Add(this.textBox51);
            this.tabPage3.Controls.Add(this.textBox47);
            this.tabPage3.Controls.Add(this.textBox46);
            this.tabPage3.Controls.Add(this.textBox45);
            this.tabPage3.Controls.Add(this.textBox49);
            this.tabPage3.Controls.Add(this.textBox57);
            this.tabPage3.Controls.Add(this.textBox55);
            this.tabPage3.Controls.Add(this.textBox64);
            this.tabPage3.Controls.Add(this.textBox63);
            this.tabPage3.Controls.Add(this.textBox62);
            this.tabPage3.Controls.Add(this.textBox59);
            this.tabPage3.Controls.Add(this.textBox43);
            this.tabPage3.Controls.Add(this.label79);
            this.tabPage3.Controls.Add(this.label87);
            this.tabPage3.Controls.Add(this.label77);
            this.tabPage3.Controls.Add(this.label82);
            this.tabPage3.Controls.Add(this.label97);
            this.tabPage3.Controls.Add(this.label91);
            this.tabPage3.Controls.Add(this.label90);
            this.tabPage3.Controls.Add(this.label96);
            this.tabPage3.Controls.Add(this.label74);
            this.tabPage3.Controls.Add(this.label70);
            this.tabPage3.Controls.Add(this.label73);
            this.tabPage3.Controls.Add(this.label71);
            this.tabPage3.Controls.Add(this.label78);
            this.tabPage3.Controls.Add(this.label76);
            this.tabPage3.Controls.Add(this.label86);
            this.tabPage3.Controls.Add(this.label72);
            this.tabPage3.Controls.Add(this.label95);
            this.tabPage3.Controls.Add(this.label94);
            this.tabPage3.Controls.Add(this.label93);
            this.tabPage3.Controls.Add(this.label89);
            this.tabPage3.Controls.Add(this.label81);
            this.tabPage3.Controls.Add(this.label69);
            this.tabPage3.Controls.Add(this.label88);
            this.tabPage3.Controls.Add(this.label85);
            this.tabPage3.Controls.Add(this.label84);
            this.tabPage3.Controls.Add(this.label83);
            this.tabPage3.Controls.Add(this.label80);
            this.tabPage3.Controls.Add(this.label138);
            this.tabPage3.Controls.Add(this.label137);
            this.tabPage3.Controls.Add(this.label68);
            this.tabPage3.Controls.Add(this.label75);
            this.tabPage3.Controls.Add(this.label67);
            this.tabPage3.Controls.Add(this.label66);
            this.tabPage3.Location = new System.Drawing.Point(4, 23);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(987, 615);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Página 3";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // textBox69
            // 
            this.textBox69.Location = new System.Drawing.Point(10, 540);
            this.textBox69.Multiline = true;
            this.textBox69.Name = "textBox69";
            this.textBox69.Size = new System.Drawing.Size(829, 50);
            this.textBox69.TabIndex = 24;
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label92.Location = new System.Drawing.Point(7, 523);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(168, 14);
            this.label92.TabIndex = 9;
            this.label92.Text = "MOVIMIENTOS OCULARES:";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "POSITIVO",
            "NEGATIVO"});
            this.comboBox2.Location = new System.Drawing.Point(504, 44);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 22);
            this.comboBox2.TabIndex = 1;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "POSITIVO",
            "NEGATIVO"});
            this.comboBox1.Location = new System.Drawing.Point(100, 44);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 22);
            this.comboBox1.TabIndex = 0;
            // 
            // textBox52
            // 
            this.textBox52.Location = new System.Drawing.Point(498, 224);
            this.textBox52.Name = "textBox52";
            this.textBox52.Size = new System.Drawing.Size(341, 22);
            this.textBox52.TabIndex = 12;
            // 
            // textBox58
            // 
            this.textBox58.Location = new System.Drawing.Point(498, 338);
            this.textBox58.Name = "textBox58";
            this.textBox58.Size = new System.Drawing.Size(341, 22);
            this.textBox58.TabIndex = 15;
            // 
            // textBox56
            // 
            this.textBox56.Location = new System.Drawing.Point(498, 252);
            this.textBox56.Name = "textBox56";
            this.textBox56.Size = new System.Drawing.Size(341, 22);
            this.textBox56.TabIndex = 13;
            // 
            // textBox65
            // 
            this.textBox65.Location = new System.Drawing.Point(498, 424);
            this.textBox65.Name = "textBox65";
            this.textBox65.Size = new System.Drawing.Size(147, 22);
            this.textBox65.TabIndex = 21;
            // 
            // textBox48
            // 
            this.textBox48.Location = new System.Drawing.Point(498, 139);
            this.textBox48.Name = "textBox48";
            this.textBox48.Size = new System.Drawing.Size(144, 22);
            this.textBox48.TabIndex = 6;
            // 
            // textBox50
            // 
            this.textBox50.Location = new System.Drawing.Point(46, 224);
            this.textBox50.Name = "textBox50";
            this.textBox50.Size = new System.Drawing.Size(387, 22);
            this.textBox50.TabIndex = 9;
            // 
            // textBox68
            // 
            this.textBox68.Location = new System.Drawing.Point(362, 452);
            this.textBox68.Multiline = true;
            this.textBox68.Name = "textBox68";
            this.textBox68.Size = new System.Drawing.Size(477, 76);
            this.textBox68.TabIndex = 23;
            // 
            // textBox61
            // 
            this.textBox61.Location = new System.Drawing.Point(43, 452);
            this.textBox61.Name = "textBox61";
            this.textBox61.Size = new System.Drawing.Size(201, 22);
            this.textBox61.TabIndex = 18;
            // 
            // textBox60
            // 
            this.textBox60.Location = new System.Drawing.Point(43, 424);
            this.textBox60.Name = "textBox60";
            this.textBox60.Size = new System.Drawing.Size(201, 22);
            this.textBox60.TabIndex = 17;
            // 
            // textBox44
            // 
            this.textBox44.Location = new System.Drawing.Point(100, 139);
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(144, 22);
            this.textBox44.TabIndex = 3;
            // 
            // textBox51
            // 
            this.textBox51.Location = new System.Drawing.Point(498, 196);
            this.textBox51.Name = "textBox51";
            this.textBox51.Size = new System.Drawing.Size(341, 22);
            this.textBox51.TabIndex = 11;
            // 
            // textBox47
            // 
            this.textBox47.Location = new System.Drawing.Point(687, 111);
            this.textBox47.Multiline = true;
            this.textBox47.Name = "textBox47";
            this.textBox47.Size = new System.Drawing.Size(152, 50);
            this.textBox47.TabIndex = 7;
            // 
            // textBox46
            // 
            this.textBox46.Location = new System.Drawing.Point(498, 111);
            this.textBox46.Name = "textBox46";
            this.textBox46.Size = new System.Drawing.Size(144, 22);
            this.textBox46.TabIndex = 5;
            // 
            // textBox45
            // 
            this.textBox45.Location = new System.Drawing.Point(289, 111);
            this.textBox45.Multiline = true;
            this.textBox45.Name = "textBox45";
            this.textBox45.Size = new System.Drawing.Size(144, 50);
            this.textBox45.TabIndex = 4;
            // 
            // textBox49
            // 
            this.textBox49.Location = new System.Drawing.Point(46, 196);
            this.textBox49.Name = "textBox49";
            this.textBox49.Size = new System.Drawing.Size(387, 22);
            this.textBox49.TabIndex = 8;
            // 
            // textBox57
            // 
            this.textBox57.Location = new System.Drawing.Point(41, 338);
            this.textBox57.Name = "textBox57";
            this.textBox57.Size = new System.Drawing.Size(392, 22);
            this.textBox57.TabIndex = 14;
            // 
            // textBox55
            // 
            this.textBox55.Location = new System.Drawing.Point(95, 252);
            this.textBox55.Name = "textBox55";
            this.textBox55.Size = new System.Drawing.Size(338, 22);
            this.textBox55.TabIndex = 10;
            // 
            // textBox64
            // 
            this.textBox64.Location = new System.Drawing.Point(689, 396);
            this.textBox64.Multiline = true;
            this.textBox64.Name = "textBox64";
            this.textBox64.Size = new System.Drawing.Size(150, 50);
            this.textBox64.TabIndex = 22;
            // 
            // textBox63
            // 
            this.textBox63.Location = new System.Drawing.Point(498, 396);
            this.textBox63.Name = "textBox63";
            this.textBox63.Size = new System.Drawing.Size(147, 22);
            this.textBox63.TabIndex = 20;
            // 
            // textBox62
            // 
            this.textBox62.Location = new System.Drawing.Point(286, 396);
            this.textBox62.Multiline = true;
            this.textBox62.Name = "textBox62";
            this.textBox62.Size = new System.Drawing.Size(147, 50);
            this.textBox62.TabIndex = 19;
            // 
            // textBox59
            // 
            this.textBox59.Location = new System.Drawing.Point(43, 396);
            this.textBox59.Name = "textBox59";
            this.textBox59.Size = new System.Drawing.Size(201, 22);
            this.textBox59.TabIndex = 16;
            // 
            // textBox43
            // 
            this.textBox43.Location = new System.Drawing.Point(100, 111);
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(144, 22);
            this.textBox43.TabIndex = 2;
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label79.Location = new System.Drawing.Point(457, 232);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(35, 14);
            this.label79.TabIndex = 5;
            this.label79.Text = "ADD:";
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label87.Location = new System.Drawing.Point(468, 346);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(24, 14);
            this.label87.TabIndex = 5;
            this.label87.Text = "OI:";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label77.Location = new System.Drawing.Point(7, 232);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(24, 14);
            this.label77.TabIndex = 5;
            this.label77.Text = "OI:";
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label82.Location = new System.Drawing.Point(468, 260);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(24, 14);
            this.label82.TabIndex = 5;
            this.label82.Text = "OI:";
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label97.Location = new System.Drawing.Point(250, 460);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(106, 14);
            this.label97.TabIndex = 5;
            this.label97.Text = "OBSERVACIONES:";
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label91.Location = new System.Drawing.Point(7, 460);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(30, 14);
            this.label91.TabIndex = 5;
            this.label91.Text = "DIP:";
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label90.Location = new System.Drawing.Point(7, 432);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(24, 14);
            this.label90.TabIndex = 5;
            this.label90.Text = "OI:";
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label96.Location = new System.Drawing.Point(468, 432);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(24, 14);
            this.label96.TabIndex = 5;
            this.label96.Text = "OI:";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label74.Location = new System.Drawing.Point(468, 147);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(24, 14);
            this.label74.TabIndex = 5;
            this.label74.Text = "OI:";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label70.Location = new System.Drawing.Point(65, 147);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(24, 14);
            this.label70.TabIndex = 5;
            this.label70.Text = "OI:";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label73.Location = new System.Drawing.Point(648, 119);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(33, 14);
            this.label73.TabIndex = 5;
            this.label73.Text = "EST:";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label71.Location = new System.Drawing.Point(250, 119);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(33, 14);
            this.label71.TabIndex = 5;
            this.label71.Text = "EST:";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label78.Location = new System.Drawing.Point(457, 204);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(35, 14);
            this.label78.TabIndex = 5;
            this.label78.Text = "ADD:";
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label76.Location = new System.Drawing.Point(7, 204);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(28, 14);
            this.label76.TabIndex = 5;
            this.label76.Text = "OD:";
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label86.Location = new System.Drawing.Point(7, 346);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(28, 14);
            this.label86.TabIndex = 5;
            this.label86.Text = "OD:";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label72.Location = new System.Drawing.Point(450, 119);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(42, 14);
            this.label72.TabIndex = 5;
            this.label72.Text = "CCOD:";
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label95.Location = new System.Drawing.Point(655, 404);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(26, 14);
            this.label95.TabIndex = 5;
            this.label95.Text = "VC:";
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label94.Location = new System.Drawing.Point(440, 404);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(52, 14);
            this.label94.TabIndex = 5;
            this.label94.Text = "ADDOD:";
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label93.Location = new System.Drawing.Point(250, 404);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(26, 14);
            this.label93.TabIndex = 5;
            this.label93.Text = "CV:";
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label89.Location = new System.Drawing.Point(7, 404);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(28, 14);
            this.label89.TabIndex = 5;
            this.label89.Text = "OD:";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label81.Location = new System.Drawing.Point(61, 260);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(28, 14);
            this.label81.TabIndex = 5;
            this.label81.Text = "OD:";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label69.Location = new System.Drawing.Point(61, 119);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(28, 14);
            this.label69.TabIndex = 5;
            this.label69.Text = "OD:";
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label88.Location = new System.Drawing.Point(7, 372);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(62, 14);
            this.label88.TabIndex = 5;
            this.label88.Text = "Subjetivo:";
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label85.Location = new System.Drawing.Point(7, 316);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(57, 14);
            this.label85.TabIndex = 5;
            this.label85.Text = "Objetivo:";
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label84.Location = new System.Drawing.Point(92, 293);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(89, 14);
            this.label84.TabIndex = 5;
            this.label84.Text = "(Retinoscopia):";
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label83.Location = new System.Drawing.Point(7, 293);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(81, 14);
            this.label83.TabIndex = 5;
            this.label83.Text = "REFRACCION:";
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label80.Location = new System.Drawing.Point(7, 260);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(25, 14);
            this.label80.TabIndex = 5;
            this.label80.Text = "QM";
            // 
            // label138
            // 
            this.label138.AutoSize = true;
            this.label138.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label138.Location = new System.Drawing.Point(438, 52);
            this.label138.Name = "label138";
            this.label138.Size = new System.Drawing.Size(54, 14);
            this.label138.TabIndex = 5;
            this.label138.Text = "Figura 2:";
            // 
            // label137
            // 
            this.label137.AutoSize = true;
            this.label137.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label137.Location = new System.Drawing.Point(34, 52);
            this.label137.Name = "label137";
            this.label137.Size = new System.Drawing.Size(54, 14);
            this.label137.TabIndex = 5;
            this.label137.Text = "Figura 1:";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label68.Location = new System.Drawing.Point(7, 119);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(37, 14);
            this.label68.TabIndex = 5;
            this.label68.Text = "AVSC";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label75.Location = new System.Drawing.Point(7, 177);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(98, 14);
            this.label75.TabIndex = 4;
            this.label75.Text = "LENSOMETRIA:";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label67.Location = new System.Drawing.Point(7, 94);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(199, 14);
            this.label67.TabIndex = 4;
            this.label67.Text = "EXPLORACION OFTAMOLOGICA:";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label66.Location = new System.Drawing.Point(7, 10);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(62, 14);
            this.label66.TabIndex = 4;
            this.label66.Text = "AMSLER:";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.pbpp2);
            this.tabPage4.Controls.Add(this.pbbiomicro2);
            this.tabPage4.Controls.Add(this.pbpp1);
            this.tabPage4.Controls.Add(this.pbbiomicro1);
            this.tabPage4.Controls.Add(this.label99);
            this.tabPage4.Controls.Add(this.label98);
            this.tabPage4.Location = new System.Drawing.Point(4, 23);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(987, 615);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Página 4";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // pbpp2
            // 
            this.pbpp2.Image = ((System.Drawing.Image)(resources.GetObject("pbpp2.Image")));
            this.pbpp2.Location = new System.Drawing.Point(420, 64);
            this.pbpp2.Name = "pbpp2";
            this.pbpp2.Size = new System.Drawing.Size(370, 218);
            this.pbpp2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbpp2.TabIndex = 6;
            this.pbpp2.TabStop = false;
            // 
            // pbbiomicro2
            // 
            this.pbbiomicro2.Image = ((System.Drawing.Image)(resources.GetObject("pbbiomicro2.Image")));
            this.pbbiomicro2.Location = new System.Drawing.Point(420, 324);
            this.pbbiomicro2.Name = "pbbiomicro2";
            this.pbbiomicro2.Size = new System.Drawing.Size(370, 218);
            this.pbbiomicro2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbbiomicro2.TabIndex = 6;
            this.pbbiomicro2.TabStop = false;
            // 
            // pbpp1
            // 
            this.pbpp1.Image = ((System.Drawing.Image)(resources.GetObject("pbpp1.Image")));
            this.pbpp1.Location = new System.Drawing.Point(10, 64);
            this.pbpp1.Name = "pbpp1";
            this.pbpp1.Size = new System.Drawing.Size(370, 218);
            this.pbpp1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbpp1.TabIndex = 6;
            this.pbpp1.TabStop = false;
            // 
            // pbbiomicro1
            // 
            this.pbbiomicro1.Image = ((System.Drawing.Image)(resources.GetObject("pbbiomicro1.Image")));
            this.pbbiomicro1.Location = new System.Drawing.Point(10, 324);
            this.pbbiomicro1.Name = "pbbiomicro1";
            this.pbbiomicro1.Size = new System.Drawing.Size(370, 218);
            this.pbbiomicro1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbbiomicro1.TabIndex = 6;
            this.pbbiomicro1.TabStop = false;
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label99.Location = new System.Drawing.Point(7, 296);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(122, 14);
            this.label99.TabIndex = 5;
            this.label99.Text = "BIOMICROSCOPIA:";
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label98.Location = new System.Drawing.Point(7, 35);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(260, 14);
            this.label98.TabIndex = 5;
            this.label98.Text = "PARPADOS VIAS LAGRIMALES Y ORBITA:";
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.textBox78);
            this.tabPage5.Controls.Add(this.textBox77);
            this.tabPage5.Controls.Add(this.textBox75);
            this.tabPage5.Controls.Add(this.textBox74);
            this.tabPage5.Controls.Add(this.textBox73);
            this.tabPage5.Controls.Add(this.textBox72);
            this.tabPage5.Controls.Add(this.textBox71);
            this.tabPage5.Controls.Add(this.textBox76);
            this.tabPage5.Controls.Add(this.textBox70);
            this.tabPage5.Controls.Add(this.angulo2);
            this.tabPage5.Controls.Add(this.pbcristalinooi);
            this.tabPage5.Controls.Add(this.angulo1);
            this.tabPage5.Controls.Add(this.pbcristalinood);
            this.tabPage5.Controls.Add(this.label103);
            this.tabPage5.Controls.Add(this.label102);
            this.tabPage5.Controls.Add(this.label113);
            this.tabPage5.Controls.Add(this.label112);
            this.tabPage5.Controls.Add(this.label108);
            this.tabPage5.Controls.Add(this.label107);
            this.tabPage5.Controls.Add(this.label106);
            this.tabPage5.Controls.Add(this.label109);
            this.tabPage5.Controls.Add(this.label105);
            this.tabPage5.Controls.Add(this.label111);
            this.tabPage5.Controls.Add(this.label101);
            this.tabPage5.Controls.Add(this.label110);
            this.tabPage5.Controls.Add(this.label114);
            this.tabPage5.Controls.Add(this.label104);
            this.tabPage5.Controls.Add(this.label100);
            this.tabPage5.Location = new System.Drawing.Point(4, 23);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(987, 615);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Página 5";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // textBox78
            // 
            this.textBox78.Location = new System.Drawing.Point(444, 368);
            this.textBox78.Name = "textBox78";
            this.textBox78.Size = new System.Drawing.Size(373, 22);
            this.textBox78.TabIndex = 8;
            // 
            // textBox77
            // 
            this.textBox77.Location = new System.Drawing.Point(444, 340);
            this.textBox77.Name = "textBox77";
            this.textBox77.Size = new System.Drawing.Size(373, 22);
            this.textBox77.TabIndex = 7;
            // 
            // textBox75
            // 
            this.textBox75.Location = new System.Drawing.Point(440, 86);
            this.textBox75.Name = "textBox75";
            this.textBox75.Size = new System.Drawing.Size(377, 22);
            this.textBox75.TabIndex = 5;
            // 
            // textBox74
            // 
            this.textBox74.Location = new System.Drawing.Point(440, 58);
            this.textBox74.Name = "textBox74";
            this.textBox74.Size = new System.Drawing.Size(377, 22);
            this.textBox74.TabIndex = 3;
            // 
            // textBox73
            // 
            this.textBox73.Location = new System.Drawing.Point(440, 30);
            this.textBox73.Name = "textBox73";
            this.textBox73.Size = new System.Drawing.Size(377, 22);
            this.textBox73.TabIndex = 1;
            // 
            // textBox72
            // 
            this.textBox72.Location = new System.Drawing.Point(127, 30);
            this.textBox72.Name = "textBox72";
            this.textBox72.Size = new System.Drawing.Size(277, 22);
            this.textBox72.TabIndex = 0;
            // 
            // textBox71
            // 
            this.textBox71.Location = new System.Drawing.Point(127, 58);
            this.textBox71.Name = "textBox71";
            this.textBox71.Size = new System.Drawing.Size(277, 22);
            this.textBox71.TabIndex = 2;
            // 
            // textBox76
            // 
            this.textBox76.Location = new System.Drawing.Point(217, 340);
            this.textBox76.Name = "textBox76";
            this.textBox76.Size = new System.Drawing.Size(187, 22);
            this.textBox76.TabIndex = 6;
            // 
            // textBox70
            // 
            this.textBox70.Location = new System.Drawing.Point(183, 86);
            this.textBox70.Name = "textBox70";
            this.textBox70.Size = new System.Drawing.Size(221, 22);
            this.textBox70.TabIndex = 4;
            // 
            // angulo2
            // 
            this.angulo2.Image = ((System.Drawing.Image)(resources.GetObject("angulo2.Image")));
            this.angulo2.Location = new System.Drawing.Point(452, 432);
            this.angulo2.Name = "angulo2";
            this.angulo2.Size = new System.Drawing.Size(248, 140);
            this.angulo2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.angulo2.TabIndex = 7;
            this.angulo2.TabStop = false;
            // 
            // pbcristalinooi
            // 
            this.pbcristalinooi.Image = ((System.Drawing.Image)(resources.GetObject("pbcristalinooi.Image")));
            this.pbcristalinooi.Location = new System.Drawing.Point(451, 164);
            this.pbcristalinooi.Name = "pbcristalinooi";
            this.pbcristalinooi.Size = new System.Drawing.Size(248, 140);
            this.pbcristalinooi.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbcristalinooi.TabIndex = 7;
            this.pbcristalinooi.TabStop = false;
            // 
            // angulo1
            // 
            this.angulo1.Image = ((System.Drawing.Image)(resources.GetObject("angulo1.Image")));
            this.angulo1.Location = new System.Drawing.Point(49, 432);
            this.angulo1.Name = "angulo1";
            this.angulo1.Size = new System.Drawing.Size(248, 140);
            this.angulo1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.angulo1.TabIndex = 7;
            this.angulo1.TabStop = false;
            // 
            // pbcristalinood
            // 
            this.pbcristalinood.Image = ((System.Drawing.Image)(resources.GetObject("pbcristalinood.Image")));
            this.pbcristalinood.Location = new System.Drawing.Point(48, 164);
            this.pbcristalinood.Name = "pbcristalinood";
            this.pbcristalinood.Size = new System.Drawing.Size(248, 140);
            this.pbcristalinood.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbcristalinood.TabIndex = 7;
            this.pbcristalinood.TabStop = false;
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label103.Location = new System.Drawing.Point(7, 94);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(170, 14);
            this.label103.TabIndex = 6;
            this.label103.Text = "DEF. PUPILAR AFERENTE OD:";
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label102.Location = new System.Drawing.Point(8, 66);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(107, 14);
            this.label102.TabIndex = 6;
            this.label102.Text = "CONSENSUAL OD:";
            // 
            // label113
            // 
            this.label113.AutoSize = true;
            this.label113.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label113.Location = new System.Drawing.Point(414, 376);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(24, 14);
            this.label113.TabIndex = 6;
            this.label113.Text = "OI:";
            // 
            // label112
            // 
            this.label112.AutoSize = true;
            this.label112.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label112.Location = new System.Drawing.Point(410, 348);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(28, 14);
            this.label112.TabIndex = 6;
            this.label112.Text = "OD:";
            // 
            // label108
            // 
            this.label108.AutoSize = true;
            this.label108.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label108.Location = new System.Drawing.Point(410, 94);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(24, 14);
            this.label108.TabIndex = 6;
            this.label108.Text = "OI:";
            // 
            // label107
            // 
            this.label107.AutoSize = true;
            this.label107.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label107.Location = new System.Drawing.Point(410, 66);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(24, 14);
            this.label107.TabIndex = 6;
            this.label107.Text = "OI:";
            // 
            // label106
            // 
            this.label106.AutoSize = true;
            this.label106.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label106.Location = new System.Drawing.Point(410, 38);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(24, 14);
            this.label106.TabIndex = 6;
            this.label106.Text = "OI:";
            // 
            // label109
            // 
            this.label109.AutoSize = true;
            this.label109.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label109.Location = new System.Drawing.Point(410, 147);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(24, 14);
            this.label109.TabIndex = 6;
            this.label109.Text = "OI:";
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label105.Location = new System.Drawing.Point(7, 147);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(28, 14);
            this.label105.TabIndex = 6;
            this.label105.Text = "OD:";
            // 
            // label111
            // 
            this.label111.AutoSize = true;
            this.label111.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label111.Location = new System.Drawing.Point(7, 348);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(204, 14);
            this.label111.TabIndex = 6;
            this.label111.Text = "APLANACION INDENTACION OTRO:";
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label101.Location = new System.Drawing.Point(8, 38);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(106, 14);
            this.label101.TabIndex = 6;
            this.label101.Text = "FOTOMOTOR OD:";
            // 
            // label110
            // 
            this.label110.AutoSize = true;
            this.label110.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label110.Location = new System.Drawing.Point(7, 323);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(34, 14);
            this.label110.TabIndex = 6;
            this.label110.Text = "T/O:";
            // 
            // label114
            // 
            this.label114.AutoSize = true;
            this.label114.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label114.Location = new System.Drawing.Point(8, 392);
            this.label114.Name = "label114";
            this.label114.Size = new System.Drawing.Size(60, 14);
            this.label114.TabIndex = 6;
            this.label114.Text = "ANGULO:";
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label104.Location = new System.Drawing.Point(7, 124);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(86, 14);
            this.label104.TabIndex = 6;
            this.label104.Text = "CRISTALINO:";
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label100.Location = new System.Drawing.Point(7, 14);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(70, 14);
            this.label100.TabIndex = 6;
            this.label100.Text = "REFLEJOS:";
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.comboBox8);
            this.tabPage6.Controls.Add(this.comboBox5);
            this.tabPage6.Controls.Add(this.comboBox7);
            this.tabPage6.Controls.Add(this.comboBox4);
            this.tabPage6.Controls.Add(this.comboBox6);
            this.tabPage6.Controls.Add(this.comboBox3);
            this.tabPage6.Controls.Add(this.textBox88);
            this.tabPage6.Controls.Add(this.textBox87);
            this.tabPage6.Controls.Add(this.textBox94);
            this.tabPage6.Controls.Add(this.textBox86);
            this.tabPage6.Controls.Add(this.textBox93);
            this.tabPage6.Controls.Add(this.textBox91);
            this.tabPage6.Controls.Add(this.textBox89);
            this.tabPage6.Controls.Add(this.textBox90);
            this.tabPage6.Controls.Add(this.textBox85);
            this.tabPage6.Controls.Add(this.label127);
            this.tabPage6.Controls.Add(this.label125);
            this.tabPage6.Controls.Add(this.label121);
            this.tabPage6.Controls.Add(this.textBox92);
            this.tabPage6.Controls.Add(this.label124);
            this.tabPage6.Controls.Add(this.label120);
            this.tabPage6.Controls.Add(this.label132);
            this.tabPage6.Controls.Add(this.label116);
            this.tabPage6.Controls.Add(this.label129);
            this.tabPage6.Controls.Add(this.label126);
            this.tabPage6.Controls.Add(this.label128);
            this.tabPage6.Controls.Add(this.label123);
            this.tabPage6.Controls.Add(this.label119);
            this.tabPage6.Controls.Add(this.label131);
            this.tabPage6.Controls.Add(this.label117);
            this.tabPage6.Controls.Add(this.label130);
            this.tabPage6.Controls.Add(this.label140);
            this.tabPage6.Controls.Add(this.label139);
            this.tabPage6.Controls.Add(this.label118);
            this.tabPage6.Controls.Add(this.label133);
            this.tabPage6.Controls.Add(this.label122);
            this.tabPage6.Controls.Add(this.label115);
            this.tabPage6.Controls.Add(this.retina2);
            this.tabPage6.Controls.Add(this.retina1);
            this.tabPage6.Location = new System.Drawing.Point(4, 23);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(987, 615);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Página 6";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // comboBox8
            // 
            this.comboBox8.FormattingEnabled = true;
            this.comboBox8.Items.AddRange(new object[] {
            "DISMINUIDO",
            "NORMAL"});
            this.comboBox8.Location = new System.Drawing.Point(447, 102);
            this.comboBox8.Name = "comboBox8";
            this.comboBox8.Size = new System.Drawing.Size(141, 22);
            this.comboBox8.TabIndex = 5;
            // 
            // comboBox5
            // 
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Items.AddRange(new object[] {
            "DISMINUIDO",
            "NORMAL"});
            this.comboBox5.Location = new System.Drawing.Point(118, 102);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(141, 22);
            this.comboBox5.TabIndex = 2;
            // 
            // comboBox7
            // 
            this.comboBox7.FormattingEnabled = true;
            this.comboBox7.Items.AddRange(new object[] {
            "PALIDO",
            "NORMAL"});
            this.comboBox7.Location = new System.Drawing.Point(448, 74);
            this.comboBox7.Name = "comboBox7";
            this.comboBox7.Size = new System.Drawing.Size(141, 22);
            this.comboBox7.TabIndex = 4;
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Items.AddRange(new object[] {
            "PALIDO",
            "NORMAL"});
            this.comboBox4.Location = new System.Drawing.Point(119, 74);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(141, 22);
            this.comboBox4.TabIndex = 1;
            // 
            // comboBox6
            // 
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Items.AddRange(new object[] {
            "10",
            "20",
            "30",
            "40",
            "50",
            "60",
            "70",
            "80",
            "90",
            "100"});
            this.comboBox6.Location = new System.Drawing.Point(447, 46);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(141, 22);
            this.comboBox6.TabIndex = 3;
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "10",
            "20",
            "30",
            "40",
            "50",
            "60",
            "70",
            "80",
            "90",
            "100"});
            this.comboBox3.Location = new System.Drawing.Point(118, 46);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(141, 22);
            this.comboBox3.TabIndex = 0;
            // 
            // textBox88
            // 
            this.textBox88.Location = new System.Drawing.Point(119, 285);
            this.textBox88.Name = "textBox88";
            this.textBox88.Size = new System.Drawing.Size(276, 22);
            this.textBox88.TabIndex = 10;
            // 
            // textBox87
            // 
            this.textBox87.Location = new System.Drawing.Point(118, 257);
            this.textBox87.Name = "textBox87";
            this.textBox87.Size = new System.Drawing.Size(277, 22);
            this.textBox87.TabIndex = 9;
            // 
            // textBox94
            // 
            this.textBox94.Location = new System.Drawing.Point(447, 286);
            this.textBox94.Name = "textBox94";
            this.textBox94.Size = new System.Drawing.Size(363, 22);
            this.textBox94.TabIndex = 15;
            // 
            // textBox86
            // 
            this.textBox86.Location = new System.Drawing.Point(119, 229);
            this.textBox86.Name = "textBox86";
            this.textBox86.Size = new System.Drawing.Size(276, 22);
            this.textBox86.TabIndex = 8;
            // 
            // textBox93
            // 
            this.textBox93.Location = new System.Drawing.Point(447, 258);
            this.textBox93.Name = "textBox93";
            this.textBox93.Size = new System.Drawing.Size(363, 22);
            this.textBox93.TabIndex = 14;
            // 
            // textBox91
            // 
            this.textBox91.Location = new System.Drawing.Point(661, 196);
            this.textBox91.Name = "textBox91";
            this.textBox91.Size = new System.Drawing.Size(149, 22);
            this.textBox91.TabIndex = 12;
            // 
            // textBox89
            // 
            this.textBox89.Location = new System.Drawing.Point(286, 201);
            this.textBox89.Name = "textBox89";
            this.textBox89.Size = new System.Drawing.Size(109, 22);
            this.textBox89.TabIndex = 7;
            // 
            // textBox90
            // 
            this.textBox90.Location = new System.Drawing.Point(494, 196);
            this.textBox90.Name = "textBox90";
            this.textBox90.Size = new System.Drawing.Size(109, 22);
            this.textBox90.TabIndex = 11;
            // 
            // textBox85
            // 
            this.textBox85.Location = new System.Drawing.Point(119, 201);
            this.textBox85.Name = "textBox85";
            this.textBox85.Size = new System.Drawing.Size(109, 22);
            this.textBox85.TabIndex = 6;
            // 
            // label127
            // 
            this.label127.AutoSize = true;
            this.label127.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label127.Location = new System.Drawing.Point(7, 291);
            this.label127.Name = "label127";
            this.label127.Size = new System.Drawing.Size(86, 14);
            this.label127.TabIndex = 9;
            this.label127.Text = "HEMORRAGIA:";
            // 
            // label125
            // 
            this.label125.AutoSize = true;
            this.label125.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label125.Location = new System.Drawing.Point(7, 264);
            this.label125.Name = "label125";
            this.label125.Size = new System.Drawing.Size(64, 14);
            this.label125.TabIndex = 9;
            this.label125.Text = "HIALOSIS:";
            // 
            // label121
            // 
            this.label121.AutoSize = true;
            this.label121.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label121.Location = new System.Drawing.Point(7, 109);
            this.label121.Name = "label121";
            this.label121.Size = new System.Drawing.Size(77, 14);
            this.label121.TabIndex = 9;
            this.label121.Text = "BORDES OD:";
            // 
            // textBox92
            // 
            this.textBox92.Location = new System.Drawing.Point(447, 230);
            this.textBox92.Name = "textBox92";
            this.textBox92.Size = new System.Drawing.Size(363, 22);
            this.textBox92.TabIndex = 13;
            // 
            // label124
            // 
            this.label124.AutoSize = true;
            this.label124.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label124.Location = new System.Drawing.Point(7, 238);
            this.label124.Name = "label124";
            this.label124.Size = new System.Drawing.Size(69, 14);
            this.label124.TabIndex = 10;
            this.label124.Text = "SINERESIS:";
            // 
            // label120
            // 
            this.label120.AutoSize = true;
            this.label120.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label120.Location = new System.Drawing.Point(7, 83);
            this.label120.Name = "label120";
            this.label120.Size = new System.Drawing.Size(106, 14);
            this.label120.TabIndex = 10;
            this.label120.Text = "COLORACION OD:";
            // 
            // label132
            // 
            this.label132.AutoSize = true;
            this.label132.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label132.Location = new System.Drawing.Point(417, 294);
            this.label132.Name = "label132";
            this.label132.Size = new System.Drawing.Size(24, 14);
            this.label132.TabIndex = 9;
            this.label132.Text = "OI:";
            // 
            // label116
            // 
            this.label116.AutoSize = true;
            this.label116.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label116.Location = new System.Drawing.Point(417, 110);
            this.label116.Name = "label116";
            this.label116.Size = new System.Drawing.Size(24, 14);
            this.label116.TabIndex = 9;
            this.label116.Text = "OI:";
            // 
            // label129
            // 
            this.label129.AutoSize = true;
            this.label129.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label129.Location = new System.Drawing.Point(609, 204);
            this.label129.Name = "label129";
            this.label129.Size = new System.Drawing.Size(46, 14);
            this.label129.TabIndex = 11;
            this.label129.Text = "TOTAL";
            // 
            // label126
            // 
            this.label126.AutoSize = true;
            this.label126.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label126.Location = new System.Drawing.Point(234, 209);
            this.label126.Name = "label126";
            this.label126.Size = new System.Drawing.Size(46, 14);
            this.label126.TabIndex = 11;
            this.label126.Text = "TOTAL";
            // 
            // label128
            // 
            this.label128.AutoSize = true;
            this.label128.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label128.Location = new System.Drawing.Point(417, 204);
            this.label128.Name = "label128";
            this.label128.Size = new System.Drawing.Size(71, 14);
            this.label128.TabIndex = 11;
            this.label128.Text = "OI PARCIAL";
            // 
            // label123
            // 
            this.label123.AutoSize = true;
            this.label123.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label123.Location = new System.Drawing.Point(7, 209);
            this.label123.Name = "label123";
            this.label123.Size = new System.Drawing.Size(106, 14);
            this.label123.TabIndex = 11;
            this.label123.Text = "DPV OD: PARCIAL";
            // 
            // label119
            // 
            this.label119.AutoSize = true;
            this.label119.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label119.Location = new System.Drawing.Point(7, 54);
            this.label119.Name = "label119";
            this.label119.Size = new System.Drawing.Size(105, 14);
            this.label119.TabIndex = 11;
            this.label119.Text = "EXCAVACION OD:";
            // 
            // label131
            // 
            this.label131.AutoSize = true;
            this.label131.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label131.Location = new System.Drawing.Point(417, 266);
            this.label131.Name = "label131";
            this.label131.Size = new System.Drawing.Size(24, 14);
            this.label131.TabIndex = 10;
            this.label131.Text = "OI:";
            // 
            // label117
            // 
            this.label117.AutoSize = true;
            this.label117.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label117.Location = new System.Drawing.Point(417, 82);
            this.label117.Name = "label117";
            this.label117.Size = new System.Drawing.Size(24, 14);
            this.label117.TabIndex = 10;
            this.label117.Text = "OI:";
            // 
            // label130
            // 
            this.label130.AutoSize = true;
            this.label130.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label130.Location = new System.Drawing.Point(417, 238);
            this.label130.Name = "label130";
            this.label130.Size = new System.Drawing.Size(24, 14);
            this.label130.TabIndex = 11;
            this.label130.Text = "OI:";
            // 
            // label140
            // 
            this.label140.AutoSize = true;
            this.label140.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label140.Location = new System.Drawing.Point(594, 54);
            this.label140.Name = "label140";
            this.label140.Size = new System.Drawing.Size(19, 14);
            this.label140.TabIndex = 11;
            this.label140.Text = "%";
            // 
            // label139
            // 
            this.label139.AutoSize = true;
            this.label139.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label139.Location = new System.Drawing.Point(265, 54);
            this.label139.Name = "label139";
            this.label139.Size = new System.Drawing.Size(19, 14);
            this.label139.TabIndex = 11;
            this.label139.Text = "%";
            // 
            // label118
            // 
            this.label118.AutoSize = true;
            this.label118.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label118.Location = new System.Drawing.Point(417, 54);
            this.label118.Name = "label118";
            this.label118.Size = new System.Drawing.Size(24, 14);
            this.label118.TabIndex = 11;
            this.label118.Text = "OI:";
            // 
            // label133
            // 
            this.label133.AutoSize = true;
            this.label133.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label133.Location = new System.Drawing.Point(7, 335);
            this.label133.Name = "label133";
            this.label133.Size = new System.Drawing.Size(56, 14);
            this.label133.TabIndex = 7;
            this.label133.Text = "RETINA:";
            // 
            // label122
            // 
            this.label122.AutoSize = true;
            this.label122.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label122.Location = new System.Drawing.Point(7, 177);
            this.label122.Name = "label122";
            this.label122.Size = new System.Drawing.Size(56, 14);
            this.label122.TabIndex = 7;
            this.label122.Text = "VITREO:";
            // 
            // label115
            // 
            this.label115.AutoSize = true;
            this.label115.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label115.Location = new System.Drawing.Point(7, 12);
            this.label115.Name = "label115";
            this.label115.Size = new System.Drawing.Size(65, 14);
            this.label115.TabIndex = 7;
            this.label115.Text = "PAPILAS:";
            // 
            // retina2
            // 
            this.retina2.Image = ((System.Drawing.Image)(resources.GetObject("retina2.Image")));
            this.retina2.Location = new System.Drawing.Point(422, 369);
            this.retina2.Name = "retina2";
            this.retina2.Size = new System.Drawing.Size(368, 225);
            this.retina2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.retina2.TabIndex = 15;
            this.retina2.TabStop = false;
            // 
            // retina1
            // 
            this.retina1.Image = ((System.Drawing.Image)(resources.GetObject("retina1.Image")));
            this.retina1.Location = new System.Drawing.Point(27, 369);
            this.retina1.Name = "retina1";
            this.retina1.Size = new System.Drawing.Size(368, 225);
            this.retina1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.retina1.TabIndex = 15;
            this.retina1.TabStop = false;
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.textBox97);
            this.tabPage7.Controls.Add(this.textBox96);
            this.tabPage7.Controls.Add(this.textBox95);
            this.tabPage7.Controls.Add(this.label136);
            this.tabPage7.Controls.Add(this.label135);
            this.tabPage7.Controls.Add(this.label134);
            this.tabPage7.Location = new System.Drawing.Point(4, 23);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Size = new System.Drawing.Size(987, 615);
            this.tabPage7.TabIndex = 6;
            this.tabPage7.Text = "Página 7";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // textBox97
            // 
            this.textBox97.Location = new System.Drawing.Point(10, 278);
            this.textBox97.Multiline = true;
            this.textBox97.Name = "textBox97";
            this.textBox97.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox97.Size = new System.Drawing.Size(797, 297);
            this.textBox97.TabIndex = 2;
            // 
            // textBox96
            // 
            this.textBox96.Location = new System.Drawing.Point(10, 155);
            this.textBox96.Multiline = true;
            this.textBox96.Name = "textBox96";
            this.textBox96.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox96.Size = new System.Drawing.Size(797, 92);
            this.textBox96.TabIndex = 1;
            // 
            // textBox95
            // 
            this.textBox95.Location = new System.Drawing.Point(10, 30);
            this.textBox95.Multiline = true;
            this.textBox95.Name = "textBox95";
            this.textBox95.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox95.Size = new System.Drawing.Size(797, 92);
            this.textBox95.TabIndex = 0;
            // 
            // label136
            // 
            this.label136.AutoSize = true;
            this.label136.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label136.Location = new System.Drawing.Point(7, 261);
            this.label136.Name = "label136";
            this.label136.Size = new System.Drawing.Size(93, 14);
            this.label136.TabIndex = 8;
            this.label136.Text = "COMENTARIO:";
            // 
            // label135
            // 
            this.label135.AutoSize = true;
            this.label135.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label135.Location = new System.Drawing.Point(7, 138);
            this.label135.Name = "label135";
            this.label135.Size = new System.Drawing.Size(43, 14);
            this.label135.TabIndex = 8;
            this.label135.Text = "PLAN:";
            // 
            // label134
            // 
            this.label134.AutoSize = true;
            this.label134.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label134.Location = new System.Drawing.Point(7, 13);
            this.label134.Name = "label134";
            this.label134.Size = new System.Drawing.Size(96, 14);
            this.label134.TabIndex = 8;
            this.label134.Text = "DIAGNOSTICO:";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.lbNuevo);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.dateTimePicker1);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.lbEditar);
            this.panel1.Location = new System.Drawing.Point(1, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(856, 123);
            this.panel1.TabIndex = 0;
            // 
            // lbNuevo
            // 
            this.lbNuevo.Image = ((System.Drawing.Image)(resources.GetObject("lbNuevo.Image")));
            this.lbNuevo.Location = new System.Drawing.Point(274, 17);
            this.lbNuevo.Name = "lbNuevo";
            this.lbNuevo.Size = new System.Drawing.Size(25, 25);
            this.lbNuevo.TabIndex = 3;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(193, 17);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 1;
            this.button2.Text = "Buscar";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(424, 17);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(124, 22);
            this.dateTimePicker1.TabIndex = 2;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(82, 17);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 22);
            this.textBox1.TabIndex = 0;
            this.textBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(11, 89);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 14);
            this.label4.TabIndex = 0;
            this.label4.Text = "DOMICILIO:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(337, 42);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(71, 14);
            this.label15.TabIndex = 0;
            this.label15.Text = "TELEFONO:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(337, 65);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(78, 14);
            this.label9.TabIndex = 0;
            this.label9.Text = "OCUPACIÓN:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(190, 65);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 14);
            this.label8.TabIndex = 0;
            this.label8.Text = "SEXO:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(11, 65);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 14);
            this.label3.TabIndex = 0;
            this.label3.Text = "EDAD:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(84, 89);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(147, 14);
            this.label7.TabIndex = 0;
            this.label7.Text = "____________________";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(84, 65);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(84, 14);
            this.label6.TabIndex = 0;
            this.label6.Text = "___________";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(237, 65);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(84, 14);
            this.label12.TabIndex = 0;
            this.label12.Text = "___________";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(421, 65);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(84, 14);
            this.label13.TabIndex = 0;
            this.label13.Text = "___________";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(421, 42);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(84, 14);
            this.label16.TabIndex = 0;
            this.label16.Text = "___________";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(84, 42);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(147, 14);
            this.label5.TabIndex = 0;
            this.label5.Text = "____________________";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(11, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 14);
            this.label2.TabIndex = 0;
            this.label2.Text = "NOMBRE:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label14.Location = new System.Drawing.Point(629, 23);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(20, 16);
            this.label14.TabIndex = 0;
            this.label14.Text = "--";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(597, 23);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(26, 14);
            this.label10.TabIndex = 0;
            this.label10.Text = "No.";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(340, 23);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(47, 14);
            this.label11.TabIndex = 0;
            this.label11.Text = "FECHA:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(11, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 14);
            this.label1.TabIndex = 0;
            this.label1.Text = "CLAVE:";
            // 
            // lbEditar
            // 
            this.lbEditar.Image = ((System.Drawing.Image)(resources.GetObject("lbEditar.Image")));
            this.lbEditar.Location = new System.Drawing.Point(274, 17);
            this.lbEditar.Name = "lbEditar";
            this.lbEditar.Size = new System.Drawing.Size(25, 25);
            this.lbEditar.TabIndex = 3;
            this.lbEditar.Visible = false;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(682, 780);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 39);
            this.button1.TabIndex = 2;
            this.button1.Text = "Guardar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(771, 780);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 39);
            this.button3.TabIndex = 3;
            this.button3.Text = "Cancelar";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(601, 780);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 39);
            this.button4.TabIndex = 4;
            this.button4.Text = "Nuevo";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(520, 780);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 39);
            this.button5.TabIndex = 5;
            this.button5.Text = "Formato";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(1, 780);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 39);
            this.button6.TabIndex = 6;
            this.button6.Text = "Historial";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // HCOftalmologia
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            this.ClientSize = new System.Drawing.Size(1008, 889);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "HCOftalmologia";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Historia Clínica Oftalmología";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Activated += new System.EventHandler(this.HCOftalmologia_Activated);
            this.Load += new System.EventHandler(this.HCOftalmologia_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbpp2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbbiomicro2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbpp1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbbiomicro1)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.angulo2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbcristalinooi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.angulo1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbcristalinood)).EndInit();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.retina2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.retina1)).EndInit();
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.DateTimePicker dateTimePicker4;
        private System.Windows.Forms.DateTimePicker dateTimePicker3;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DateTimePicker dateTimePicker6;
        private System.Windows.Forms.DateTimePicker dateTimePicker5;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.TextBox textBox52;
        private System.Windows.Forms.TextBox textBox58;
        private System.Windows.Forms.TextBox textBox56;
        private System.Windows.Forms.TextBox textBox65;
        private System.Windows.Forms.TextBox textBox48;
        private System.Windows.Forms.TextBox textBox50;
        private System.Windows.Forms.TextBox textBox68;
        private System.Windows.Forms.TextBox textBox61;
        private System.Windows.Forms.TextBox textBox60;
        private System.Windows.Forms.TextBox textBox44;
        private System.Windows.Forms.TextBox textBox51;
        private System.Windows.Forms.TextBox textBox47;
        private System.Windows.Forms.TextBox textBox46;
        private System.Windows.Forms.TextBox textBox45;
        private System.Windows.Forms.TextBox textBox49;
        private System.Windows.Forms.TextBox textBox57;
        private System.Windows.Forms.TextBox textBox55;
        private System.Windows.Forms.TextBox textBox64;
        private System.Windows.Forms.TextBox textBox63;
        private System.Windows.Forms.TextBox textBox62;
        private System.Windows.Forms.TextBox textBox59;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.PictureBox pbpp2;
        private System.Windows.Forms.PictureBox pbbiomicro2;
        private System.Windows.Forms.PictureBox pbpp1;
        private System.Windows.Forms.PictureBox pbbiomicro1;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TextBox textBox78;
        private System.Windows.Forms.TextBox textBox77;
        private System.Windows.Forms.TextBox textBox75;
        private System.Windows.Forms.TextBox textBox74;
        private System.Windows.Forms.TextBox textBox73;
        private System.Windows.Forms.TextBox textBox72;
        private System.Windows.Forms.TextBox textBox71;
        private System.Windows.Forms.TextBox textBox76;
        private System.Windows.Forms.TextBox textBox70;
        private System.Windows.Forms.PictureBox angulo2;
        private System.Windows.Forms.PictureBox pbcristalinooi;
        private System.Windows.Forms.PictureBox angulo1;
        private System.Windows.Forms.PictureBox pbcristalinood;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.Label label113;
        private System.Windows.Forms.Label label112;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.Label label109;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.Label label114;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Label label116;
        private System.Windows.Forms.Label label117;
        private System.Windows.Forms.Label label118;
        private System.Windows.Forms.Label label115;
        private System.Windows.Forms.PictureBox retina2;
        private System.Windows.Forms.PictureBox retina1;
        private System.Windows.Forms.TextBox textBox88;
        private System.Windows.Forms.TextBox textBox87;
        private System.Windows.Forms.TextBox textBox94;
        private System.Windows.Forms.TextBox textBox86;
        private System.Windows.Forms.TextBox textBox93;
        private System.Windows.Forms.TextBox textBox91;
        private System.Windows.Forms.TextBox textBox89;
        private System.Windows.Forms.TextBox textBox90;
        private System.Windows.Forms.TextBox textBox85;
        private System.Windows.Forms.Label label127;
        private System.Windows.Forms.Label label125;
        private System.Windows.Forms.Label label121;
        private System.Windows.Forms.TextBox textBox92;
        private System.Windows.Forms.Label label124;
        private System.Windows.Forms.Label label120;
        private System.Windows.Forms.Label label132;
        private System.Windows.Forms.Label label129;
        private System.Windows.Forms.Label label126;
        private System.Windows.Forms.Label label128;
        private System.Windows.Forms.Label label123;
        private System.Windows.Forms.Label label119;
        private System.Windows.Forms.Label label131;
        private System.Windows.Forms.Label label130;
        private System.Windows.Forms.Label label133;
        private System.Windows.Forms.Label label122;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.TextBox textBox97;
        private System.Windows.Forms.TextBox textBox96;
        private System.Windows.Forms.TextBox textBox95;
        private System.Windows.Forms.Label label136;
        private System.Windows.Forms.Label label135;
        private System.Windows.Forms.Label label134;
        private System.Windows.Forms.TextBox textBox69;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label138;
        private System.Windows.Forms.Label label137;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.ComboBox comboBox8;
        private System.Windows.Forms.ComboBox comboBox7;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.Label label140;
        private System.Windows.Forms.Label label139;
        private System.Windows.Forms.Label label141;
        private System.Windows.Forms.ComboBox comboBox9;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lbNuevo;
        private System.Windows.Forms.Label lbEditar;
        private System.Windows.Forms.Button button6;
    }
}