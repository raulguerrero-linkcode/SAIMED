﻿namespace SHOPCONTROL.HistorialClinica
{
    
    
    public partial class DataSetTicket {
    }
}
