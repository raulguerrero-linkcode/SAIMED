﻿namespace SHOPCONTROL.HistorialClinica
{
    partial class Dental
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dental));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label114 = new System.Windows.Forms.Label();
            this.label1111 = new System.Windows.Forms.Label();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.label116 = new System.Windows.Forms.Label();
            this.lbNuevo = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.button1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.lbEditar = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.panel49 = new System.Windows.Forms.Panel();
            this.checkBox20 = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.button9 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.comboBox13 = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.label103 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.comboBox14 = new System.Windows.Forms.ComboBox();
            this.comboBox15 = new System.Windows.Forms.ComboBox();
            this.label104 = new System.Windows.Forms.Label();
            this.comboBox16 = new System.Windows.Forms.ComboBox();
            this.label105 = new System.Windows.Forms.Label();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.label106 = new System.Windows.Forms.Label();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.label107 = new System.Windows.Forms.Label();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.label108 = new System.Windows.Forms.Label();
            this.label109 = new System.Windows.Forms.Label();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.label110 = new System.Windows.Forms.Label();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.label111 = new System.Windows.Forms.Label();
            this.label112 = new System.Windows.Forms.Label();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.label115 = new System.Windows.Forms.Label();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel43 = new System.Windows.Forms.Panel();
            this.radioButton77 = new System.Windows.Forms.RadioButton();
            this.label60 = new System.Windows.Forms.Label();
            this.radioButton78 = new System.Windows.Forms.RadioButton();
            this.panel36 = new System.Windows.Forms.Panel();
            this.radioButton63 = new System.Windows.Forms.RadioButton();
            this.label53 = new System.Windows.Forms.Label();
            this.radioButton64 = new System.Windows.Forms.RadioButton();
            this.panel40 = new System.Windows.Forms.Panel();
            this.radioButton71 = new System.Windows.Forms.RadioButton();
            this.label57 = new System.Windows.Forms.Label();
            this.radioButton72 = new System.Windows.Forms.RadioButton();
            this.panel39 = new System.Windows.Forms.Panel();
            this.radioButton69 = new System.Windows.Forms.RadioButton();
            this.label56 = new System.Windows.Forms.Label();
            this.radioButton70 = new System.Windows.Forms.RadioButton();
            this.panel38 = new System.Windows.Forms.Panel();
            this.radioButton67 = new System.Windows.Forms.RadioButton();
            this.label55 = new System.Windows.Forms.Label();
            this.radioButton68 = new System.Windows.Forms.RadioButton();
            this.panel37 = new System.Windows.Forms.Panel();
            this.radioButton65 = new System.Windows.Forms.RadioButton();
            this.label54 = new System.Windows.Forms.Label();
            this.radioButton66 = new System.Windows.Forms.RadioButton();
            this.panel20 = new System.Windows.Forms.Panel();
            this.radioButton31 = new System.Windows.Forms.RadioButton();
            this.label37 = new System.Windows.Forms.Label();
            this.radioButton32 = new System.Windows.Forms.RadioButton();
            this.panel42 = new System.Windows.Forms.Panel();
            this.radioButton75 = new System.Windows.Forms.RadioButton();
            this.label59 = new System.Windows.Forms.Label();
            this.radioButton76 = new System.Windows.Forms.RadioButton();
            this.panel35 = new System.Windows.Forms.Panel();
            this.radioButton61 = new System.Windows.Forms.RadioButton();
            this.label52 = new System.Windows.Forms.Label();
            this.radioButton62 = new System.Windows.Forms.RadioButton();
            this.panel19 = new System.Windows.Forms.Panel();
            this.radioButton29 = new System.Windows.Forms.RadioButton();
            this.label36 = new System.Windows.Forms.Label();
            this.radioButton30 = new System.Windows.Forms.RadioButton();
            this.panel41 = new System.Windows.Forms.Panel();
            this.radioButton73 = new System.Windows.Forms.RadioButton();
            this.label58 = new System.Windows.Forms.Label();
            this.radioButton74 = new System.Windows.Forms.RadioButton();
            this.panel34 = new System.Windows.Forms.Panel();
            this.radioButton59 = new System.Windows.Forms.RadioButton();
            this.label51 = new System.Windows.Forms.Label();
            this.radioButton60 = new System.Windows.Forms.RadioButton();
            this.panel18 = new System.Windows.Forms.Panel();
            this.radioButton27 = new System.Windows.Forms.RadioButton();
            this.label35 = new System.Windows.Forms.Label();
            this.radioButton28 = new System.Windows.Forms.RadioButton();
            this.panel44 = new System.Windows.Forms.Panel();
            this.radioButton79 = new System.Windows.Forms.RadioButton();
            this.label61 = new System.Windows.Forms.Label();
            this.radioButton80 = new System.Windows.Forms.RadioButton();
            this.panel33 = new System.Windows.Forms.Panel();
            this.radioButton57 = new System.Windows.Forms.RadioButton();
            this.label50 = new System.Windows.Forms.Label();
            this.radioButton58 = new System.Windows.Forms.RadioButton();
            this.panel16 = new System.Windows.Forms.Panel();
            this.radioButton25 = new System.Windows.Forms.RadioButton();
            this.label34 = new System.Windows.Forms.Label();
            this.radioButton26 = new System.Windows.Forms.RadioButton();
            this.panel32 = new System.Windows.Forms.Panel();
            this.radioButton55 = new System.Windows.Forms.RadioButton();
            this.label49 = new System.Windows.Forms.Label();
            this.radioButton56 = new System.Windows.Forms.RadioButton();
            this.panel15 = new System.Windows.Forms.Panel();
            this.radioButton23 = new System.Windows.Forms.RadioButton();
            this.label33 = new System.Windows.Forms.Label();
            this.radioButton24 = new System.Windows.Forms.RadioButton();
            this.panel31 = new System.Windows.Forms.Panel();
            this.radioButton53 = new System.Windows.Forms.RadioButton();
            this.label48 = new System.Windows.Forms.Label();
            this.radioButton54 = new System.Windows.Forms.RadioButton();
            this.panel14 = new System.Windows.Forms.Panel();
            this.radioButton21 = new System.Windows.Forms.RadioButton();
            this.label32 = new System.Windows.Forms.Label();
            this.radioButton22 = new System.Windows.Forms.RadioButton();
            this.panel30 = new System.Windows.Forms.Panel();
            this.radioButton51 = new System.Windows.Forms.RadioButton();
            this.label47 = new System.Windows.Forms.Label();
            this.radioButton52 = new System.Windows.Forms.RadioButton();
            this.panel13 = new System.Windows.Forms.Panel();
            this.radioButton19 = new System.Windows.Forms.RadioButton();
            this.label31 = new System.Windows.Forms.Label();
            this.radioButton20 = new System.Windows.Forms.RadioButton();
            this.panel29 = new System.Windows.Forms.Panel();
            this.radioButton49 = new System.Windows.Forms.RadioButton();
            this.label46 = new System.Windows.Forms.Label();
            this.radioButton50 = new System.Windows.Forms.RadioButton();
            this.panel12 = new System.Windows.Forms.Panel();
            this.radioButton17 = new System.Windows.Forms.RadioButton();
            this.label30 = new System.Windows.Forms.Label();
            this.radioButton18 = new System.Windows.Forms.RadioButton();
            this.panel28 = new System.Windows.Forms.Panel();
            this.radioButton47 = new System.Windows.Forms.RadioButton();
            this.label45 = new System.Windows.Forms.Label();
            this.radioButton48 = new System.Windows.Forms.RadioButton();
            this.panel11 = new System.Windows.Forms.Panel();
            this.radioButton15 = new System.Windows.Forms.RadioButton();
            this.label29 = new System.Windows.Forms.Label();
            this.radioButton16 = new System.Windows.Forms.RadioButton();
            this.panel27 = new System.Windows.Forms.Panel();
            this.radioButton45 = new System.Windows.Forms.RadioButton();
            this.label44 = new System.Windows.Forms.Label();
            this.radioButton46 = new System.Windows.Forms.RadioButton();
            this.panel10 = new System.Windows.Forms.Panel();
            this.radioButton13 = new System.Windows.Forms.RadioButton();
            this.label28 = new System.Windows.Forms.Label();
            this.radioButton14 = new System.Windows.Forms.RadioButton();
            this.panel26 = new System.Windows.Forms.Panel();
            this.radioButton43 = new System.Windows.Forms.RadioButton();
            this.label43 = new System.Windows.Forms.Label();
            this.radioButton44 = new System.Windows.Forms.RadioButton();
            this.panel9 = new System.Windows.Forms.Panel();
            this.radioButton11 = new System.Windows.Forms.RadioButton();
            this.label27 = new System.Windows.Forms.Label();
            this.radioButton12 = new System.Windows.Forms.RadioButton();
            this.panel25 = new System.Windows.Forms.Panel();
            this.radioButton41 = new System.Windows.Forms.RadioButton();
            this.label42 = new System.Windows.Forms.Label();
            this.radioButton42 = new System.Windows.Forms.RadioButton();
            this.panel8 = new System.Windows.Forms.Panel();
            this.radioButton9 = new System.Windows.Forms.RadioButton();
            this.label26 = new System.Windows.Forms.Label();
            this.radioButton10 = new System.Windows.Forms.RadioButton();
            this.panel24 = new System.Windows.Forms.Panel();
            this.radioButton39 = new System.Windows.Forms.RadioButton();
            this.label41 = new System.Windows.Forms.Label();
            this.radioButton40 = new System.Windows.Forms.RadioButton();
            this.panel7 = new System.Windows.Forms.Panel();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.label25 = new System.Windows.Forms.Label();
            this.radioButton8 = new System.Windows.Forms.RadioButton();
            this.panel23 = new System.Windows.Forms.Panel();
            this.radioButton37 = new System.Windows.Forms.RadioButton();
            this.label40 = new System.Windows.Forms.Label();
            this.radioButton38 = new System.Windows.Forms.RadioButton();
            this.panel6 = new System.Windows.Forms.Panel();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.label24 = new System.Windows.Forms.Label();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.panel22 = new System.Windows.Forms.Panel();
            this.radioButton35 = new System.Windows.Forms.RadioButton();
            this.label39 = new System.Windows.Forms.Label();
            this.radioButton36 = new System.Windows.Forms.RadioButton();
            this.panel5 = new System.Windows.Forms.Panel();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.label23 = new System.Windows.Forms.Label();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.panel21 = new System.Windows.Forms.Panel();
            this.radioButton33 = new System.Windows.Forms.RadioButton();
            this.label38 = new System.Windows.Forms.Label();
            this.radioButton34 = new System.Windows.Forms.RadioButton();
            this.panel4 = new System.Windows.Forms.Panel();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.label22 = new System.Windows.Forms.Label();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.panel3 = new System.Windows.Forms.Panel();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.label92 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.checkedListBox1 = new System.Windows.Forms.CheckedListBox();
            this.panel48 = new System.Windows.Forms.Panel();
            this.label93 = new System.Windows.Forms.Label();
            this.panel45 = new System.Windows.Forms.Panel();
            this.label76 = new System.Windows.Forms.Label();
            this.panel17 = new System.Windows.Forms.Panel();
            this.label69 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.label66 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.label102 = new System.Windows.Forms.Label();
            this.label101 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.label99 = new System.Windows.Forms.Label();
            this.label98 = new System.Windows.Forms.Label();
            this.label97 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.odontograma = new System.Windows.Forms.PictureBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.dateTimePicker7 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker4 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker6 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker3 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker5 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.panel47 = new System.Windows.Forms.Panel();
            this.label85 = new System.Windows.Forms.Label();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.panel46 = new System.Windows.Forms.Panel();
            this.label84 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.panel49.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabPage1.SuspendLayout();
            this.panel43.SuspendLayout();
            this.panel36.SuspendLayout();
            this.panel40.SuspendLayout();
            this.panel39.SuspendLayout();
            this.panel38.SuspendLayout();
            this.panel37.SuspendLayout();
            this.panel20.SuspendLayout();
            this.panel42.SuspendLayout();
            this.panel35.SuspendLayout();
            this.panel19.SuspendLayout();
            this.panel41.SuspendLayout();
            this.panel34.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel44.SuspendLayout();
            this.panel33.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel32.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel31.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel30.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel29.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel28.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel27.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel26.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel25.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel24.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel23.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel22.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel21.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel48.SuspendLayout();
            this.panel45.SuspendLayout();
            this.panel17.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.odontograma)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.panel47.SuspendLayout();
            this.panel46.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.tabControl1);
            this.panel1.Location = new System.Drawing.Point(1, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(995, 687);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.label114);
            this.panel2.Controls.Add(this.label1111);
            this.panel2.Controls.Add(this.textBox46);
            this.panel2.Controls.Add(this.label116);
            this.panel2.Controls.Add(this.lbNuevo);
            this.panel2.Controls.Add(this.dateTimePicker1);
            this.panel2.Controls.Add(this.button1);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.lbEditar);
            this.panel2.Location = new System.Drawing.Point(3, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(992, 52);
            this.panel2.TabIndex = 1;
            // 
            // label114
            // 
            this.label114.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label114.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label114.ForeColor = System.Drawing.Color.White;
            this.label114.Location = new System.Drawing.Point(882, 4);
            this.label114.Name = "label114";
            this.label114.Size = new System.Drawing.Size(109, 42);
            this.label114.TabIndex = 17;
            this.label114.Text = "0000";
            this.label114.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label1111
            // 
            this.label1111.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1111.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1111.Location = new System.Drawing.Point(754, 4);
            this.label1111.Name = "label1111";
            this.label1111.Size = new System.Drawing.Size(128, 42);
            this.label1111.TabIndex = 18;
            this.label1111.Text = "Numero de Estudio";
            this.label1111.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox46
            // 
            this.textBox46.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.textBox46.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox46.Location = new System.Drawing.Point(66, 9);
            this.textBox46.Name = "textBox46";
            this.textBox46.Size = new System.Drawing.Size(112, 26);
            this.textBox46.TabIndex = 15;
            // 
            // label116
            // 
            this.label116.AutoSize = true;
            this.label116.BackColor = System.Drawing.Color.Transparent;
            this.label116.Font = new System.Drawing.Font("Adobe Fan Heiti Std B", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label116.ForeColor = System.Drawing.Color.Black;
            this.label116.Location = new System.Drawing.Point(7, 13);
            this.label116.Name = "label116";
            this.label116.Size = new System.Drawing.Size(53, 19);
            this.label116.TabIndex = 16;
            this.label116.Text = "CLAVE";
            // 
            // lbNuevo
            // 
            this.lbNuevo.Image = ((System.Drawing.Image)(resources.GetObject("lbNuevo.Image")));
            this.lbNuevo.Location = new System.Drawing.Point(288, 13);
            this.lbNuevo.Name = "lbNuevo";
            this.lbNuevo.Size = new System.Drawing.Size(10, 21);
            this.lbNuevo.TabIndex = 5;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(648, 13);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(100, 22);
            this.dateTimePicker1.TabIndex = 2;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(184, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "Buscar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(599, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 14);
            this.label2.TabIndex = 0;
            this.label2.Text = "Fecha:";
            // 
            // lbEditar
            // 
            this.lbEditar.Image = ((System.Drawing.Image)(resources.GetObject("lbEditar.Image")));
            this.lbEditar.Location = new System.Drawing.Point(288, 12);
            this.lbEditar.Name = "lbEditar";
            this.lbEditar.Size = new System.Drawing.Size(10, 21);
            this.lbEditar.TabIndex = 5;
            this.lbEditar.Visible = false;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(7, 61);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(985, 612);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.panel49);
            this.tabPage4.Location = new System.Drawing.Point(4, 23);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(977, 585);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Informacion";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // panel49
            // 
            this.panel49.BackColor = System.Drawing.Color.White;
            this.panel49.Controls.Add(this.checkBox20);
            this.panel49.Controls.Add(this.label3);
            this.panel49.Controls.Add(this.label4);
            this.panel49.Controls.Add(this.button9);
            this.panel49.Controls.Add(this.label5);
            this.panel49.Controls.Add(this.textBox35);
            this.panel49.Controls.Add(this.textBox36);
            this.panel49.Controls.Add(this.label6);
            this.panel49.Controls.Add(this.label7);
            this.panel49.Controls.Add(this.textBox1);
            this.panel49.Controls.Add(this.comboBox13);
            this.panel49.Controls.Add(this.label8);
            this.panel49.Controls.Add(this.label9);
            this.panel49.Controls.Add(this.label10);
            this.panel49.Controls.Add(this.label11);
            this.panel49.Controls.Add(this.label12);
            this.panel49.Controls.Add(this.textBox38);
            this.panel49.Controls.Add(this.label103);
            this.panel49.Controls.Add(this.groupBox2);
            this.panel49.Controls.Add(this.comboBox14);
            this.panel49.Controls.Add(this.comboBox15);
            this.panel49.Controls.Add(this.label104);
            this.panel49.Controls.Add(this.comboBox16);
            this.panel49.Controls.Add(this.label105);
            this.panel49.Controls.Add(this.textBox39);
            this.panel49.Controls.Add(this.label106);
            this.panel49.Controls.Add(this.textBox40);
            this.panel49.Controls.Add(this.label107);
            this.panel49.Controls.Add(this.textBox41);
            this.panel49.Controls.Add(this.label108);
            this.panel49.Controls.Add(this.label109);
            this.panel49.Controls.Add(this.textBox42);
            this.panel49.Controls.Add(this.textBox43);
            this.panel49.Controls.Add(this.label110);
            this.panel49.Controls.Add(this.textBox44);
            this.panel49.Controls.Add(this.label111);
            this.panel49.Controls.Add(this.label112);
            this.panel49.Controls.Add(this.textBox45);
            this.panel49.Controls.Add(this.label115);
            this.panel49.Location = new System.Drawing.Point(3, 12);
            this.panel49.Name = "panel49";
            this.panel49.Size = new System.Drawing.Size(961, 570);
            this.panel49.TabIndex = 3;
            // 
            // checkBox20
            // 
            this.checkBox20.AutoSize = true;
            this.checkBox20.Location = new System.Drawing.Point(659, 69);
            this.checkBox20.Name = "checkBox20";
            this.checkBox20.Size = new System.Drawing.Size(61, 18);
            this.checkBox20.TabIndex = 42;
            this.checkBox20.Text = "Nuevo";
            this.checkBox20.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(635, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 23);
            this.label3.TabIndex = 41;
            this.label3.Text = "0";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label3.Visible = false;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(486, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(143, 23);
            this.label4.TabIndex = 40;
            this.label4.Text = "Ultimo estudio realizado";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label4.Visible = false;
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.White;
            this.button9.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.Image = ((System.Drawing.Image)(resources.GetObject("button9.Image")));
            this.button9.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button9.Location = new System.Drawing.Point(498, 365);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(142, 46);
            this.button9.TabIndex = 39;
            this.button9.Text = "Actualizar Datos ";
            this.button9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button9.UseVisualStyleBackColor = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(11, 374);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 14);
            this.label5.TabIndex = 32;
            this.label5.Text = "Direccion";
            // 
            // textBox35
            // 
            this.textBox35.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox35.Location = new System.Drawing.Point(137, 371);
            this.textBox35.Multiline = true;
            this.textBox35.Name = "textBox35";
            this.textBox35.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox35.Size = new System.Drawing.Size(325, 40);
            this.textBox35.TabIndex = 18;
            // 
            // textBox36
            // 
            this.textBox36.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBox36.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox36.Location = new System.Drawing.Point(138, 344);
            this.textBox36.Multiline = true;
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(222, 21);
            this.textBox36.TabIndex = 17;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(12, 351);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(56, 14);
            this.label6.TabIndex = 0;
            this.label6.Text = "Municipio";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(489, 68);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(117, 16);
            this.label7.TabIndex = 0;
            this.label7.Text = "Num. Expediente";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.textBox1.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(492, 89);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(225, 26);
            this.textBox1.TabIndex = 1;
            // 
            // comboBox13
            // 
            this.comboBox13.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox13.FormattingEnabled = true;
            this.comboBox13.Items.AddRange(new object[] {
            "ANUNCIO",
            "INTERNET",
            "RECOMENDACIÓN"});
            this.comboBox13.Location = new System.Drawing.Point(218, 304);
            this.comboBox13.Name = "comboBox13";
            this.comboBox13.Size = new System.Drawing.Size(142, 22);
            this.comboBox13.TabIndex = 16;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Blue;
            this.label8.Location = new System.Drawing.Point(13, 307);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(197, 13);
            this.label8.TabIndex = 29;
            this.label8.Text = "¿Cómo se entero de nuestros servicios?";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Red;
            this.label9.Location = new System.Drawing.Point(3, 122);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(14, 18);
            this.label9.TabIndex = 27;
            this.label9.Text = "*";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Red;
            this.label10.Location = new System.Drawing.Point(0, 70);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(14, 18);
            this.label10.TabIndex = 26;
            this.label10.Text = "*";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Red;
            this.label11.Location = new System.Drawing.Point(1, 50);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(14, 18);
            this.label11.TabIndex = 25;
            this.label11.Text = "*";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Red;
            this.label12.Location = new System.Drawing.Point(1, 23);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(14, 18);
            this.label12.TabIndex = 24;
            this.label12.Text = "*";
            // 
            // textBox38
            // 
            this.textBox38.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox38.Location = new System.Drawing.Point(136, 266);
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(222, 22);
            this.textBox38.TabIndex = 11;
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label103.Location = new System.Drawing.Point(11, 269);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(42, 14);
            this.label103.TabIndex = 20;
            this.label103.Text = "Celular";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button7);
            this.groupBox2.Controls.Add(this.button8);
            this.groupBox2.Controls.Add(this.pictureBox1);
            this.groupBox2.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(743, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(197, 246);
            this.groupBox2.TabIndex = 7;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Foto";
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(130, 197);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(61, 24);
            this.button7.TabIndex = 20;
            this.button7.Text = "Camara";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Visible = false;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(76, 197);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(48, 24);
            this.button8.TabIndex = 19;
            this.button8.Text = "Foto";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Visible = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(11, 18);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(180, 171);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // comboBox14
            // 
            this.comboBox14.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox14.FormattingEnabled = true;
            this.comboBox14.Items.AddRange(new object[] {
            "FEMENINO",
            "MASCULINO"});
            this.comboBox14.Location = new System.Drawing.Point(137, 200);
            this.comboBox14.Name = "comboBox14";
            this.comboBox14.Size = new System.Drawing.Size(222, 22);
            this.comboBox14.TabIndex = 9;
            // 
            // comboBox15
            // 
            this.comboBox15.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox15.FormattingEnabled = true;
            this.comboBox15.Items.AddRange(new object[] {
            "NINGUNA",
            "PRIMARIA",
            "PRIMARIA INCOMPLETA",
            "SECUNDARIA",
            "SECUNDARIA INCOMPLETA",
            "BACHILLERATO",
            "BACHILLERATO INCOMPLETO",
            "LICENCIATURA",
            "LICENCIATURA TRUNCADA",
            "MAESTRIA",
            "MAESTRIA TRUNCADA",
            "POSGRADO"});
            this.comboBox15.Location = new System.Drawing.Point(137, 93);
            this.comboBox15.Name = "comboBox15";
            this.comboBox15.Size = new System.Drawing.Size(324, 22);
            this.comboBox15.TabIndex = 3;
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label104.Location = new System.Drawing.Point(12, 25);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(65, 14);
            this.label104.TabIndex = 0;
            this.label104.Text = "Nombre(s)";
            // 
            // comboBox16
            // 
            this.comboBox16.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox16.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox16.FormattingEnabled = true;
            this.comboBox16.Items.AddRange(new object[] {
            "NO REGISTRADO",
            "SOLTERO",
            "CASADO",
            "DIVORCIADO",
            "VIUDO",
            "UNION LIBRE"});
            this.comboBox16.Location = new System.Drawing.Point(137, 173);
            this.comboBox16.Name = "comboBox16";
            this.comboBox16.Size = new System.Drawing.Size(223, 22);
            this.comboBox16.TabIndex = 8;
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label105.Location = new System.Drawing.Point(12, 50);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(96, 14);
            this.label105.TabIndex = 0;
            this.label105.Text = "Apellido Paterno";
            // 
            // textBox39
            // 
            this.textBox39.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox39.Location = new System.Drawing.Point(137, 44);
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(324, 22);
            this.textBox39.TabIndex = 1;
            // 
            // label106
            // 
            this.label106.AutoSize = true;
            this.label106.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label106.Location = new System.Drawing.Point(10, 71);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(98, 14);
            this.label106.TabIndex = 0;
            this.label106.Text = "Apellido Materno";
            // 
            // textBox40
            // 
            this.textBox40.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox40.Location = new System.Drawing.Point(136, 241);
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(222, 22);
            this.textBox40.TabIndex = 10;
            // 
            // label107
            // 
            this.label107.AutoSize = true;
            this.label107.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label107.Location = new System.Drawing.Point(12, 96);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(66, 14);
            this.label107.TabIndex = 0;
            this.label107.Text = "Escolaridad";
            // 
            // textBox41
            // 
            this.textBox41.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox41.Location = new System.Drawing.Point(320, 118);
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(39, 22);
            this.textBox41.TabIndex = 5;
            // 
            // label108
            // 
            this.label108.AutoSize = true;
            this.label108.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label108.Location = new System.Drawing.Point(16, 146);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(38, 14);
            this.label108.TabIndex = 0;
            this.label108.Text = "e-mail";
            // 
            // label109
            // 
            this.label109.AutoSize = true;
            this.label109.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label109.Location = new System.Drawing.Point(11, 244);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(56, 14);
            this.label109.TabIndex = 0;
            this.label109.Text = "Telefono";
            // 
            // textBox42
            // 
            this.textBox42.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox42.Location = new System.Drawing.Point(137, 68);
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(324, 22);
            this.textBox42.TabIndex = 2;
            // 
            // textBox43
            // 
            this.textBox43.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox43.Location = new System.Drawing.Point(137, 118);
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(48, 22);
            this.textBox43.TabIndex = 4;
            // 
            // label110
            // 
            this.label110.AutoSize = true;
            this.label110.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label110.Location = new System.Drawing.Point(15, 124);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(34, 14);
            this.label110.TabIndex = 0;
            this.label110.Text = "Edad";
            // 
            // textBox44
            // 
            this.textBox44.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.textBox44.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox44.Location = new System.Drawing.Point(137, 143);
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(222, 22);
            this.textBox44.TabIndex = 6;
            // 
            // label111
            // 
            this.label111.AutoSize = true;
            this.label111.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label111.Location = new System.Drawing.Point(16, 202);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(47, 14);
            this.label111.TabIndex = 0;
            this.label111.Text = "Genero";
            // 
            // label112
            // 
            this.label112.AutoSize = true;
            this.label112.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label112.Location = new System.Drawing.Point(16, 178);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(67, 14);
            this.label112.TabIndex = 0;
            this.label112.Text = "Estado Civil";
            // 
            // textBox45
            // 
            this.textBox45.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox45.Location = new System.Drawing.Point(137, 21);
            this.textBox45.Name = "textBox45";
            this.textBox45.Size = new System.Drawing.Size(324, 22);
            this.textBox45.TabIndex = 0;
            // 
            // label115
            // 
            this.label115.AutoSize = true;
            this.label115.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label115.Location = new System.Drawing.Point(226, 124);
            this.label115.Name = "label115";
            this.label115.Size = new System.Drawing.Size(83, 14);
            this.label115.TabIndex = 0;
            this.label115.Text = "Num. de Hijos";
            // 
            // tabPage1
            // 
            this.tabPage1.AutoScroll = true;
            this.tabPage1.Controls.Add(this.panel43);
            this.tabPage1.Controls.Add(this.panel36);
            this.tabPage1.Controls.Add(this.panel40);
            this.tabPage1.Controls.Add(this.panel39);
            this.tabPage1.Controls.Add(this.panel38);
            this.tabPage1.Controls.Add(this.panel37);
            this.tabPage1.Controls.Add(this.panel20);
            this.tabPage1.Controls.Add(this.panel42);
            this.tabPage1.Controls.Add(this.panel35);
            this.tabPage1.Controls.Add(this.panel19);
            this.tabPage1.Controls.Add(this.panel41);
            this.tabPage1.Controls.Add(this.panel34);
            this.tabPage1.Controls.Add(this.panel18);
            this.tabPage1.Controls.Add(this.panel44);
            this.tabPage1.Controls.Add(this.panel33);
            this.tabPage1.Controls.Add(this.panel16);
            this.tabPage1.Controls.Add(this.panel32);
            this.tabPage1.Controls.Add(this.panel15);
            this.tabPage1.Controls.Add(this.panel31);
            this.tabPage1.Controls.Add(this.panel14);
            this.tabPage1.Controls.Add(this.panel30);
            this.tabPage1.Controls.Add(this.panel13);
            this.tabPage1.Controls.Add(this.panel29);
            this.tabPage1.Controls.Add(this.panel12);
            this.tabPage1.Controls.Add(this.panel28);
            this.tabPage1.Controls.Add(this.panel11);
            this.tabPage1.Controls.Add(this.panel27);
            this.tabPage1.Controls.Add(this.panel10);
            this.tabPage1.Controls.Add(this.panel26);
            this.tabPage1.Controls.Add(this.panel9);
            this.tabPage1.Controls.Add(this.panel25);
            this.tabPage1.Controls.Add(this.panel8);
            this.tabPage1.Controls.Add(this.panel24);
            this.tabPage1.Controls.Add(this.panel7);
            this.tabPage1.Controls.Add(this.panel23);
            this.tabPage1.Controls.Add(this.panel6);
            this.tabPage1.Controls.Add(this.panel22);
            this.tabPage1.Controls.Add(this.panel5);
            this.tabPage1.Controls.Add(this.panel21);
            this.tabPage1.Controls.Add(this.panel4);
            this.tabPage1.Controls.Add(this.panel3);
            this.tabPage1.Controls.Add(this.textBox3);
            this.tabPage1.Controls.Add(this.textBox6);
            this.tabPage1.Controls.Add(this.textBox5);
            this.tabPage1.Controls.Add(this.textBox10);
            this.tabPage1.Controls.Add(this.textBox9);
            this.tabPage1.Controls.Add(this.textBox8);
            this.tabPage1.Controls.Add(this.textBox7);
            this.tabPage1.Controls.Add(this.textBox4);
            this.tabPage1.Controls.Add(this.textBox2);
            this.tabPage1.Controls.Add(this.label20);
            this.tabPage1.Controls.Add(this.label19);
            this.tabPage1.Controls.Add(this.label21);
            this.tabPage1.Controls.Add(this.label16);
            this.tabPage1.Controls.Add(this.label18);
            this.tabPage1.Controls.Add(this.label17);
            this.tabPage1.Controls.Add(this.label15);
            this.tabPage1.Controls.Add(this.label14);
            this.tabPage1.Controls.Add(this.label13);
            this.tabPage1.Location = new System.Drawing.Point(4, 23);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(977, 585);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Página 1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // panel43
            // 
            this.panel43.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel43.Controls.Add(this.radioButton77);
            this.panel43.Controls.Add(this.label60);
            this.panel43.Controls.Add(this.radioButton78);
            this.panel43.Location = new System.Drawing.Point(361, 553);
            this.panel43.Name = "panel43";
            this.panel43.Size = new System.Drawing.Size(351, 23);
            this.panel43.TabIndex = 7;
            // 
            // radioButton77
            // 
            this.radioButton77.AutoSize = true;
            this.radioButton77.Location = new System.Drawing.Point(332, 4);
            this.radioButton77.Name = "radioButton77";
            this.radioButton77.Size = new System.Drawing.Size(14, 13);
            this.radioButton77.TabIndex = 4;
            this.radioButton77.TabStop = true;
            this.radioButton77.UseVisualStyleBackColor = true;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label60.Location = new System.Drawing.Point(3, 3);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(103, 14);
            this.label60.TabIndex = 1;
            this.label60.Text = "-Respiración bucal";
            // 
            // radioButton78
            // 
            this.radioButton78.AutoSize = true;
            this.radioButton78.Location = new System.Drawing.Point(308, 4);
            this.radioButton78.Name = "radioButton78";
            this.radioButton78.Size = new System.Drawing.Size(14, 13);
            this.radioButton78.TabIndex = 4;
            this.radioButton78.TabStop = true;
            this.radioButton78.UseVisualStyleBackColor = true;
            // 
            // panel36
            // 
            this.panel36.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel36.Controls.Add(this.radioButton63);
            this.panel36.Controls.Add(this.label53);
            this.panel36.Controls.Add(this.radioButton64);
            this.panel36.Location = new System.Drawing.Point(361, 487);
            this.panel36.Name = "panel36";
            this.panel36.Size = new System.Drawing.Size(351, 23);
            this.panel36.TabIndex = 7;
            // 
            // radioButton63
            // 
            this.radioButton63.AutoSize = true;
            this.radioButton63.Location = new System.Drawing.Point(332, 4);
            this.radioButton63.Name = "radioButton63";
            this.radioButton63.Size = new System.Drawing.Size(14, 13);
            this.radioButton63.TabIndex = 4;
            this.radioButton63.TabStop = true;
            this.radioButton63.UseVisualStyleBackColor = true;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.Location = new System.Drawing.Point(3, 3);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(165, 14);
            this.label53.TabIndex = 1;
            this.label53.Text = "¿Consume alimentos cítricos?";
            // 
            // radioButton64
            // 
            this.radioButton64.AutoSize = true;
            this.radioButton64.Location = new System.Drawing.Point(308, 4);
            this.radioButton64.Name = "radioButton64";
            this.radioButton64.Size = new System.Drawing.Size(14, 13);
            this.radioButton64.TabIndex = 4;
            this.radioButton64.TabStop = true;
            this.radioButton64.UseVisualStyleBackColor = true;
            // 
            // panel40
            // 
            this.panel40.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel40.Controls.Add(this.radioButton71);
            this.panel40.Controls.Add(this.label57);
            this.panel40.Controls.Add(this.radioButton72);
            this.panel40.Location = new System.Drawing.Point(8, 553);
            this.panel40.Name = "panel40";
            this.panel40.Size = new System.Drawing.Size(351, 23);
            this.panel40.TabIndex = 7;
            // 
            // radioButton71
            // 
            this.radioButton71.AutoSize = true;
            this.radioButton71.Location = new System.Drawing.Point(332, 4);
            this.radioButton71.Name = "radioButton71";
            this.radioButton71.Size = new System.Drawing.Size(14, 13);
            this.radioButton71.TabIndex = 4;
            this.radioButton71.TabStop = true;
            this.radioButton71.UseVisualStyleBackColor = true;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label57.Location = new System.Drawing.Point(3, 3);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(299, 14);
            this.label57.TabIndex = 1;
            this.label57.Text = "¿Está tomando actualmente pastillas anticonceptivas?";
            // 
            // radioButton72
            // 
            this.radioButton72.AutoSize = true;
            this.radioButton72.Location = new System.Drawing.Point(308, 4);
            this.radioButton72.Name = "radioButton72";
            this.radioButton72.Size = new System.Drawing.Size(14, 13);
            this.radioButton72.TabIndex = 4;
            this.radioButton72.TabStop = true;
            this.radioButton72.UseVisualStyleBackColor = true;
            // 
            // panel39
            // 
            this.panel39.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel39.Controls.Add(this.radioButton69);
            this.panel39.Controls.Add(this.label56);
            this.panel39.Controls.Add(this.radioButton70);
            this.panel39.Location = new System.Drawing.Point(8, 531);
            this.panel39.Name = "panel39";
            this.panel39.Size = new System.Drawing.Size(351, 23);
            this.panel39.TabIndex = 7;
            // 
            // radioButton69
            // 
            this.radioButton69.AutoSize = true;
            this.radioButton69.Location = new System.Drawing.Point(332, 4);
            this.radioButton69.Name = "radioButton69";
            this.radioButton69.Size = new System.Drawing.Size(14, 13);
            this.radioButton69.TabIndex = 4;
            this.radioButton69.TabStop = true;
            this.radioButton69.UseVisualStyleBackColor = true;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.Location = new System.Drawing.Point(3, 3);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(145, 14);
            this.label56.TabIndex = 1;
            this.label56.Text = "¿Está usted embarazada?";
            // 
            // radioButton70
            // 
            this.radioButton70.AutoSize = true;
            this.radioButton70.Location = new System.Drawing.Point(308, 4);
            this.radioButton70.Name = "radioButton70";
            this.radioButton70.Size = new System.Drawing.Size(14, 13);
            this.radioButton70.TabIndex = 4;
            this.radioButton70.TabStop = true;
            this.radioButton70.UseVisualStyleBackColor = true;
            // 
            // panel38
            // 
            this.panel38.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel38.Controls.Add(this.radioButton67);
            this.panel38.Controls.Add(this.label55);
            this.panel38.Controls.Add(this.radioButton68);
            this.panel38.Location = new System.Drawing.Point(8, 509);
            this.panel38.Name = "panel38";
            this.panel38.Size = new System.Drawing.Size(351, 23);
            this.panel38.TabIndex = 7;
            // 
            // radioButton67
            // 
            this.radioButton67.AutoSize = true;
            this.radioButton67.Location = new System.Drawing.Point(332, 4);
            this.radioButton67.Name = "radioButton67";
            this.radioButton67.Size = new System.Drawing.Size(14, 13);
            this.radioButton67.TabIndex = 4;
            this.radioButton67.TabStop = true;
            this.radioButton67.UseVisualStyleBackColor = true;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.Location = new System.Drawing.Point(3, 3);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(212, 14);
            this.label55.TabIndex = 1;
            this.label55.Text = "¿Toma algún medicamento retroviral?";
            // 
            // radioButton68
            // 
            this.radioButton68.AutoSize = true;
            this.radioButton68.Location = new System.Drawing.Point(308, 4);
            this.radioButton68.Name = "radioButton68";
            this.radioButton68.Size = new System.Drawing.Size(14, 13);
            this.radioButton68.TabIndex = 4;
            this.radioButton68.TabStop = true;
            this.radioButton68.UseVisualStyleBackColor = true;
            // 
            // panel37
            // 
            this.panel37.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel37.Controls.Add(this.radioButton65);
            this.panel37.Controls.Add(this.label54);
            this.panel37.Controls.Add(this.radioButton66);
            this.panel37.Location = new System.Drawing.Point(8, 487);
            this.panel37.Name = "panel37";
            this.panel37.Size = new System.Drawing.Size(351, 23);
            this.panel37.TabIndex = 7;
            // 
            // radioButton65
            // 
            this.radioButton65.AutoSize = true;
            this.radioButton65.Location = new System.Drawing.Point(332, 4);
            this.radioButton65.Name = "radioButton65";
            this.radioButton65.Size = new System.Drawing.Size(14, 13);
            this.radioButton65.TabIndex = 4;
            this.radioButton65.TabStop = true;
            this.radioButton65.UseVisualStyleBackColor = true;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.Location = new System.Drawing.Point(3, 3);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(110, 14);
            this.label54.TabIndex = 1;
            this.label54.Text = "¿Es usted V.I.H +?";
            // 
            // radioButton66
            // 
            this.radioButton66.AutoSize = true;
            this.radioButton66.Location = new System.Drawing.Point(308, 4);
            this.radioButton66.Name = "radioButton66";
            this.radioButton66.Size = new System.Drawing.Size(14, 13);
            this.radioButton66.TabIndex = 4;
            this.radioButton66.TabStop = true;
            this.radioButton66.UseVisualStyleBackColor = true;
            // 
            // panel20
            // 
            this.panel20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel20.Controls.Add(this.radioButton31);
            this.panel20.Controls.Add(this.label37);
            this.panel20.Controls.Add(this.radioButton32);
            this.panel20.Location = new System.Drawing.Point(8, 465);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(351, 23);
            this.panel20.TabIndex = 7;
            // 
            // radioButton31
            // 
            this.radioButton31.AutoSize = true;
            this.radioButton31.Location = new System.Drawing.Point(332, 4);
            this.radioButton31.Name = "radioButton31";
            this.radioButton31.Size = new System.Drawing.Size(14, 13);
            this.radioButton31.TabIndex = 4;
            this.radioButton31.TabStop = true;
            this.radioButton31.UseVisualStyleBackColor = true;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(3, 3);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(236, 14);
            this.label37.TabIndex = 1;
            this.label37.Text = "-Anemia, leucemia, hemofilia, déficit Vit. K";
            // 
            // radioButton32
            // 
            this.radioButton32.AutoSize = true;
            this.radioButton32.Location = new System.Drawing.Point(308, 4);
            this.radioButton32.Name = "radioButton32";
            this.radioButton32.Size = new System.Drawing.Size(14, 13);
            this.radioButton32.TabIndex = 4;
            this.radioButton32.TabStop = true;
            this.radioButton32.UseVisualStyleBackColor = true;
            // 
            // panel42
            // 
            this.panel42.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel42.Controls.Add(this.radioButton75);
            this.panel42.Controls.Add(this.label59);
            this.panel42.Controls.Add(this.radioButton76);
            this.panel42.Location = new System.Drawing.Point(361, 531);
            this.panel42.Name = "panel42";
            this.panel42.Size = new System.Drawing.Size(351, 23);
            this.panel42.TabIndex = 7;
            // 
            // radioButton75
            // 
            this.radioButton75.AutoSize = true;
            this.radioButton75.Location = new System.Drawing.Point(332, 4);
            this.radioButton75.Name = "radioButton75";
            this.radioButton75.Size = new System.Drawing.Size(14, 13);
            this.radioButton75.TabIndex = 4;
            this.radioButton75.TabStop = true;
            this.radioButton75.UseVisualStyleBackColor = true;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label59.Location = new System.Drawing.Point(3, 3);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(135, 14);
            this.label59.TabIndex = 1;
            this.label59.Text = "-Apretamiento dentario";
            // 
            // radioButton76
            // 
            this.radioButton76.AutoSize = true;
            this.radioButton76.Location = new System.Drawing.Point(308, 4);
            this.radioButton76.Name = "radioButton76";
            this.radioButton76.Size = new System.Drawing.Size(14, 13);
            this.radioButton76.TabIndex = 4;
            this.radioButton76.TabStop = true;
            this.radioButton76.UseVisualStyleBackColor = true;
            // 
            // panel35
            // 
            this.panel35.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel35.Controls.Add(this.radioButton61);
            this.panel35.Controls.Add(this.label52);
            this.panel35.Controls.Add(this.radioButton62);
            this.panel35.Location = new System.Drawing.Point(361, 465);
            this.panel35.Name = "panel35";
            this.panel35.Size = new System.Drawing.Size(351, 23);
            this.panel35.TabIndex = 7;
            // 
            // radioButton61
            // 
            this.radioButton61.AutoSize = true;
            this.radioButton61.Location = new System.Drawing.Point(332, 4);
            this.radioButton61.Name = "radioButton61";
            this.radioButton61.Size = new System.Drawing.Size(14, 13);
            this.radioButton61.TabIndex = 4;
            this.radioButton61.TabStop = true;
            this.radioButton61.UseVisualStyleBackColor = true;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(3, 3);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(92, 14);
            this.label52.TabIndex = 1;
            this.label52.Text = "Cigarrillos diarios";
            // 
            // radioButton62
            // 
            this.radioButton62.AutoSize = true;
            this.radioButton62.Location = new System.Drawing.Point(308, 4);
            this.radioButton62.Name = "radioButton62";
            this.radioButton62.Size = new System.Drawing.Size(14, 13);
            this.radioButton62.TabIndex = 4;
            this.radioButton62.TabStop = true;
            this.radioButton62.UseVisualStyleBackColor = true;
            // 
            // panel19
            // 
            this.panel19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel19.Controls.Add(this.radioButton29);
            this.panel19.Controls.Add(this.label36);
            this.panel19.Controls.Add(this.radioButton30);
            this.panel19.Location = new System.Drawing.Point(8, 443);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(351, 23);
            this.panel19.TabIndex = 7;
            // 
            // radioButton29
            // 
            this.radioButton29.AutoSize = true;
            this.radioButton29.Location = new System.Drawing.Point(332, 4);
            this.radioButton29.Name = "radioButton29";
            this.radioButton29.Size = new System.Drawing.Size(14, 13);
            this.radioButton29.TabIndex = 4;
            this.radioButton29.TabStop = true;
            this.radioButton29.UseVisualStyleBackColor = true;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(3, 3);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(279, 14);
            this.label36.TabIndex = 1;
            this.label36.Text = "¿Padece o a padecido algún problema sanguíneo?";
            // 
            // radioButton30
            // 
            this.radioButton30.AutoSize = true;
            this.radioButton30.Location = new System.Drawing.Point(308, 4);
            this.radioButton30.Name = "radioButton30";
            this.radioButton30.Size = new System.Drawing.Size(14, 13);
            this.radioButton30.TabIndex = 4;
            this.radioButton30.TabStop = true;
            this.radioButton30.UseVisualStyleBackColor = true;
            // 
            // panel41
            // 
            this.panel41.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel41.Controls.Add(this.radioButton73);
            this.panel41.Controls.Add(this.label58);
            this.panel41.Controls.Add(this.radioButton74);
            this.panel41.Location = new System.Drawing.Point(361, 509);
            this.panel41.Name = "panel41";
            this.panel41.Size = new System.Drawing.Size(351, 23);
            this.panel41.TabIndex = 7;
            // 
            // radioButton73
            // 
            this.radioButton73.AutoSize = true;
            this.radioButton73.Location = new System.Drawing.Point(332, 4);
            this.radioButton73.Name = "radioButton73";
            this.radioButton73.Size = new System.Drawing.Size(14, 13);
            this.radioButton73.TabIndex = 4;
            this.radioButton73.TabStop = true;
            this.radioButton73.UseVisualStyleBackColor = true;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label58.Location = new System.Drawing.Point(3, 3);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(186, 14);
            this.label58.TabIndex = 1;
            this.label58.Text = "¿Muerde objeto con los dientes?";
            // 
            // radioButton74
            // 
            this.radioButton74.AutoSize = true;
            this.radioButton74.Location = new System.Drawing.Point(308, 4);
            this.radioButton74.Name = "radioButton74";
            this.radioButton74.Size = new System.Drawing.Size(14, 13);
            this.radioButton74.TabIndex = 4;
            this.radioButton74.TabStop = true;
            this.radioButton74.UseVisualStyleBackColor = true;
            // 
            // panel34
            // 
            this.panel34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel34.Controls.Add(this.radioButton59);
            this.panel34.Controls.Add(this.label51);
            this.panel34.Controls.Add(this.radioButton60);
            this.panel34.Location = new System.Drawing.Point(361, 443);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(351, 23);
            this.panel34.TabIndex = 7;
            // 
            // radioButton59
            // 
            this.radioButton59.AutoSize = true;
            this.radioButton59.Location = new System.Drawing.Point(332, 4);
            this.radioButton59.Name = "radioButton59";
            this.radioButton59.Size = new System.Drawing.Size(14, 13);
            this.radioButton59.TabIndex = 4;
            this.radioButton59.TabStop = true;
            this.radioButton59.UseVisualStyleBackColor = true;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(3, 3);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(48, 14);
            this.label51.TabIndex = 1;
            this.label51.Text = "¿Fuma?";
            // 
            // radioButton60
            // 
            this.radioButton60.AutoSize = true;
            this.radioButton60.Location = new System.Drawing.Point(308, 4);
            this.radioButton60.Name = "radioButton60";
            this.radioButton60.Size = new System.Drawing.Size(14, 13);
            this.radioButton60.TabIndex = 4;
            this.radioButton60.TabStop = true;
            this.radioButton60.UseVisualStyleBackColor = true;
            // 
            // panel18
            // 
            this.panel18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel18.Controls.Add(this.radioButton27);
            this.panel18.Controls.Add(this.label35);
            this.panel18.Controls.Add(this.radioButton28);
            this.panel18.Location = new System.Drawing.Point(8, 421);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(351, 23);
            this.panel18.TabIndex = 7;
            // 
            // radioButton27
            // 
            this.radioButton27.AutoSize = true;
            this.radioButton27.Location = new System.Drawing.Point(332, 4);
            this.radioButton27.Name = "radioButton27";
            this.radioButton27.Size = new System.Drawing.Size(14, 13);
            this.radioButton27.TabIndex = 4;
            this.radioButton27.TabStop = true;
            this.radioButton27.UseVisualStyleBackColor = true;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(3, 3);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(201, 14);
            this.label35.TabIndex = 1;
            this.label35.Text = "¿Sangra excesivamente al cortarse?";
            // 
            // radioButton28
            // 
            this.radioButton28.AutoSize = true;
            this.radioButton28.Location = new System.Drawing.Point(308, 4);
            this.radioButton28.Name = "radioButton28";
            this.radioButton28.Size = new System.Drawing.Size(14, 13);
            this.radioButton28.TabIndex = 4;
            this.radioButton28.TabStop = true;
            this.radioButton28.UseVisualStyleBackColor = true;
            // 
            // panel44
            // 
            this.panel44.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel44.Controls.Add(this.radioButton79);
            this.panel44.Controls.Add(this.label61);
            this.panel44.Controls.Add(this.radioButton80);
            this.panel44.Location = new System.Drawing.Point(361, 399);
            this.panel44.Name = "panel44";
            this.panel44.Size = new System.Drawing.Size(351, 23);
            this.panel44.TabIndex = 7;
            // 
            // radioButton79
            // 
            this.radioButton79.AutoSize = true;
            this.radioButton79.Location = new System.Drawing.Point(332, 4);
            this.radioButton79.Name = "radioButton79";
            this.radioButton79.Size = new System.Drawing.Size(14, 13);
            this.radioButton79.TabIndex = 4;
            this.radioButton79.TabStop = true;
            this.radioButton79.UseVisualStyleBackColor = true;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label61.Location = new System.Drawing.Point(3, 3);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(215, 14);
            this.label61.TabIndex = 1;
            this.label61.Text = "¿Sufre de herpes o aftas recurrentes?";
            // 
            // radioButton80
            // 
            this.radioButton80.AutoSize = true;
            this.radioButton80.Location = new System.Drawing.Point(308, 4);
            this.radioButton80.Name = "radioButton80";
            this.radioButton80.Size = new System.Drawing.Size(14, 13);
            this.radioButton80.TabIndex = 4;
            this.radioButton80.TabStop = true;
            this.radioButton80.UseVisualStyleBackColor = true;
            // 
            // panel33
            // 
            this.panel33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel33.Controls.Add(this.radioButton57);
            this.panel33.Controls.Add(this.label50);
            this.panel33.Controls.Add(this.radioButton58);
            this.panel33.Location = new System.Drawing.Point(361, 421);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(351, 23);
            this.panel33.TabIndex = 7;
            // 
            // radioButton57
            // 
            this.radioButton57.AutoSize = true;
            this.radioButton57.Location = new System.Drawing.Point(332, 4);
            this.radioButton57.Name = "radioButton57";
            this.radioButton57.Size = new System.Drawing.Size(14, 13);
            this.radioButton57.TabIndex = 4;
            this.radioButton57.TabStop = true;
            this.radioButton57.UseVisualStyleBackColor = true;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(3, 3);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(177, 14);
            this.label50.TabIndex = 1;
            this.label50.Text = "¿Morderse las uñas o los labios?";
            // 
            // radioButton58
            // 
            this.radioButton58.AutoSize = true;
            this.radioButton58.Location = new System.Drawing.Point(308, 4);
            this.radioButton58.Name = "radioButton58";
            this.radioButton58.Size = new System.Drawing.Size(14, 13);
            this.radioButton58.TabIndex = 4;
            this.radioButton58.TabStop = true;
            this.radioButton58.UseVisualStyleBackColor = true;
            // 
            // panel16
            // 
            this.panel16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel16.Controls.Add(this.radioButton25);
            this.panel16.Controls.Add(this.label34);
            this.panel16.Controls.Add(this.radioButton26);
            this.panel16.Location = new System.Drawing.Point(8, 399);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(351, 23);
            this.panel16.TabIndex = 7;
            // 
            // radioButton25
            // 
            this.radioButton25.AutoSize = true;
            this.radioButton25.Location = new System.Drawing.Point(332, 4);
            this.radioButton25.Name = "radioButton25";
            this.radioButton25.Size = new System.Drawing.Size(14, 13);
            this.radioButton25.TabIndex = 4;
            this.radioButton25.TabStop = true;
            this.radioButton25.UseVisualStyleBackColor = true;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(3, 3);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(33, 14);
            this.label34.TabIndex = 1;
            this.label34.Text = "-Baja";
            // 
            // radioButton26
            // 
            this.radioButton26.AutoSize = true;
            this.radioButton26.Location = new System.Drawing.Point(308, 4);
            this.radioButton26.Name = "radioButton26";
            this.radioButton26.Size = new System.Drawing.Size(14, 13);
            this.radioButton26.TabIndex = 4;
            this.radioButton26.TabStop = true;
            this.radioButton26.UseVisualStyleBackColor = true;
            // 
            // panel32
            // 
            this.panel32.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel32.Controls.Add(this.radioButton55);
            this.panel32.Controls.Add(this.label49);
            this.panel32.Controls.Add(this.radioButton56);
            this.panel32.Location = new System.Drawing.Point(361, 377);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(351, 23);
            this.panel32.TabIndex = 7;
            // 
            // radioButton55
            // 
            this.radioButton55.AutoSize = true;
            this.radioButton55.Location = new System.Drawing.Point(332, 4);
            this.radioButton55.Name = "radioButton55";
            this.radioButton55.Size = new System.Drawing.Size(14, 13);
            this.radioButton55.TabIndex = 4;
            this.radioButton55.TabStop = true;
            this.radioButton55.UseVisualStyleBackColor = true;
            this.radioButton55.Visible = false;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(3, 3);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(240, 14);
            this.label49.TabIndex = 1;
            this.label49.Text = "-Presenta alguno de los siguientes hábitos:";
            // 
            // radioButton56
            // 
            this.radioButton56.AutoSize = true;
            this.radioButton56.Location = new System.Drawing.Point(308, 4);
            this.radioButton56.Name = "radioButton56";
            this.radioButton56.Size = new System.Drawing.Size(14, 13);
            this.radioButton56.TabIndex = 4;
            this.radioButton56.TabStop = true;
            this.radioButton56.UseVisualStyleBackColor = true;
            this.radioButton56.Visible = false;
            // 
            // panel15
            // 
            this.panel15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel15.Controls.Add(this.radioButton23);
            this.panel15.Controls.Add(this.label33);
            this.panel15.Controls.Add(this.radioButton24);
            this.panel15.Location = new System.Drawing.Point(8, 377);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(351, 23);
            this.panel15.TabIndex = 7;
            // 
            // radioButton23
            // 
            this.radioButton23.AutoSize = true;
            this.radioButton23.Location = new System.Drawing.Point(332, 4);
            this.radioButton23.Name = "radioButton23";
            this.radioButton23.Size = new System.Drawing.Size(14, 13);
            this.radioButton23.TabIndex = 4;
            this.radioButton23.TabStop = true;
            this.radioButton23.UseVisualStyleBackColor = true;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(3, 3);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(32, 14);
            this.label33.TabIndex = 1;
            this.label33.Text = "-Alta";
            // 
            // radioButton24
            // 
            this.radioButton24.AutoSize = true;
            this.radioButton24.Location = new System.Drawing.Point(308, 4);
            this.radioButton24.Name = "radioButton24";
            this.radioButton24.Size = new System.Drawing.Size(14, 13);
            this.radioButton24.TabIndex = 4;
            this.radioButton24.TabStop = true;
            this.radioButton24.UseVisualStyleBackColor = true;
            // 
            // panel31
            // 
            this.panel31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel31.Controls.Add(this.radioButton53);
            this.panel31.Controls.Add(this.label48);
            this.panel31.Controls.Add(this.radioButton54);
            this.panel31.Location = new System.Drawing.Point(361, 355);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(351, 23);
            this.panel31.TabIndex = 7;
            // 
            // radioButton53
            // 
            this.radioButton53.AutoSize = true;
            this.radioButton53.Location = new System.Drawing.Point(332, 4);
            this.radioButton53.Name = "radioButton53";
            this.radioButton53.Size = new System.Drawing.Size(14, 13);
            this.radioButton53.TabIndex = 4;
            this.radioButton53.TabStop = true;
            this.radioButton53.UseVisualStyleBackColor = true;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(3, 3);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(305, 14);
            this.label48.TabIndex = 1;
            this.label48.Text = "¿Siente ruidos en la mandíbula al abrir o cerrar la boca?";
            // 
            // radioButton54
            // 
            this.radioButton54.AutoSize = true;
            this.radioButton54.Location = new System.Drawing.Point(308, 4);
            this.radioButton54.Name = "radioButton54";
            this.radioButton54.Size = new System.Drawing.Size(14, 13);
            this.radioButton54.TabIndex = 4;
            this.radioButton54.TabStop = true;
            this.radioButton54.UseVisualStyleBackColor = true;
            // 
            // panel14
            // 
            this.panel14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel14.Controls.Add(this.radioButton21);
            this.panel14.Controls.Add(this.label32);
            this.panel14.Controls.Add(this.radioButton22);
            this.panel14.Location = new System.Drawing.Point(8, 355);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(351, 23);
            this.panel14.TabIndex = 7;
            // 
            // radioButton21
            // 
            this.radioButton21.AutoSize = true;
            this.radioButton21.Location = new System.Drawing.Point(332, 4);
            this.radioButton21.Name = "radioButton21";
            this.radioButton21.Size = new System.Drawing.Size(14, 13);
            this.radioButton21.TabIndex = 4;
            this.radioButton21.TabStop = true;
            this.radioButton21.UseVisualStyleBackColor = true;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(3, 3);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(142, 14);
            this.label32.TabIndex = 1;
            this.label32.Text = "Sufre de tensión arterial:";
            // 
            // radioButton22
            // 
            this.radioButton22.AutoSize = true;
            this.radioButton22.Location = new System.Drawing.Point(308, 4);
            this.radioButton22.Name = "radioButton22";
            this.radioButton22.Size = new System.Drawing.Size(14, 13);
            this.radioButton22.TabIndex = 4;
            this.radioButton22.TabStop = true;
            this.radioButton22.UseVisualStyleBackColor = true;
            // 
            // panel30
            // 
            this.panel30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel30.Controls.Add(this.radioButton51);
            this.panel30.Controls.Add(this.label47);
            this.panel30.Controls.Add(this.radioButton52);
            this.panel30.Location = new System.Drawing.Point(361, 333);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(351, 23);
            this.panel30.TabIndex = 7;
            // 
            // radioButton51
            // 
            this.radioButton51.AutoSize = true;
            this.radioButton51.Location = new System.Drawing.Point(332, 4);
            this.radioButton51.Name = "radioButton51";
            this.radioButton51.Size = new System.Drawing.Size(14, 13);
            this.radioButton51.TabIndex = 4;
            this.radioButton51.TabStop = true;
            this.radioButton51.UseVisualStyleBackColor = true;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(3, 3);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(259, 14);
            this.label47.TabIndex = 1;
            this.label47.Text = "¿Ha tenido limitacioón al abrir o cerrar la boca?";
            // 
            // radioButton52
            // 
            this.radioButton52.AutoSize = true;
            this.radioButton52.Location = new System.Drawing.Point(308, 4);
            this.radioButton52.Name = "radioButton52";
            this.radioButton52.Size = new System.Drawing.Size(14, 13);
            this.radioButton52.TabIndex = 4;
            this.radioButton52.TabStop = true;
            this.radioButton52.UseVisualStyleBackColor = true;
            // 
            // panel13
            // 
            this.panel13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel13.Controls.Add(this.radioButton19);
            this.panel13.Controls.Add(this.label31);
            this.panel13.Controls.Add(this.radioButton20);
            this.panel13.Location = new System.Drawing.Point(8, 333);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(351, 23);
            this.panel13.TabIndex = 7;
            // 
            // radioButton19
            // 
            this.radioButton19.AutoSize = true;
            this.radioButton19.Location = new System.Drawing.Point(332, 4);
            this.radioButton19.Name = "radioButton19";
            this.radioButton19.Size = new System.Drawing.Size(14, 13);
            this.radioButton19.TabIndex = 4;
            this.radioButton19.TabStop = true;
            this.radioButton19.UseVisualStyleBackColor = true;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(3, 3);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(108, 14);
            this.label31.TabIndex = 1;
            this.label31.Text = "-Merthiolate, otros";
            // 
            // radioButton20
            // 
            this.radioButton20.AutoSize = true;
            this.radioButton20.Location = new System.Drawing.Point(308, 4);
            this.radioButton20.Name = "radioButton20";
            this.radioButton20.Size = new System.Drawing.Size(14, 13);
            this.radioButton20.TabIndex = 4;
            this.radioButton20.TabStop = true;
            this.radioButton20.UseVisualStyleBackColor = true;
            // 
            // panel29
            // 
            this.panel29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel29.Controls.Add(this.radioButton49);
            this.panel29.Controls.Add(this.label46);
            this.panel29.Controls.Add(this.radioButton50);
            this.panel29.Location = new System.Drawing.Point(361, 311);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(351, 23);
            this.panel29.TabIndex = 7;
            // 
            // radioButton49
            // 
            this.radioButton49.AutoSize = true;
            this.radioButton49.Location = new System.Drawing.Point(332, 4);
            this.radioButton49.Name = "radioButton49";
            this.radioButton49.Size = new System.Drawing.Size(14, 13);
            this.radioButton49.TabIndex = 4;
            this.radioButton49.TabStop = true;
            this.radioButton49.UseVisualStyleBackColor = true;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(3, 3);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(53, 14);
            this.label46.TabIndex = 1;
            this.label46.Text = "-Tiroides";
            // 
            // radioButton50
            // 
            this.radioButton50.AutoSize = true;
            this.radioButton50.Location = new System.Drawing.Point(308, 4);
            this.radioButton50.Name = "radioButton50";
            this.radioButton50.Size = new System.Drawing.Size(14, 13);
            this.radioButton50.TabIndex = 4;
            this.radioButton50.TabStop = true;
            this.radioButton50.UseVisualStyleBackColor = true;
            // 
            // panel12
            // 
            this.panel12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel12.Controls.Add(this.radioButton17);
            this.panel12.Controls.Add(this.label30);
            this.panel12.Controls.Add(this.radioButton18);
            this.panel12.Location = new System.Drawing.Point(8, 311);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(351, 23);
            this.panel12.TabIndex = 7;
            // 
            // radioButton17
            // 
            this.radioButton17.AutoSize = true;
            this.radioButton17.Location = new System.Drawing.Point(332, 4);
            this.radioButton17.Name = "radioButton17";
            this.radioButton17.Size = new System.Drawing.Size(14, 13);
            this.radioButton17.TabIndex = 4;
            this.radioButton17.TabStop = true;
            this.radioButton17.UseVisualStyleBackColor = true;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(3, 3);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(87, 14);
            this.label30.TabIndex = 1;
            this.label30.Text = "-Aspirina, yodo";
            // 
            // radioButton18
            // 
            this.radioButton18.AutoSize = true;
            this.radioButton18.Location = new System.Drawing.Point(308, 4);
            this.radioButton18.Name = "radioButton18";
            this.radioButton18.Size = new System.Drawing.Size(14, 13);
            this.radioButton18.TabIndex = 4;
            this.radioButton18.TabStop = true;
            this.radioButton18.UseVisualStyleBackColor = true;
            // 
            // panel28
            // 
            this.panel28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel28.Controls.Add(this.radioButton47);
            this.panel28.Controls.Add(this.label45);
            this.panel28.Controls.Add(this.radioButton48);
            this.panel28.Location = new System.Drawing.Point(361, 289);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(351, 23);
            this.panel28.TabIndex = 7;
            // 
            // radioButton47
            // 
            this.radioButton47.AutoSize = true;
            this.radioButton47.Location = new System.Drawing.Point(332, 4);
            this.radioButton47.Name = "radioButton47";
            this.radioButton47.Size = new System.Drawing.Size(14, 13);
            this.radioButton47.TabIndex = 4;
            this.radioButton47.TabStop = true;
            this.radioButton47.UseVisualStyleBackColor = true;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(3, 3);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(89, 14);
            this.label45.TabIndex = 1;
            this.label45.Text = "-Úlcera gastrica";
            // 
            // radioButton48
            // 
            this.radioButton48.AutoSize = true;
            this.radioButton48.Location = new System.Drawing.Point(308, 4);
            this.radioButton48.Name = "radioButton48";
            this.radioButton48.Size = new System.Drawing.Size(14, 13);
            this.radioButton48.TabIndex = 4;
            this.radioButton48.TabStop = true;
            this.radioButton48.UseVisualStyleBackColor = true;
            // 
            // panel11
            // 
            this.panel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel11.Controls.Add(this.radioButton15);
            this.panel11.Controls.Add(this.label29);
            this.panel11.Controls.Add(this.radioButton16);
            this.panel11.Location = new System.Drawing.Point(8, 289);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(351, 23);
            this.panel11.TabIndex = 7;
            // 
            // radioButton15
            // 
            this.radioButton15.AutoSize = true;
            this.radioButton15.Location = new System.Drawing.Point(332, 4);
            this.radioButton15.Name = "radioButton15";
            this.radioButton15.Size = new System.Drawing.Size(14, 13);
            this.radioButton15.TabIndex = 4;
            this.radioButton15.TabStop = true;
            this.radioButton15.UseVisualStyleBackColor = true;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(3, 3);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(63, 14);
            this.label29.TabIndex = 1;
            this.label29.Text = "-Anestesia";
            // 
            // radioButton16
            // 
            this.radioButton16.AutoSize = true;
            this.radioButton16.Location = new System.Drawing.Point(308, 4);
            this.radioButton16.Name = "radioButton16";
            this.radioButton16.Size = new System.Drawing.Size(14, 13);
            this.radioButton16.TabIndex = 4;
            this.radioButton16.TabStop = true;
            this.radioButton16.UseVisualStyleBackColor = true;
            // 
            // panel27
            // 
            this.panel27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel27.Controls.Add(this.radioButton45);
            this.panel27.Controls.Add(this.label44);
            this.panel27.Controls.Add(this.radioButton46);
            this.panel27.Location = new System.Drawing.Point(361, 267);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(351, 23);
            this.panel27.TabIndex = 7;
            // 
            // radioButton45
            // 
            this.radioButton45.AutoSize = true;
            this.radioButton45.Location = new System.Drawing.Point(332, 4);
            this.radioButton45.Name = "radioButton45";
            this.radioButton45.Size = new System.Drawing.Size(14, 13);
            this.radioButton45.TabIndex = 4;
            this.radioButton45.TabStop = true;
            this.radioButton45.UseVisualStyleBackColor = true;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(3, 3);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(58, 14);
            this.label44.TabIndex = 1;
            this.label44.Text = "-Diábetes";
            // 
            // radioButton46
            // 
            this.radioButton46.AutoSize = true;
            this.radioButton46.Location = new System.Drawing.Point(308, 4);
            this.radioButton46.Name = "radioButton46";
            this.radioButton46.Size = new System.Drawing.Size(14, 13);
            this.radioButton46.TabIndex = 4;
            this.radioButton46.TabStop = true;
            this.radioButton46.UseVisualStyleBackColor = true;
            // 
            // panel10
            // 
            this.panel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel10.Controls.Add(this.radioButton13);
            this.panel10.Controls.Add(this.label28);
            this.panel10.Controls.Add(this.radioButton14);
            this.panel10.Location = new System.Drawing.Point(8, 267);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(351, 23);
            this.panel10.TabIndex = 7;
            // 
            // radioButton13
            // 
            this.radioButton13.AutoSize = true;
            this.radioButton13.Location = new System.Drawing.Point(332, 4);
            this.radioButton13.Name = "radioButton13";
            this.radioButton13.Size = new System.Drawing.Size(14, 13);
            this.radioButton13.TabIndex = 4;
            this.radioButton13.TabStop = true;
            this.radioButton13.UseVisualStyleBackColor = true;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(3, 3);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(59, 14);
            this.label28.TabIndex = 1;
            this.label28.Text = "-Penicílina";
            // 
            // radioButton14
            // 
            this.radioButton14.AutoSize = true;
            this.radioButton14.Location = new System.Drawing.Point(308, 4);
            this.radioButton14.Name = "radioButton14";
            this.radioButton14.Size = new System.Drawing.Size(14, 13);
            this.radioButton14.TabIndex = 4;
            this.radioButton14.TabStop = true;
            this.radioButton14.UseVisualStyleBackColor = true;
            // 
            // panel26
            // 
            this.panel26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel26.Controls.Add(this.radioButton43);
            this.panel26.Controls.Add(this.label43);
            this.panel26.Controls.Add(this.radioButton44);
            this.panel26.Location = new System.Drawing.Point(361, 245);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(351, 23);
            this.panel26.TabIndex = 7;
            // 
            // radioButton43
            // 
            this.radioButton43.AutoSize = true;
            this.radioButton43.Location = new System.Drawing.Point(332, 4);
            this.radioButton43.Name = "radioButton43";
            this.radioButton43.Size = new System.Drawing.Size(14, 13);
            this.radioButton43.TabIndex = 4;
            this.radioButton43.TabStop = true;
            this.radioButton43.UseVisualStyleBackColor = true;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(3, 3);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(40, 14);
            this.label43.TabIndex = 1;
            this.label43.Text = "-Asma";
            // 
            // radioButton44
            // 
            this.radioButton44.AutoSize = true;
            this.radioButton44.Location = new System.Drawing.Point(308, 4);
            this.radioButton44.Name = "radioButton44";
            this.radioButton44.Size = new System.Drawing.Size(14, 13);
            this.radioButton44.TabIndex = 4;
            this.radioButton44.TabStop = true;
            this.radioButton44.UseVisualStyleBackColor = true;
            // 
            // panel9
            // 
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel9.Controls.Add(this.radioButton11);
            this.panel9.Controls.Add(this.label27);
            this.panel9.Controls.Add(this.radioButton12);
            this.panel9.Location = new System.Drawing.Point(8, 245);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(351, 23);
            this.panel9.TabIndex = 7;
            // 
            // radioButton11
            // 
            this.radioButton11.AutoSize = true;
            this.radioButton11.Location = new System.Drawing.Point(332, 4);
            this.radioButton11.Name = "radioButton11";
            this.radioButton11.Size = new System.Drawing.Size(14, 13);
            this.radioButton11.TabIndex = 4;
            this.radioButton11.TabStop = true;
            this.radioButton11.UseVisualStyleBackColor = true;
            this.radioButton11.Visible = false;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(3, 3);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(194, 14);
            this.label27.TabIndex = 1;
            this.label27.Text = "Ha presentado reacción alérgica a:";
            // 
            // radioButton12
            // 
            this.radioButton12.AutoSize = true;
            this.radioButton12.Location = new System.Drawing.Point(308, 4);
            this.radioButton12.Name = "radioButton12";
            this.radioButton12.Size = new System.Drawing.Size(14, 13);
            this.radioButton12.TabIndex = 4;
            this.radioButton12.TabStop = true;
            this.radioButton12.UseVisualStyleBackColor = true;
            this.radioButton12.Visible = false;
            // 
            // panel25
            // 
            this.panel25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel25.Controls.Add(this.radioButton41);
            this.panel25.Controls.Add(this.label42);
            this.panel25.Controls.Add(this.radioButton42);
            this.panel25.Location = new System.Drawing.Point(361, 223);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(351, 23);
            this.panel25.TabIndex = 7;
            // 
            // radioButton41
            // 
            this.radioButton41.AutoSize = true;
            this.radioButton41.Location = new System.Drawing.Point(332, 4);
            this.radioButton41.Name = "radioButton41";
            this.radioButton41.Size = new System.Drawing.Size(14, 13);
            this.radioButton41.TabIndex = 4;
            this.radioButton41.TabStop = true;
            this.radioButton41.UseVisualStyleBackColor = true;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(3, 3);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(101, 14);
            this.label42.TabIndex = 1;
            this.label42.Text = "-Fiebre reumática";
            // 
            // radioButton42
            // 
            this.radioButton42.AutoSize = true;
            this.radioButton42.Location = new System.Drawing.Point(308, 4);
            this.radioButton42.Name = "radioButton42";
            this.radioButton42.Size = new System.Drawing.Size(14, 13);
            this.radioButton42.TabIndex = 4;
            this.radioButton42.TabStop = true;
            this.radioButton42.UseVisualStyleBackColor = true;
            // 
            // panel8
            // 
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel8.Controls.Add(this.radioButton9);
            this.panel8.Controls.Add(this.label26);
            this.panel8.Controls.Add(this.radioButton10);
            this.panel8.Location = new System.Drawing.Point(8, 223);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(351, 23);
            this.panel8.TabIndex = 7;
            // 
            // radioButton9
            // 
            this.radioButton9.AutoSize = true;
            this.radioButton9.Location = new System.Drawing.Point(332, 4);
            this.radioButton9.Name = "radioButton9";
            this.radioButton9.Size = new System.Drawing.Size(14, 13);
            this.radioButton9.TabIndex = 4;
            this.radioButton9.TabStop = true;
            this.radioButton9.UseVisualStyleBackColor = true;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(3, 3);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(199, 14);
            this.label26.TabIndex = 1;
            this.label26.Text = "¿Ha consumido o consume drogas?";
            // 
            // radioButton10
            // 
            this.radioButton10.AutoSize = true;
            this.radioButton10.Location = new System.Drawing.Point(308, 4);
            this.radioButton10.Name = "radioButton10";
            this.radioButton10.Size = new System.Drawing.Size(14, 13);
            this.radioButton10.TabIndex = 4;
            this.radioButton10.TabStop = true;
            this.radioButton10.UseVisualStyleBackColor = true;
            // 
            // panel24
            // 
            this.panel24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel24.Controls.Add(this.radioButton39);
            this.panel24.Controls.Add(this.label41);
            this.panel24.Controls.Add(this.radioButton40);
            this.panel24.Location = new System.Drawing.Point(361, 201);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(351, 23);
            this.panel24.TabIndex = 7;
            // 
            // radioButton39
            // 
            this.radioButton39.AutoSize = true;
            this.radioButton39.Location = new System.Drawing.Point(332, 4);
            this.radioButton39.Name = "radioButton39";
            this.radioButton39.Size = new System.Drawing.Size(14, 13);
            this.radioButton39.TabIndex = 4;
            this.radioButton39.TabStop = true;
            this.radioButton39.UseVisualStyleBackColor = true;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(3, 3);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(58, 14);
            this.label41.TabIndex = 1;
            this.label41.Text = "-Hepatitis";
            // 
            // radioButton40
            // 
            this.radioButton40.AutoSize = true;
            this.radioButton40.Location = new System.Drawing.Point(308, 4);
            this.radioButton40.Name = "radioButton40";
            this.radioButton40.Size = new System.Drawing.Size(14, 13);
            this.radioButton40.TabIndex = 4;
            this.radioButton40.TabStop = true;
            this.radioButton40.UseVisualStyleBackColor = true;
            // 
            // panel7
            // 
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.radioButton7);
            this.panel7.Controls.Add(this.label25);
            this.panel7.Controls.Add(this.radioButton8);
            this.panel7.Location = new System.Drawing.Point(8, 201);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(351, 23);
            this.panel7.TabIndex = 7;
            // 
            // radioButton7
            // 
            this.radioButton7.AutoSize = true;
            this.radioButton7.Location = new System.Drawing.Point(332, 4);
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.Size = new System.Drawing.Size(14, 13);
            this.radioButton7.TabIndex = 4;
            this.radioButton7.TabStop = true;
            this.radioButton7.UseVisualStyleBackColor = true;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(3, 3);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(239, 14);
            this.label25.TabIndex = 1;
            this.label25.Text = "¿Ha recibido alguna transfusión sanguínea?";
            // 
            // radioButton8
            // 
            this.radioButton8.AutoSize = true;
            this.radioButton8.Location = new System.Drawing.Point(308, 4);
            this.radioButton8.Name = "radioButton8";
            this.radioButton8.Size = new System.Drawing.Size(14, 13);
            this.radioButton8.TabIndex = 4;
            this.radioButton8.TabStop = true;
            this.radioButton8.UseVisualStyleBackColor = true;
            // 
            // panel23
            // 
            this.panel23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel23.Controls.Add(this.radioButton37);
            this.panel23.Controls.Add(this.label40);
            this.panel23.Controls.Add(this.radioButton38);
            this.panel23.Location = new System.Drawing.Point(361, 179);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(351, 23);
            this.panel23.TabIndex = 7;
            // 
            // radioButton37
            // 
            this.radioButton37.AutoSize = true;
            this.radioButton37.Location = new System.Drawing.Point(332, 4);
            this.radioButton37.Name = "radioButton37";
            this.radioButton37.Size = new System.Drawing.Size(14, 13);
            this.radioButton37.TabIndex = 4;
            this.radioButton37.TabStop = true;
            this.radioButton37.UseVisualStyleBackColor = true;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(3, 3);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(132, 14);
            this.label40.TabIndex = 1;
            this.label40.Text = "-Problemas del corazón";
            // 
            // radioButton38
            // 
            this.radioButton38.AutoSize = true;
            this.radioButton38.Location = new System.Drawing.Point(308, 4);
            this.radioButton38.Name = "radioButton38";
            this.radioButton38.Size = new System.Drawing.Size(14, 13);
            this.radioButton38.TabIndex = 4;
            this.radioButton38.TabStop = true;
            this.radioButton38.UseVisualStyleBackColor = true;
            // 
            // panel6
            // 
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.radioButton5);
            this.panel6.Controls.Add(this.label24);
            this.panel6.Controls.Add(this.radioButton6);
            this.panel6.Location = new System.Drawing.Point(8, 179);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(351, 23);
            this.panel6.TabIndex = 7;
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Location = new System.Drawing.Point(332, 4);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(14, 13);
            this.radioButton5.TabIndex = 4;
            this.radioButton5.TabStop = true;
            this.radioButton5.UseVisualStyleBackColor = true;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(3, 3);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(282, 14);
            this.label24.TabIndex = 1;
            this.label24.Text = "¿Le han practicado alguna intervención quirúrgica?";
            // 
            // radioButton6
            // 
            this.radioButton6.AutoSize = true;
            this.radioButton6.Location = new System.Drawing.Point(308, 4);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(14, 13);
            this.radioButton6.TabIndex = 4;
            this.radioButton6.TabStop = true;
            this.radioButton6.UseVisualStyleBackColor = true;
            // 
            // panel22
            // 
            this.panel22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel22.Controls.Add(this.radioButton35);
            this.panel22.Controls.Add(this.label39);
            this.panel22.Controls.Add(this.radioButton36);
            this.panel22.Location = new System.Drawing.Point(361, 157);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(351, 23);
            this.panel22.TabIndex = 7;
            // 
            // radioButton35
            // 
            this.radioButton35.AutoSize = true;
            this.radioButton35.Location = new System.Drawing.Point(332, 4);
            this.radioButton35.Name = "radioButton35";
            this.radioButton35.Size = new System.Drawing.Size(14, 13);
            this.radioButton35.TabIndex = 4;
            this.radioButton35.TabStop = true;
            this.radioButton35.UseVisualStyleBackColor = true;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(3, 3);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(142, 14);
            this.label39.TabIndex = 1;
            this.label39.Text = "-Enfermedades venéreas";
            // 
            // radioButton36
            // 
            this.radioButton36.AutoSize = true;
            this.radioButton36.Location = new System.Drawing.Point(308, 4);
            this.radioButton36.Name = "radioButton36";
            this.radioButton36.Size = new System.Drawing.Size(14, 13);
            this.radioButton36.TabIndex = 4;
            this.radioButton36.TabStop = true;
            this.radioButton36.UseVisualStyleBackColor = true;
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.radioButton3);
            this.panel5.Controls.Add(this.label23);
            this.panel5.Controls.Add(this.radioButton4);
            this.panel5.Location = new System.Drawing.Point(8, 157);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(351, 23);
            this.panel5.TabIndex = 7;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(332, 4);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(14, 13);
            this.radioButton3.TabIndex = 4;
            this.radioButton3.TabStop = true;
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(3, 3);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(233, 14);
            this.label23.TabIndex = 1;
            this.label23.Text = "¿Toma actualmente algún medicamento?";
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(308, 4);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(14, 13);
            this.radioButton4.TabIndex = 4;
            this.radioButton4.TabStop = true;
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // panel21
            // 
            this.panel21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel21.Controls.Add(this.radioButton33);
            this.panel21.Controls.Add(this.label38);
            this.panel21.Controls.Add(this.radioButton34);
            this.panel21.Location = new System.Drawing.Point(361, 135);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(351, 23);
            this.panel21.TabIndex = 6;
            // 
            // radioButton33
            // 
            this.radioButton33.AutoSize = true;
            this.radioButton33.Location = new System.Drawing.Point(332, 5);
            this.radioButton33.Name = "radioButton33";
            this.radioButton33.Size = new System.Drawing.Size(14, 13);
            this.radioButton33.TabIndex = 4;
            this.radioButton33.TabStop = true;
            this.radioButton33.UseVisualStyleBackColor = true;
            this.radioButton33.Visible = false;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(3, 4);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(126, 14);
            this.label38.TabIndex = 1;
            this.label38.Text = "Sufre o ha sufrido de:";
            // 
            // radioButton34
            // 
            this.radioButton34.AutoSize = true;
            this.radioButton34.Location = new System.Drawing.Point(308, 5);
            this.radioButton34.Name = "radioButton34";
            this.radioButton34.Size = new System.Drawing.Size(14, 13);
            this.radioButton34.TabIndex = 4;
            this.radioButton34.TabStop = true;
            this.radioButton34.UseVisualStyleBackColor = true;
            this.radioButton34.Visible = false;
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.radioButton2);
            this.panel4.Controls.Add(this.label22);
            this.panel4.Controls.Add(this.radioButton1);
            this.panel4.Location = new System.Drawing.Point(8, 135);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(351, 23);
            this.panel4.TabIndex = 6;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(332, 5);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(14, 13);
            this.radioButton2.TabIndex = 1;
            this.radioButton2.TabStop = true;
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(3, 4);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(215, 14);
            this.label22.TabIndex = 1;
            this.label22.Text = "¿Esta usted bajo tratamiento médico?";
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(308, 5);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(14, 13);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.TabStop = true;
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Silver;
            this.panel3.Controls.Add(this.checkBox2);
            this.panel3.Controls.Add(this.checkBox1);
            this.panel3.Controls.Add(this.label92);
            this.panel3.Controls.Add(this.label91);
            this.panel3.Location = new System.Drawing.Point(8, 108);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(704, 21);
            this.panel3.TabIndex = 3;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(333, 1);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(43, 18);
            this.checkBox2.TabIndex = 3;
            this.checkBox2.Text = "NO";
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(275, 1);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(37, 18);
            this.checkBox1.TabIndex = 2;
            this.checkBox1.Text = "SI";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label92.Location = new System.Drawing.Point(682, 2);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(22, 14);
            this.label92.TabIndex = 1;
            this.label92.Text = "No";
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label91.Location = new System.Drawing.Point(659, 2);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(16, 14);
            this.label91.TabIndex = 1;
            this.label91.Text = "Si";
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(151, 9);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox3.Size = new System.Drawing.Size(557, 36);
            this.textBox3.TabIndex = 1;
            // 
            // textBox6
            // 
            this.textBox6.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox6.Location = new System.Drawing.Point(730, 151);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(224, 22);
            this.textBox6.TabIndex = 4;
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.Location = new System.Drawing.Point(730, 107);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(224, 22);
            this.textBox5.TabIndex = 3;
            // 
            // textBox10
            // 
            this.textBox10.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox10.Location = new System.Drawing.Point(730, 258);
            this.textBox10.Multiline = true;
            this.textBox10.Name = "textBox10";
            this.textBox10.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox10.Size = new System.Drawing.Size(224, 208);
            this.textBox10.TabIndex = 8;
            // 
            // textBox9
            // 
            this.textBox9.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox9.Location = new System.Drawing.Point(151, 78);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(557, 22);
            this.textBox9.TabIndex = 7;
            // 
            // textBox8
            // 
            this.textBox8.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox8.Location = new System.Drawing.Point(151, 51);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(557, 22);
            this.textBox8.TabIndex = 6;
            // 
            // textBox7
            // 
            this.textBox7.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox7.Location = new System.Drawing.Point(730, 193);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(224, 22);
            this.textBox7.TabIndex = 5;
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(730, 65);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(224, 22);
            this.textBox4.TabIndex = 2;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(730, 23);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(221, 22);
            this.textBox2.TabIndex = 0;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(4, 81);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(104, 14);
            this.label20.TabIndex = 1;
            this.label20.Text = "Otro indique cual:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(4, 51);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(133, 14);
            this.label19.TabIndex = 1;
            this.label19.Text = "Restauración protésica:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(727, 241);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(113, 14);
            this.label21.TabIndex = 1;
            this.label21.Text = "Enfermedad actual:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(727, 176);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(158, 14);
            this.label16.TabIndex = 1;
            this.label16.Text = "Sangramiento en las encías:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(727, 136);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(50, 14);
            this.label18.TabIndex = 1;
            this.label18.Text = "Control:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(727, 90);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(39, 14);
            this.label17.TabIndex = 1;
            this.label17.Text = "Dolor:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(727, 48);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(114, 14);
            this.label15.TabIndex = 1;
            this.label15.Text = "Motivo de consulta:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(4, 15);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(141, 14);
            this.label14.TabIndex = 1;
            this.label14.Text = "Antecedentes familiares:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(727, 6);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(102, 14);
            this.label13.TabIndex = 0;
            this.label13.Text = "Odont. Tratante:";
            // 
            // tabPage2
            // 
            this.tabPage2.AutoScroll = true;
            this.tabPage2.Controls.Add(this.pictureBox7);
            this.tabPage2.Controls.Add(this.pictureBox6);
            this.tabPage2.Controls.Add(this.pictureBox5);
            this.tabPage2.Controls.Add(this.pictureBox4);
            this.tabPage2.Controls.Add(this.pictureBox3);
            this.tabPage2.Controls.Add(this.pictureBox2);
            this.tabPage2.Controls.Add(this.checkedListBox1);
            this.tabPage2.Controls.Add(this.panel48);
            this.tabPage2.Controls.Add(this.panel45);
            this.tabPage2.Controls.Add(this.panel17);
            this.tabPage2.Controls.Add(this.label68);
            this.tabPage2.Controls.Add(this.textBox15);
            this.tabPage2.Controls.Add(this.textBox27);
            this.tabPage2.Controls.Add(this.textBox26);
            this.tabPage2.Controls.Add(this.textBox25);
            this.tabPage2.Controls.Add(this.textBox24);
            this.tabPage2.Controls.Add(this.textBox23);
            this.tabPage2.Controls.Add(this.textBox22);
            this.tabPage2.Controls.Add(this.textBox21);
            this.tabPage2.Controls.Add(this.textBox20);
            this.tabPage2.Controls.Add(this.textBox19);
            this.tabPage2.Controls.Add(this.textBox18);
            this.tabPage2.Controls.Add(this.textBox17);
            this.tabPage2.Controls.Add(this.textBox16);
            this.tabPage2.Controls.Add(this.textBox14);
            this.tabPage2.Controls.Add(this.textBox13);
            this.tabPage2.Controls.Add(this.textBox12);
            this.tabPage2.Controls.Add(this.textBox11);
            this.tabPage2.Controls.Add(this.label66);
            this.tabPage2.Controls.Add(this.label74);
            this.tabPage2.Controls.Add(this.label73);
            this.tabPage2.Controls.Add(this.label72);
            this.tabPage2.Controls.Add(this.label71);
            this.tabPage2.Controls.Add(this.label77);
            this.tabPage2.Controls.Add(this.label78);
            this.tabPage2.Controls.Add(this.label81);
            this.tabPage2.Controls.Add(this.label80);
            this.tabPage2.Controls.Add(this.label96);
            this.tabPage2.Controls.Add(this.label95);
            this.tabPage2.Controls.Add(this.label102);
            this.tabPage2.Controls.Add(this.label101);
            this.tabPage2.Controls.Add(this.label100);
            this.tabPage2.Controls.Add(this.label99);
            this.tabPage2.Controls.Add(this.label98);
            this.tabPage2.Controls.Add(this.label97);
            this.tabPage2.Controls.Add(this.label94);
            this.tabPage2.Controls.Add(this.label82);
            this.tabPage2.Controls.Add(this.label79);
            this.tabPage2.Controls.Add(this.label70);
            this.tabPage2.Controls.Add(this.label67);
            this.tabPage2.Controls.Add(this.label75);
            this.tabPage2.Controls.Add(this.label65);
            this.tabPage2.Controls.Add(this.label64);
            this.tabPage2.Controls.Add(this.label63);
            this.tabPage2.Controls.Add(this.label62);
            this.tabPage2.Controls.Add(this.odontograma);
            this.tabPage2.Location = new System.Drawing.Point(4, 23);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(977, 585);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Página 2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // pictureBox7
            // 
            this.pictureBox7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(621, 674);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(16, 16);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 4;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(621, 652);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(16, 16);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 4;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(621, 630);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(16, 16);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 4;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(621, 608);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(16, 16);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 4;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(621, 586);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(16, 16);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 4;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(621, 564);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(16, 16);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 4;
            this.pictureBox2.TabStop = false;
            // 
            // checkedListBox1
            // 
            this.checkedListBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.checkedListBox1.CheckOnClick = true;
            this.checkedListBox1.FormattingEnabled = true;
            this.checkedListBox1.Items.AddRange(new object[] {
            "Periodoncia",
            "Endodoncia",
            "Cirugía",
            "Estomatología",
            "Radiología",
            "Otros"});
            this.checkedListBox1.Location = new System.Drawing.Point(621, 395);
            this.checkedListBox1.Name = "checkedListBox1";
            this.checkedListBox1.Size = new System.Drawing.Size(120, 119);
            this.checkedListBox1.TabIndex = 17;
            // 
            // panel48
            // 
            this.panel48.BackColor = System.Drawing.Color.LightGray;
            this.panel48.Controls.Add(this.label93);
            this.panel48.Location = new System.Drawing.Point(1, 314);
            this.panel48.Name = "panel48";
            this.panel48.Size = new System.Drawing.Size(777, 31);
            this.panel48.TabIndex = 1;
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label93.Location = new System.Drawing.Point(2, 9);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(92, 14);
            this.label93.TabIndex = 0;
            this.label93.Text = "Odontograma";
            // 
            // panel45
            // 
            this.panel45.BackColor = System.Drawing.Color.LightGray;
            this.panel45.Controls.Add(this.label76);
            this.panel45.Location = new System.Drawing.Point(1, 188);
            this.panel45.Name = "panel45";
            this.panel45.Size = new System.Drawing.Size(777, 31);
            this.panel45.TabIndex = 1;
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label76.Location = new System.Drawing.Point(2, 9);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(181, 14);
            this.label76.TabIndex = 0;
            this.label76.Text = "Exámenes Complementarios:";
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.Color.LightGray;
            this.panel17.Controls.Add(this.label69);
            this.panel17.Location = new System.Drawing.Point(4, 117);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(774, 31);
            this.panel17.TabIndex = 1;
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label69.Location = new System.Drawing.Point(2, 9);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(168, 14);
            this.label69.TabIndex = 0;
            this.label69.Text = "Examen Clínico IntraBucal:";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(529, 79);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(144, 14);
            this.label68.TabIndex = 0;
            this.label68.Text = "Región hioidea y tiroidea:";
            // 
            // textBox15
            // 
            this.textBox15.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox15.Location = new System.Drawing.Point(468, 35);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(310, 22);
            this.textBox15.TabIndex = 4;
            // 
            // textBox27
            // 
            this.textBox27.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox27.Location = new System.Drawing.Point(102, 262);
            this.textBox27.Multiline = true;
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(676, 46);
            this.textBox27.TabIndex = 16;
            // 
            // textBox26
            // 
            this.textBox26.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox26.Location = new System.Drawing.Point(634, 228);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(144, 22);
            this.textBox26.TabIndex = 15;
            // 
            // textBox25
            // 
            this.textBox25.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox25.Location = new System.Drawing.Point(396, 228);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(132, 22);
            this.textBox25.TabIndex = 14;
            // 
            // textBox24
            // 
            this.textBox24.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox24.Location = new System.Drawing.Point(202, 228);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(132, 22);
            this.textBox24.TabIndex = 13;
            // 
            // textBox23
            // 
            this.textBox23.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox23.Location = new System.Drawing.Point(701, 160);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(77, 22);
            this.textBox23.TabIndex = 12;
            // 
            // textBox22
            // 
            this.textBox22.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox22.Location = new System.Drawing.Point(540, 160);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(100, 22);
            this.textBox22.TabIndex = 11;
            // 
            // textBox21
            // 
            this.textBox21.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox21.Location = new System.Drawing.Point(377, 160);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(100, 22);
            this.textBox21.TabIndex = 10;
            // 
            // textBox20
            // 
            this.textBox20.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox20.Location = new System.Drawing.Point(226, 160);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(100, 22);
            this.textBox20.TabIndex = 9;
            // 
            // textBox19
            // 
            this.textBox19.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox19.Location = new System.Drawing.Point(63, 160);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(100, 22);
            this.textBox19.TabIndex = 8;
            // 
            // textBox18
            // 
            this.textBox18.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox18.Location = new System.Drawing.Point(676, 71);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(102, 22);
            this.textBox18.TabIndex = 7;
            // 
            // textBox17
            // 
            this.textBox17.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox17.Location = new System.Drawing.Point(410, 71);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(113, 22);
            this.textBox17.TabIndex = 6;
            // 
            // textBox16
            // 
            this.textBox16.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox16.Location = new System.Drawing.Point(240, 71);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(113, 22);
            this.textBox16.TabIndex = 5;
            // 
            // textBox14
            // 
            this.textBox14.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox14.Location = new System.Drawing.Point(138, 35);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(263, 22);
            this.textBox14.TabIndex = 3;
            // 
            // textBox13
            // 
            this.textBox13.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox13.Location = new System.Drawing.Point(622, 7);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(156, 22);
            this.textBox13.TabIndex = 2;
            // 
            // textBox12
            // 
            this.textBox12.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox12.Location = new System.Drawing.Point(362, 7);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(143, 22);
            this.textBox12.TabIndex = 1;
            // 
            // textBox11
            // 
            this.textBox11.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox11.Location = new System.Drawing.Point(139, 7);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(177, 22);
            this.textBox11.TabIndex = 0;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(359, 79);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(45, 14);
            this.label66.TabIndex = 0;
            this.label66.Text = "Orejas:";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Location = new System.Drawing.Point(646, 168);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(49, 14);
            this.label74.TabIndex = 0;
            this.label74.Text = "Paladar:";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(483, 168);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(51, 14);
            this.label73.TabIndex = 0;
            this.label73.Text = "Lengua:";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(332, 168);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(39, 14);
            this.label72.TabIndex = 0;
            this.label72.Text = "Encía:";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(169, 168);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(51, 14);
            this.label71.TabIndex = 0;
            this.label71.Text = "Mucosa:";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label77.Location = new System.Drawing.Point(7, 236);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(27, 14);
            this.label77.TabIndex = 0;
            this.label77.Text = "Rx:";
            // 
            // label78
            // 
            this.label78.Location = new System.Drawing.Point(40, 222);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(83, 48);
            this.label78.TabIndex = 0;
            this.label78.Text = "Panoramica\r\nCoronal\r\nPeriapical";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Location = new System.Drawing.Point(534, 236);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(94, 14);
            this.label81.TabIndex = 0;
            this.label81.Text = "Tensión arterial:";
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Location = new System.Drawing.Point(340, 236);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(50, 14);
            this.label80.TabIndex = 0;
            this.label80.Text = "Modelo:";
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Location = new System.Drawing.Point(650, 542);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(78, 14);
            this.label96.TabIndex = 0;
            this.label96.Text = "SIMBOLOGÍA";
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Location = new System.Drawing.Point(650, 369);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(91, 14);
            this.label95.TabIndex = 0;
            this.label95.Text = "DERIVACIONES";
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Location = new System.Drawing.Point(643, 674);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(42, 14);
            this.label102.TabIndex = 0;
            this.label102.Text = "Tramo";
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.Location = new System.Drawing.Point(643, 652);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(45, 14);
            this.label101.TabIndex = 0;
            this.label101.Text = "Corona";
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Location = new System.Drawing.Point(643, 630);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(102, 14);
            this.label100.TabIndex = 0;
            this.label100.Text = "Obturación (rojo)";
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Location = new System.Drawing.Point(643, 610);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(72, 14);
            this.label99.TabIndex = 0;
            this.label99.Text = "Caries (azul)";
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Location = new System.Drawing.Point(643, 586);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(96, 14);
            this.label98.TabIndex = 0;
            this.label98.Text = "Diente a extraer";
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Location = new System.Drawing.Point(643, 564);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(91, 14);
            this.label97.TabIndex = 0;
            this.label97.Text = "Diente ausente";
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Location = new System.Drawing.Point(340, 348);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(87, 14);
            this.label94.TabIndex = 0;
            this.label94.Text = "Examen Clínico";
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(7, 270);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(89, 14);
            this.label82.TabIndex = 0;
            this.label82.Text = "Observaciones:";
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Location = new System.Drawing.Point(124, 236);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(72, 14);
            this.label79.TabIndex = 0;
            this.label79.Text = "Laboratorio:";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(7, 168);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(50, 14);
            this.label70.TabIndex = 0;
            this.label70.Text = "Carrillos:";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(7, 79);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(227, 14);
            this.label67.TabIndex = 0;
            this.label67.Text = "A.T.M (articulación temporomandibular):";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(407, 43);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(55, 14);
            this.label75.TabIndex = 0;
            this.label75.Text = "Ganglios:";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(7, 43);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(126, 14);
            this.label65.TabIndex = 0;
            this.label65.Text = "Palpación de ganglios:";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(511, 15);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(105, 14);
            this.label64.TabIndex = 0;
            this.label64.Text = "Labios y comisura:";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(322, 15);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(34, 14);
            this.label63.TabIndex = 0;
            this.label63.Text = "Cara:";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(6, 15);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(127, 14);
            this.label62.TabIndex = 0;
            this.label62.Text = "Aspecto del paciente:";
            // 
            // odontograma
            // 
            this.odontograma.Image = ((System.Drawing.Image)(resources.GetObject("odontograma.Image")));
            this.odontograma.Location = new System.Drawing.Point(10, 369);
            this.odontograma.Name = "odontograma";
            this.odontograma.Size = new System.Drawing.Size(577, 395);
            this.odontograma.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.odontograma.TabIndex = 2;
            this.odontograma.TabStop = false;
            this.odontograma.Click += new System.EventHandler(this.odontograma_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.dateTimePicker7);
            this.tabPage3.Controls.Add(this.dateTimePicker4);
            this.tabPage3.Controls.Add(this.dateTimePicker6);
            this.tabPage3.Controls.Add(this.dateTimePicker3);
            this.tabPage3.Controls.Add(this.dateTimePicker5);
            this.tabPage3.Controls.Add(this.dateTimePicker2);
            this.tabPage3.Controls.Add(this.textBox34);
            this.tabPage3.Controls.Add(this.panel47);
            this.tabPage3.Controls.Add(this.textBox33);
            this.tabPage3.Controls.Add(this.textBox31);
            this.tabPage3.Controls.Add(this.textBox32);
            this.tabPage3.Controls.Add(this.textBox30);
            this.tabPage3.Controls.Add(this.textBox29);
            this.tabPage3.Controls.Add(this.panel46);
            this.tabPage3.Controls.Add(this.label88);
            this.tabPage3.Controls.Add(this.label86);
            this.tabPage3.Controls.Add(this.label87);
            this.tabPage3.Controls.Add(this.label83);
            this.tabPage3.Controls.Add(this.textBox28);
            this.tabPage3.Location = new System.Drawing.Point(4, 23);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(977, 585);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Página 3";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // dateTimePicker7
            // 
            this.dateTimePicker7.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker7.Location = new System.Drawing.Point(396, 295);
            this.dateTimePicker7.Name = "dateTimePicker7";
            this.dateTimePicker7.Size = new System.Drawing.Size(107, 22);
            this.dateTimePicker7.TabIndex = 11;
            // 
            // dateTimePicker4
            // 
            this.dateTimePicker4.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker4.Location = new System.Drawing.Point(9, 295);
            this.dateTimePicker4.Name = "dateTimePicker4";
            this.dateTimePicker4.Size = new System.Drawing.Size(107, 22);
            this.dateTimePicker4.TabIndex = 5;
            // 
            // dateTimePicker6
            // 
            this.dateTimePicker6.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker6.Location = new System.Drawing.Point(396, 245);
            this.dateTimePicker6.Name = "dateTimePicker6";
            this.dateTimePicker6.Size = new System.Drawing.Size(107, 22);
            this.dateTimePicker6.TabIndex = 9;
            // 
            // dateTimePicker3
            // 
            this.dateTimePicker3.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker3.Location = new System.Drawing.Point(9, 245);
            this.dateTimePicker3.Name = "dateTimePicker3";
            this.dateTimePicker3.Size = new System.Drawing.Size(107, 22);
            this.dateTimePicker3.TabIndex = 3;
            // 
            // dateTimePicker5
            // 
            this.dateTimePicker5.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker5.Location = new System.Drawing.Point(396, 195);
            this.dateTimePicker5.Name = "dateTimePicker5";
            this.dateTimePicker5.Size = new System.Drawing.Size(107, 22);
            this.dateTimePicker5.TabIndex = 7;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker2.Location = new System.Drawing.Point(9, 195);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(107, 22);
            this.dateTimePicker2.TabIndex = 1;
            // 
            // textBox34
            // 
            this.textBox34.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox34.Location = new System.Drawing.Point(509, 295);
            this.textBox34.Multiline = true;
            this.textBox34.Name = "textBox34";
            this.textBox34.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox34.Size = new System.Drawing.Size(243, 44);
            this.textBox34.TabIndex = 12;
            // 
            // panel47
            // 
            this.panel47.BackColor = System.Drawing.Color.LightGray;
            this.panel47.Controls.Add(this.label85);
            this.panel47.Location = new System.Drawing.Point(4, 133);
            this.panel47.Name = "panel47";
            this.panel47.Size = new System.Drawing.Size(792, 31);
            this.panel47.TabIndex = 2;
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label85.Location = new System.Drawing.Point(2, 9);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(168, 14);
            this.label85.TabIndex = 0;
            this.label85.Text = "Secuencia del Tratamiento";
            // 
            // textBox33
            // 
            this.textBox33.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox33.Location = new System.Drawing.Point(509, 245);
            this.textBox33.Multiline = true;
            this.textBox33.Name = "textBox33";
            this.textBox33.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox33.Size = new System.Drawing.Size(243, 44);
            this.textBox33.TabIndex = 10;
            // 
            // textBox31
            // 
            this.textBox31.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox31.Location = new System.Drawing.Point(122, 295);
            this.textBox31.Multiline = true;
            this.textBox31.Name = "textBox31";
            this.textBox31.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox31.Size = new System.Drawing.Size(243, 44);
            this.textBox31.TabIndex = 6;
            // 
            // textBox32
            // 
            this.textBox32.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox32.Location = new System.Drawing.Point(509, 195);
            this.textBox32.Multiline = true;
            this.textBox32.Name = "textBox32";
            this.textBox32.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox32.Size = new System.Drawing.Size(243, 44);
            this.textBox32.TabIndex = 8;
            // 
            // textBox30
            // 
            this.textBox30.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox30.Location = new System.Drawing.Point(122, 245);
            this.textBox30.Multiline = true;
            this.textBox30.Name = "textBox30";
            this.textBox30.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox30.Size = new System.Drawing.Size(243, 44);
            this.textBox30.TabIndex = 4;
            // 
            // textBox29
            // 
            this.textBox29.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox29.Location = new System.Drawing.Point(122, 195);
            this.textBox29.Multiline = true;
            this.textBox29.Name = "textBox29";
            this.textBox29.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox29.Size = new System.Drawing.Size(243, 44);
            this.textBox29.TabIndex = 2;
            // 
            // panel46
            // 
            this.panel46.BackColor = System.Drawing.Color.LightGray;
            this.panel46.Controls.Add(this.label84);
            this.panel46.Location = new System.Drawing.Point(3, 3);
            this.panel46.Name = "panel46";
            this.panel46.Size = new System.Drawing.Size(792, 31);
            this.panel46.TabIndex = 2;
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label84.Location = new System.Drawing.Point(2, 9);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(218, 14);
            this.label84.TabIndex = 0;
            this.label84.Text = "Diagnóstico y Plan de Tratamiento";
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Location = new System.Drawing.Point(540, 178);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(156, 14);
            this.label88.TabIndex = 1;
            this.label88.Text = "Descripción del tratamiento";
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Location = new System.Drawing.Point(119, 178);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(156, 14);
            this.label86.TabIndex = 1;
            this.label86.Text = "Descripción del tratamiento";
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Location = new System.Drawing.Point(393, 178);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(39, 14);
            this.label87.TabIndex = 1;
            this.label87.Text = "Fecha";
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Location = new System.Drawing.Point(6, 178);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(39, 14);
            this.label83.TabIndex = 1;
            this.label83.Text = "Fecha";
            // 
            // textBox28
            // 
            this.textBox28.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox28.Location = new System.Drawing.Point(4, 40);
            this.textBox28.Multiline = true;
            this.textBox28.Name = "textBox28";
            this.textBox28.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox28.Size = new System.Drawing.Size(789, 87);
            this.textBox28.TabIndex = 0;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(742, 692);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 35);
            this.button2.TabIndex = 1;
            this.button2.Text = "Cancelar";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(661, 692);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 35);
            this.button3.TabIndex = 1;
            this.button3.Text = "Guardar";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(580, 692);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 35);
            this.button4.TabIndex = 1;
            this.button4.Text = "Nuevo";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(499, 692);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 35);
            this.button5.TabIndex = 2;
            this.button5.Text = "Formato";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(418, 692);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 35);
            this.button6.TabIndex = 3;
            this.button6.Text = "Historial";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // Dental
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1008, 729);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Dental";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Dental";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Activated += new System.EventHandler(this.Dental_Activated);
            this.Load += new System.EventHandler(this.Dental_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.panel49.ResumeLayout(false);
            this.panel49.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.panel43.ResumeLayout(false);
            this.panel43.PerformLayout();
            this.panel36.ResumeLayout(false);
            this.panel36.PerformLayout();
            this.panel40.ResumeLayout(false);
            this.panel40.PerformLayout();
            this.panel39.ResumeLayout(false);
            this.panel39.PerformLayout();
            this.panel38.ResumeLayout(false);
            this.panel38.PerformLayout();
            this.panel37.ResumeLayout(false);
            this.panel37.PerformLayout();
            this.panel20.ResumeLayout(false);
            this.panel20.PerformLayout();
            this.panel42.ResumeLayout(false);
            this.panel42.PerformLayout();
            this.panel35.ResumeLayout(false);
            this.panel35.PerformLayout();
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            this.panel41.ResumeLayout(false);
            this.panel41.PerformLayout();
            this.panel34.ResumeLayout(false);
            this.panel34.PerformLayout();
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            this.panel44.ResumeLayout(false);
            this.panel44.PerformLayout();
            this.panel33.ResumeLayout(false);
            this.panel33.PerformLayout();
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            this.panel32.ResumeLayout(false);
            this.panel32.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.panel31.ResumeLayout(false);
            this.panel31.PerformLayout();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.panel30.ResumeLayout(false);
            this.panel30.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.panel29.ResumeLayout(false);
            this.panel29.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel28.ResumeLayout(false);
            this.panel28.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel27.ResumeLayout(false);
            this.panel27.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel26.ResumeLayout(false);
            this.panel26.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel25.ResumeLayout(false);
            this.panel25.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel24.ResumeLayout(false);
            this.panel24.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel23.ResumeLayout(false);
            this.panel23.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel22.ResumeLayout(false);
            this.panel22.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel21.ResumeLayout(false);
            this.panel21.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel48.ResumeLayout(false);
            this.panel48.PerformLayout();
            this.panel45.ResumeLayout(false);
            this.panel45.PerformLayout();
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.odontograma)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.panel47.ResumeLayout(false);
            this.panel47.PerformLayout();
            this.panel46.ResumeLayout(false);
            this.panel46.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.RadioButton radioButton13;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.RadioButton radioButton14;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.RadioButton radioButton11;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.RadioButton radioButton12;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.RadioButton radioButton9;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.RadioButton radioButton10;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.RadioButton radioButton8;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.RadioButton radioButton31;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.RadioButton radioButton32;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.RadioButton radioButton29;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.RadioButton radioButton30;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.RadioButton radioButton27;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.RadioButton radioButton28;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.RadioButton radioButton25;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.RadioButton radioButton26;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.RadioButton radioButton23;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.RadioButton radioButton24;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.RadioButton radioButton21;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.RadioButton radioButton22;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.RadioButton radioButton19;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.RadioButton radioButton20;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.RadioButton radioButton17;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.RadioButton radioButton18;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.RadioButton radioButton15;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.RadioButton radioButton16;
        private System.Windows.Forms.Panel panel43;
        private System.Windows.Forms.RadioButton radioButton77;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.RadioButton radioButton78;
        private System.Windows.Forms.Panel panel36;
        private System.Windows.Forms.RadioButton radioButton63;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.RadioButton radioButton64;
        private System.Windows.Forms.Panel panel40;
        private System.Windows.Forms.RadioButton radioButton71;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.RadioButton radioButton72;
        private System.Windows.Forms.Panel panel39;
        private System.Windows.Forms.RadioButton radioButton69;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.RadioButton radioButton70;
        private System.Windows.Forms.Panel panel38;
        private System.Windows.Forms.RadioButton radioButton67;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.RadioButton radioButton68;
        private System.Windows.Forms.Panel panel37;
        private System.Windows.Forms.RadioButton radioButton65;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.RadioButton radioButton66;
        private System.Windows.Forms.Panel panel42;
        private System.Windows.Forms.RadioButton radioButton75;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.RadioButton radioButton76;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.RadioButton radioButton61;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.RadioButton radioButton62;
        private System.Windows.Forms.Panel panel41;
        private System.Windows.Forms.RadioButton radioButton73;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.RadioButton radioButton74;
        private System.Windows.Forms.Panel panel34;
        private System.Windows.Forms.RadioButton radioButton59;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.RadioButton radioButton60;
        private System.Windows.Forms.Panel panel44;
        private System.Windows.Forms.RadioButton radioButton79;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.RadioButton radioButton80;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.RadioButton radioButton57;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.RadioButton radioButton58;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.RadioButton radioButton55;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.RadioButton radioButton56;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.RadioButton radioButton53;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.RadioButton radioButton54;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.RadioButton radioButton51;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.RadioButton radioButton52;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.RadioButton radioButton49;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.RadioButton radioButton50;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.RadioButton radioButton47;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.RadioButton radioButton48;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.RadioButton radioButton45;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.RadioButton radioButton46;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.RadioButton radioButton43;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.RadioButton radioButton44;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.RadioButton radioButton41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.RadioButton radioButton42;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.RadioButton radioButton39;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.RadioButton radioButton40;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.RadioButton radioButton37;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.RadioButton radioButton38;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.RadioButton radioButton35;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.RadioButton radioButton36;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.RadioButton radioButton33;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.RadioButton radioButton34;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.Panel panel45;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DateTimePicker dateTimePicker7;
        private System.Windows.Forms.DateTimePicker dateTimePicker4;
        private System.Windows.Forms.DateTimePicker dateTimePicker6;
        private System.Windows.Forms.DateTimePicker dateTimePicker3;
        private System.Windows.Forms.DateTimePicker dateTimePicker5;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.Panel panel47;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.Panel panel46;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.PictureBox odontograma;
        private System.Windows.Forms.Panel panel48;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.CheckedListBox checkedListBox1;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label lbNuevo;
        private System.Windows.Forms.Label lbEditar;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Panel panel49;
        private System.Windows.Forms.CheckBox checkBox20;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ComboBox comboBox13;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ComboBox comboBox14;
        private System.Windows.Forms.ComboBox comboBox15;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.ComboBox comboBox16;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.Label label109;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.TextBox textBox44;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.Label label112;
        private System.Windows.Forms.TextBox textBox45;
        private System.Windows.Forms.Label label115;
        private System.Windows.Forms.TextBox textBox46;
        private System.Windows.Forms.Label label116;
        private System.Windows.Forms.Label label114;
        private System.Windows.Forms.Label label1111;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox2;
    }
}