﻿namespace SHOPCONTROL {
    
    
    public partial class ReciboUsuario {
    }
}
namespace SHOPCONTROL {
    
    
    public partial class ReciboUsuario {
    }
}
