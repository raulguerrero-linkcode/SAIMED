﻿namespace SHOPCONTROL {
    
    
    public partial class ImagenB {
    }
}
